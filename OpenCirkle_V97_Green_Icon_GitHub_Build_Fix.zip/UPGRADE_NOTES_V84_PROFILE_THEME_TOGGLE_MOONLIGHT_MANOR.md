# V84 — Profile 8 Ball Pool Theme Toggle

- The Profile > More profile settings menu now exposes a dedicated **8 Ball Pool Theme** on/off switch.
- ON selects the `moonlight_manor` preference and activates the Moonlight Manor teal/green pool-table theme and supplied wallpaper.
- OFF selects `crystal_dark`, restoring the original Crystal Crypt blue/purple default appearance.
- Theme CSS is scoped to `data-oc-theme="moonlight"`; no Moonlight Manor palette or wallpaper is applied globally while OFF.
- The preference is saved to local storage and the signed-in user's Firestore profile, so it persists across restarts and devices.
- Existing `crystal_light` values from the earlier incorrect theme implementation are migrated as Moonlight Manor for backward compatibility.
