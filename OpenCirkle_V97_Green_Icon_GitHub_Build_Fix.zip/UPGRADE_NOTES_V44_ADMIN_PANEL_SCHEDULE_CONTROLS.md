# OpenCirkle v44 — Admin Panel Schedule Controls Upgrade

## Updated existing admin interfaces
- Updated `src/components/admin/AdminControlCenter.tsx` (the admin panel inside the app).
- Updated `ADMIN_CONTROL_CENTER_UPGRADED.html` (standalone Firebase-connected admin panel).
- Renamed the in-app section to **Scheduled App Availability Timer** for clearer wording.
- Added one-tap schedule presets:
  - Close in 1 hour; reopen in 2 hours.
  - Close in 6 hours; reopen in 8 hours.
  - Close in 24 hours; reopen in 25 hours.
- Added **Clear schedule** to disable the timer and clear both scheduled dates.
- Added the device/browser time-zone display and improved validation guidance for missing, invalid, or already-past close times.
- The standalone HTML panel now displays a live 1-second countdown preview and updates when schedule fields are edited.
- Existing Firestore setting names remain unchanged: `scheduledServiceEnabled`, `serviceCloseAt`, `serviceOpenAt`, stored in `platformSettings/global`.
- Existing settings save flow and audit logging are preserved.

## Important limitation
This schedule controls the app's maintenance/availability UI. It does not physically stop Netlify, Firebase, Cloud Functions, or all backend/API access. Enforcing a real service shutdown requires trusted server-side controls. The client display uses the device/browser clock.

## Verification
- Standalone admin HTML inline JavaScript syntax check passed with Node.js `--check`.
- ZIP integrity check passed after packaging.
- Full Vite/TypeScript build and live Firebase integration tests were not run in this environment; do not consider the update fully production-tested until it is built and tested against the actual Firebase project.
