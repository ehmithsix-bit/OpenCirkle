# OpenCirkle v46 — Admin Controls for Collaboration, Offline Status & Availability

## Admin Control Center
- Added global Post Collaboration enable/disable switch.
- Added configurable maximum collaborators per post (1–6).
- Added online/offline status banner visibility control.
- Added manual App Closed and Server Error screen types.
- Added one-time scheduled closure screen selection (Maintenance or App Closed).
- Added daily recurring close/open time controls and validation.
- Preserved existing app settings, payments, monetization, ads, customization, audit trail and account management.
- All settings save to `platformSettings/global` and administrative changes are written to `adminAuditLogs`.

## Main app integration
- `createPost` reads `platformSettings/global` before processing collaborator invites.
- Collaboration invitations are blocked when collaboration is disabled.
- The configured maximum collaborator count is enforced (hard ceiling remains six).
- `NetworkStatus` reads `offlineSyncIndicatorEnabled` and hides/shows the connection banner accordingly.
- Firestore persistent local cache remains enabled by the app build; the admin switch only controls the connection banner, not the cache engine.
- Responsive layout is a code-level adaptive fix and does not need an admin toggle.
- Main app already reads manual service modes, one-time schedules, daily schedules and scheduled screen type.

## Important limitations
- Offline Firestore persistence and automatic reconciliation are build-level behavior; do not present the banner switch as disabling/enabling the cache.
- Client-side schedules use each device's local clock/timezone. A trusted server scheduler is required for authoritative global enforcement.
- Client-side service screens do not physically stop Firebase, Netlify, Cloud Functions or direct API access.
- Deploy the updated Firestore rules and test collaboration writes in a staging Firebase project before production.
