OpenCirkle v79 — Admin Auto Greeting controls

Updated ADMIN_CONTROL_CENTER_UPGRADED.html:
- Added a dedicated Verified Auto Greeting navigation page.
- Lists only accounts with verified === true and verificationStatus approved (legacy verified accounts with no status are treated as approved to match the existing admin badge logic).
- Shows enabled/disabled status and whether a greeting message is configured without exposing the private message text.
- Adds an Admin/Super Admin-only disable action for an enabled verified account.
- Disabling preserves the user's greeting text and records admin UID/time plus an adminAuditLogs entry.
- Added search and summary counts based on the existing bounded users snapshot.

Important integration note:
The panel expects users/{uid}.autoGreetingEnabled, autoGreetingMessage, autoGreetingUpdatedAt (or autoGreetingUpdatedAtMs). The actual send-on-first-message behavior still requires the app-side settings UI, trusted Firebase Cloud Function, duplicate protection, and Firestore Security Rules to be implemented/deployed. This admin HTML does not itself send messages or deploy backend code. The default-avatar white-line fix belongs to the app UI, not the admin console.
