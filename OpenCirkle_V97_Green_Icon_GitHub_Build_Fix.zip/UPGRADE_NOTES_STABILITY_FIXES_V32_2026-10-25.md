# OpenCirkle stability fixes — 2026-10-25

## Changes
- Android native push permission: after sign-in, the app requests Android notification permission once for a user/device. If allowed, it registers for FCM and saves the token through the existing push service. If the user declines, the app does not repeatedly interrupt them; enable it from Android App info > Notifications or use Settings > Push Notifications.
- Web push remains user-gesture initiated from Settings > Push Notifications because browsers may suppress automatic permission prompts.
- Verification request modal now subscribes to `platformSettings/global`, so changes to `verificationFee`, bKash/Nagad receiver numbers, and payment instructions update live while the modal is open.
- App Design Studio publishing uses `setDoc(..., {merge:true})` so publishing can create `platformSettings/global` if it does not yet exist, rather than failing because `updateDoc` requires an existing document.
- Main app now applies admin-published theme CSS variables to common surfaces, respects header and navigation visibility flags, and respects the `showHeaderName` branding option.
- Added optional push fields to the user profile type.

## Verification fee
In the Admin Control Center, open App settings > Verification payment settings, set Verification fee (BDT), then save. The app reads `platformSettings/global.verificationFee`; existing requests keep their submitted amount, while new requests use the current fee.

## Important deployment note
Rebuild and redeploy the updated web app, and rebuild/reinstall the Android APK for native Android permission behavior and UI changes to take effect. A web deployment alone cannot change an already-installed APK. Deploy Firebase Functions and verify Firestore rules/token delivery for end-to-end background push.
