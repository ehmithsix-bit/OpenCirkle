/* Firebase Cloud Messaging service worker for OpenCirkle web push. */
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyBqcAKT35gt8b5QwcY8hoL6kT_ndBJsDCE',
  authDomain: 'echo-bb04c.firebaseapp.com',
  projectId: 'echo-bb04c',
  storageBucket: 'echo-bb04c.firebasestorage.app',
  messagingSenderId: '45625028258',
  appId: '1:45625028258:web:2cd2502e408ea6f94b71fb'
});

const messaging = firebase.messaging();
messaging.onBackgroundMessage((payload) => {
  const title = payload.notification?.title || payload.data?.title || 'OpenCirkle';
  const options = {
    body: payload.notification?.body || payload.data?.body || 'আপনার জন্য নতুন আপডেট আছে।',
    icon: '/opencirkle-splash-logo.png',
    badge: '/opencirkle-splash-logo.png',
    data: payload.data || { url: '/' },
    tag: payload.data?.tag || 'opencirkle-notification',
    renotify: false
  };
  self.registration.showNotification(title, options);
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = event.notification.data?.url || '/';
  event.waitUntil((async () => {
    const clientsList = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of clientsList) {
      if ('focus' in client) { await client.focus(); if ('navigate' in client) await client.navigate(target); return; }
    }
    if (clients.openWindow) await clients.openWindow(target);
  })());
});
