# OpenCirkle v81 — Latest Username & Display Name Fix

- Added a shared, 30-second cached lookup for canonical `users/{uid}` profiles with in-flight request deduplication.
- Feed post authors now display their current username, display name, verification and avatar values rather than only historical post snapshots.
- Comment authors are refreshed from their current user profiles when a discussion loads.
- Conversation list and active chat participant identities are refreshed from canonical user profiles.
- The signed-in user's current AuthContext profile takes precedence for their own posts and comments.
- Historical post/comment/message documents are not bulk rewritten; only displayed identity is refreshed.
- No Firestore collections or user data are deleted.

Validation: ZIP integrity checked. Run `npm install`, `npm run lint`, and `npm run build`, then test by changing a username/display name and reopening feed, comments, and chat. No Android device or live Firebase test was run.
