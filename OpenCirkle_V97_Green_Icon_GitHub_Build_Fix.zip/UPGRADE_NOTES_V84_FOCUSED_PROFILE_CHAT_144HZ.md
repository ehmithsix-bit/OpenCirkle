# OpenCirkle v84 — Focused Profile/Chat UI and High-Refresh Optimization

## Changes
- Hides the global header, desktop sidebars, announcement banner, and mobile bottom navigation while the Profile or Messages/Chat tab is active.
- Adds a compact Return button at the top of Profile and Chat. It returns to Feed and clears the selected profile/chat recipient.
- Uses a wider, tighter content layout in these focused screens.
- Adds an Android API 30+ frame-rate hint of 144 FPS. Android/display firmware remains in control and may select a lower supported refresh rate.
- Adds small touch/text rendering CSS optimizations without disabling pinch zoom or reduced-motion preferences.

## Build
After extracting:
1. `npm install`
2. `npm run build`
3. `npm run cap:sync`
4. Build the Android APK from the `android/` project.

Note: A local dependency install was attempted during this update but timed out, so a complete Vite/Android build could not be verified in this environment.
