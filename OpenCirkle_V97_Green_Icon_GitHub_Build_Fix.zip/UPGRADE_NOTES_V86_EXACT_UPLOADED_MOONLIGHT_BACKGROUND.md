# V86 — Exact Moonlight Manor background

- Replaced `src/assets/8-ball-pool-moonlight-manor.jpg` with the exact wallpaper uploaded in the conversation.
- When `8 Ball Pool Theme` is ON (`data-oc-theme="moonlight"`), the wallpaper is applied to the body as a fixed, cover-sized background canvas across app routes.
- Root and page-level wrappers are transparent in Moonlight mode so the wallpaper is visible behind the full app.
- When the toggle is OFF, the `moonlight` data attribute is not active and the existing Crystal Crypt theme/background rules remain in control.
- Existing theme preference persistence and profile toggle wiring are retained.
- ZIP integrity checked. A package build and device-level visual test were not run in this environment.
