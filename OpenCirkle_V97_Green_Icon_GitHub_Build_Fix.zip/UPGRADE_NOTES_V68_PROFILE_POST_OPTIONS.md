# OpenCirkle v68 — Profile Post Options Visibility Fix

- Made each post's three-dot options control a clearly visible 40x40 touch target with a stronger contrast, border, and focus state.
- Explicitly set button type and accessible label/title.
- Improved dropdown positioning for shorter mobile viewports.
- Kept existing edit, pin, boost, report, block, and delete behavior.

Validation: source ZIP integrity checked. Build and device testing were not run in this environment.
