# OpenCirkle V91 – Route-level code splitting and startup performance

## Changes
- Converted Explore, Notifications, Messenger, Bookmarks, Profile, Settings, and Admin Control Center to React lazy-loaded route chunks.
- Kept the Feed as the first interactive content section; it is also loaded through a dynamic import so the main application bundle does not eagerly include every large section.
- Added a lightweight accessible Suspense loading state while a section chunk is downloaded.
- Enabled CSS code splitting and set a modern ES2020 build target in Vite.

## Expected benefit
- Smaller initial JavaScript download/parse workload because large secondary screens are no longer bundled into the initial App import graph.
- Secondary sections are downloaded when first visited and then remain mounted using the existing visitedTabs behavior, preserving their current state behavior.
- CSS remains split by Vite where the import graph allows it.

## Compatibility / scope
- No Firebase schema, authentication, Firestore rules, Android package identity, UI theme, or user-facing feature logic was intentionally changed.
- This is a source-level performance optimization. Actual speed gains depend on device, network, browser cache, and production bundle output.

## Verification status
- Source edits and ZIP packaging completed.
- Production Vite build, TypeScript check, automated tests, Capacitor sync, Gradle APK build, and real-device profiling were not run in this environment. Run `npm ci`, `npm run lint`, `npm test`, `npm run build`, then `npx cap sync android` before release.
