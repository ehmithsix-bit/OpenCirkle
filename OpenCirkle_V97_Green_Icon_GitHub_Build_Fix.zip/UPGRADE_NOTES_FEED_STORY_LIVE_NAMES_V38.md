# OpenCirkle Feed Rotation + Live Story Names (v38)

## Changes
- Home feed no longer sorts the combined list back into a fixed newest-first order, which caused the same generated community author to repeatedly appear first.
- Each Home entry/load chooses a randomized slice of community profiles and shuffles the mixed feed list.
- On some Home loads (40% chance), one of the signed-in user's eligible recent posts is mixed into the feed, when such a post exists.
- Existing story rings subscribe to the current `users/{authorId}` profile document and display the latest display name, username, and avatar data instead of relying only on the snapshot stored when the story was created.
- The open story viewer also subscribes to the author's current profile, so the author name/username/avatar can update while viewing.

## Notes
- This change does not rewrite historical story documents; the UI resolves current profile details at display time.
- Story name syncing depends on story `authorId` matching the user's document ID in `users/{uid}` and Firestore rules allowing reads of those user documents.
- A full dependency install/build was not completed in this environment because `npm install` timed out. ZIP integrity was checked separately.
