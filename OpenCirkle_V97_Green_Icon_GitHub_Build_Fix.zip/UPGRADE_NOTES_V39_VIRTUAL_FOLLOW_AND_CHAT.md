OpenCirkle v39 — Sample Profile Follow & Chat Behavior

- Following locally generated sample profiles stores the relationship in browser/device localStorage only. It does not create a Firestore follows document, update Firebase counters, or send Firebase notifications.
- The current user's Following list includes locally followed sample profiles. The own-profile Following counter adds the number of locally followed sample profiles.
- Removed the old warning alert from sample-profile follow actions.
- Sample profile pages now show a Message action. Since sample profiles are not registered Firebase accounts, messages to them are stored locally on the current device and are not delivered to another person. The chat UI explicitly labels this as a local sample chat.
- Real Firebase accounts retain the existing Firebase follow and messaging flows.

Build note: npm install timed out in the execution environment, so a complete Vite build could not be run here. Please run npm install and npm run build before deploying.
