# V89 — Restore existing UI animations

- Removed the blanket `prefers-reduced-motion` rule in the mobile navigation that disabled every navigation animation and transition.
- Restored header wordmark lava-gradient motion and tap-triggered search/notification animations when Android's Reduce animations setting is enabled.
- Kept the existing dock entrance, left/right navigation entry, icon bounce/spin/pop, crystal rotating border, and button press feedback.
- Added a short reveal animation to the bottom navigation labels and made repeated taps replay the selected navigation animation.
- Preserved the V88 application structure, Firebase configuration, routes, and feature code.

Note: This V88 source has no separate footer component or footer text element. The bottom navigation labels are the available footer-area text, and their animation is restored here.
