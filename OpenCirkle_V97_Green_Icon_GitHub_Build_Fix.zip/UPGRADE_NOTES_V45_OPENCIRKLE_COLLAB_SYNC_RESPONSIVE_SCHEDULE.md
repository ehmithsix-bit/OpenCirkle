# OpenCirkle v45 — Collaboration, Sync, Responsive UI & Availability

## Implemented in this source update
- Added post collaboration invitations using usernames, Firestore collaborator state (`pending`, `accepted`, `rejected`), invite notifications, accept/reject actions, and accepted-collaborator display in post headers.
- Added persistent Firestore local cache with multi-tab support so offline reads use the same document model and cached changes reconcile when connectivity returns.
- Added adaptive dynamic viewport sizing and safe-area spacing for compact and large phone screens.
- Added distinct manual App Closed and Server Error service screens.
- Added daily recurring close/open times in the in-app Admin Control Center; the daily schedule uses the device local timezone and takes priority over the one-time schedule.

## Important deployment notes
- Deploy the updated `firestore.rules` with Firebase CLI; collaboration response writes will otherwise be denied by existing rules. Review the rules in a staging project before production.
- Firestore local persistence may be unavailable in some browser contexts; the code falls back to standard Firestore initialization.
- Client-side availability screens do not physically shut down Firebase, Netlify, Functions, or direct API access. True backend shutdown requires trusted server-side enforcement and security rules.
- Daily schedule evaluation uses each device's local clock/timezone. For authoritative scheduling across users, use a trusted server clock and scheduled Cloud Function.
- Usernames are resolved at post creation. Unknown usernames are skipped. Maximum 6 collaborators.
- Full build and live Firebase integration tests must be run with project dependencies and a staging Firebase project before release.
- Added an admin-selectable scheduled lock screen type so both one-time and daily schedules can show either Maintenance or App Closed.
