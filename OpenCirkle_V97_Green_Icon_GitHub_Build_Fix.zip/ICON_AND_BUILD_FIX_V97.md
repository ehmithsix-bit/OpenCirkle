# OpenCirkle V97 icon and Android build preparation

- Set the supplied pale-green/dark-green OpenCirkle mark as the Android launcher icon.
- Added legacy density launcher PNGs and Android adaptive launcher icon resources.
- Kept the application label and package ID unchanged: `OpenCirkle` / `com.opencirkle.app`.
- The original Android project does not include `gradlew` or `gradle-wrapper.jar`. The included `GITHUB_ACTIONS_BUILD_WORKFLOW.yml` installs Gradle 8.11.1 on the GitHub runner and builds the debug APK without requiring a wrapper.

To use the workflow while uploading this ZIP as a single file to GitHub, create `.github/workflows/build-apk.yml` in the GitHub repository and paste the contents of `GITHUB_ACTIONS_BUILD_WORKFLOW.yml` there. The workflow then extracts the ZIP from the repository root and builds the APK.
