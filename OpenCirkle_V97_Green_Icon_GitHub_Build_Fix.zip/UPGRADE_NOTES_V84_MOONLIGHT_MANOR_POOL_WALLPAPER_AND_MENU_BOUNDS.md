# V84 — Moonlight Manor 8 Ball Pool Wallpaper and Post Menu Bounds

- Applied the user-provided Moonlight Manor 8 Ball Pool wallpaper as the app canvas background in the 8 Ball Pool appearance. Green felt cards and controls remain readable above it.
- Reworked post three-dot menu placement to measure the actual app header and fixed bottom navigation/profile dock at runtime.
- The menu now chooses the side with more available room, caps its scrollable height to that measured space, and remains between the header and bottom dock instead of overlapping either.
