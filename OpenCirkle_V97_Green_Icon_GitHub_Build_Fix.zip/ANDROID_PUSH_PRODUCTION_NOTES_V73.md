# OpenCirkle Push Notifications — v73 implementation notes

## What this repository contains
- Frontend: React + TypeScript + Vite.
- Android shell: Capacitor 7 (`com.opencirkle.app`), Java `MainActivity`, Android target SDK 35.
- Authentication/data: Firebase Authentication + Cloud Firestore.
- Push client: `@capacitor/push-notifications` for Android; Firebase Web Messaging remains supported when configured with a Web Push VAPID key.
- Cloud Functions: Node.js 20, Firebase Functions v2 + Admin SDK.
- Firebase project found in the checked-in Android Google Services file: `echo-bb04c`; Android package matches `com.opencirkle.app`.

## Server-side notification events
Cloud Functions now cover post creation, story creation, online transitions with a 30-minute cooldown, new follow records, likes, comments (and replies when a comment document has `parentCommentId`/`replyToCommentId` plus `parentAuthorId`/`replyToUserId`), and new conversation messages. They check recipient preference, self-notification, account blocks, private-account follow eligibility for follower fan-out, story expiry/privacy, muted conversation metadata (`mutedBy`), and invalid FCM tokens. Notification delivery has stable event/recipient keys and retry status records to reduce duplicates.

Existing schema constraints remain: current comment UI/schema does not create reply-parent fields, so reply push handling only activates if that schema is populated. Story privacy uses the existing optional `privacy` field; current story composer does not expose a privacy selector. Message mute is respected when the conversation document stores `mutedBy` as an array or recipient-keyed map. Add the corresponding UI/data writes before promising those optional controls to users.

## Changed files
- `functions/index.js` — secure server-side fan-out, event triggers, recipient eligibility, stable delivery records, retry handling, invalid-token cleanup, online cooldown.
- `src/services/pushNotificationService.ts` — complete preference shape, token metadata refresh, notification tap hash routing.
- `src/components/settings/PushNotificationSettings.tsx` — controls for posts, stories, online alerts, likes, comments/replies, follows, messages, plus online visibility.
- `src/types/index.ts` — expanded push preferences, online visibility fields, notification types and story/message IDs.
- `src/App.tsx` — respects online visibility in heartbeat and handles post/story/message notification deep links.
- `src/components/feed/FeedView.tsx` — scrolls to a target post after a push deep link.
- `src/components/feed/IOSStorySpheres.tsx` — opens a target story from a deep link when it is present in the loaded story list.
- `src/components/notifications/NotificationsView.tsx` — notification tap navigation for stories/messages.
- `firestore.rules` — tighter token validation and client notification creation/update constraints.

## Firebase Console and deployment
1. Confirm Firebase Authentication providers used by OpenCirkle are enabled.
2. In Firebase Console > Project settings > Your apps, verify Android package `com.opencirkle.app` and keep the matching `android/app/google-services.json`.
3. Firebase Console > Cloud Messaging: ensure Cloud Messaging is enabled for the project. Android uses the Firebase Android app configuration; no FCM server key belongs in the app.
4. For web push only, generate/use the Web Push VAPID public key in Project settings > Cloud Messaging and set `VITE_FIREBASE_VAPID_KEY` in `.env` and the production hosting environment. Android does not need this variable.
5. Cloud Functions deployment generally requires the Firebase **Blaze (pay-as-you-go)** plan, billing enabled, and the required Google Cloud APIs. Costs depend on Firestore reads/writes, function invocations, and FCM usage. Review budgets/alerts first.
6. Install Firebase CLI, sign in, then run from repository root:
   ```bash
   npm install
   cd functions && npm install && cd ..
   firebase login
   firebase use echo-bb04c
   firebase deploy --only firestore:rules,firestore:indexes,functions
   ```
7. Build/sync Android after web changes:
   ```bash
   npm run build
   npx cap sync android
   npx cap open android
   ```

## Testing checklist (must be done with a deployed project and real Android devices)
- Install a fresh APK on Android 13+ and confirm the notification permission prompt appears only when the user enables notifications.
- Enable notifications; verify a `pushTokens` record is created with the authenticated UID, Android platform, and a current FCM token. Repeat on a second device/account to verify multi-device delivery.
- Test each category toggle and confirm disabled categories do not receive pushes.
- Publish a text post/story, follow, like, comment, and send a direct message from a second account; verify one in-app record and push on eligible recipient devices.
- Test online notifications across repeated app open/close cycles; confirm no repeated alerts within 30 minutes and hidden online status suppresses online alerts.
- Test foreground (in-app event), background, and force-stopped/terminated states; tap each push and verify it opens the relevant feed post, story, or messages tab.
- Test blocked users, private account/non-follower cases, expired stories, muted conversations, self-actions, and disabled global/category preferences.
- Revoke a test token/uninstall a test app, send another event, and verify invalid tokens are deleted.
- Inspect Firebase Functions logs for retry failures and Firestore indexes/rules errors.

## Verification status / known limits
- `node --check functions/index.js` passes in the current workspace.
- No Android device, deployed Firebase project, or real FCM delivery test is available in this workspace. Do not treat push delivery as production-verified until the deployment and checklist above pass.
- The existing comment model has no reply-parent fields and the story composer has no privacy selector; backend logic supports those fields if/when the UI writes them. Conversation mute only works if the existing conversation record uses `mutedBy` as described above.
- The current project uses a browser/WebView frontend and Capacitor native push plugin; notification delivery depends on a valid Firebase Android configuration, runtime permission, deployed Functions, network/device settings, and device OEM battery restrictions.
