# OpenCirkle — Normal Dummy Profile Display Fix

- Removed the visible “AI community” badge from locally generated starter-feed posts.
- Starter-feed authors now display a regular human-readable display name and handle instead of the “AI Community ·” prefix / `ai_community_` handle.
- Clicking one of these starter-feed authors opens the standard ProfileView layout using a local synthetic profile fallback, rather than “Profile Not Located”.
- These sample profiles remain local/demo-only and do not create Firebase user documents. Follow attempts show a clear notice; messaging and live presence are not enabled for them.
- Existing exact follower-count fix is preserved from the supplied ZIP.

Validation: ZIP integrity checked. Full Vite/TypeScript build was not run because node_modules are not present in this environment. Firebase/live behavior was not tested.
