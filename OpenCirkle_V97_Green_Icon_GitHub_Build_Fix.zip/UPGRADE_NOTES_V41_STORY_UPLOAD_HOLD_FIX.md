# OpenCirkle v41 — Story Upload and Press/Hold Fix

## Story upload
- Added a local `cleanFirestoreData` helper in `IOSStorySpheres.tsx` so the story upload path does not depend on an undefined function/import.
- Sanitizes the story payload before `addDoc`, removes undefined/function/symbol fields, keeps Firestore Timestamp and Date values intact, and normalizes non-finite numbers to null.
- Preserves the existing story fields and 24-hour expiration behavior.

## Story viewer press-and-hold
- Holding the story pauses the progress timer; releasing resumes from the same progress.
- Uses Pointer Events with pointer capture plus touch start/end/cancel fallbacks for Android WebView compatibility.
- Handles pointer cancellation/lost capture to avoid the story staying paused accidentally.
- Disables touch gestures on the story card so Android touch interactions do not interfere with hold-to-pause.

## Verification status
- Source edits were checked for the expected function and event handlers.
- A complete Vite/TypeScript build and real APK/Firebase runtime test still need to be run in an environment with dependencies and Android build tools installed.
- If the installed APK still reports the same error after rebuilding from this source, it is likely built from a different/older project copy; rebuild/sync the Android project from this updated source.
