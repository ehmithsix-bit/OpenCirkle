# OpenCirkle update notes — 2026-10-21

Changes in this patch:
- Explore search now separates hashtag searches, @username / People searches, and post searches instead of mixing the same result type into every tab.
- The own-profile menu now provides Log out and Add / Switch Account (signs out and opens the login flow for another account).
- Added a live sponsor placement component controlled by platformSettings/global: sponsorAdsEnabled, sponsorClickAdsEnabled, sponsorTitle, sponsorDescription, sponsorImageUrl, sponsorTargetUrl. It only accepts HTTPS URLs and never executes arbitrary sponsor scripts.
- Added sponsor ad controls to the updated standalone Super Admin Control Center HTML.
- Verification approval/rejection from the standalone admin panel now sends a personal in-app notification to the account.

Important:
- Deploy the updated web app bundle and the updated admin HTML together.
- Ensure Firestore Security Rules permit only authorized admins to write platformSettings/global and verification status; client UI is not a security boundary.
- Sponsor ad fields must be populated in the admin panel for the sponsor card to appear.
- Account switching signs out of the current Firebase session before opening the login dialog; this is not simultaneous multi-session account storage.
- Search results still depend on the existing Firestore schema, indexes, and the app's existing search services.
