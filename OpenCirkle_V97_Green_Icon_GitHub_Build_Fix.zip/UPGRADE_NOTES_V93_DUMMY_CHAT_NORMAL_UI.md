# OpenCirkle V93 — Dummy profile chat UI polish

- Removed the visible “Sample profile” label and “Local chat” badge from virtual/dummy profile conversations.
- Removed the explanatory local-only warning banner and local-only empty-state wording.
- Updated the empty state and composer placeholder to match the normal chat interface.
- Kept the existing virtual-profile local message storage/handling unchanged. Dummy-profile messages are still local-only and are not delivered to a registered user.
- No production build, Firebase live test, APK build, or device test was run for this update.
