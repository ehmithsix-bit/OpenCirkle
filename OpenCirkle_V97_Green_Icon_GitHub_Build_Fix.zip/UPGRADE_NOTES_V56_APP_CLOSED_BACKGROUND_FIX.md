# OpenCirkle v56 — App Closed Background Fix

- Expanded the App Closed artwork from a partial-height hero to a full-viewport background (`100dvh`, full inset).
- Kept the provided artwork proportionally cropped with `object-fit: cover` and centered positioning so it fills the entire screen on mobile aspect ratios.
- Reworked the full-screen dark gradient overlay to preserve legibility of the timer and controls while retaining the background image across the full screen.
- Removed the retry network-error feedback paragraph below the Try Again button. Retry behavior itself remains unchanged; it still checks authoritative service availability and reloads when the app is available.
- No other app screens or features intentionally changed.

Validation: source edits and ZIP archive integrity checked. A full production build was not run because project dependencies are not installed in this workspace.
