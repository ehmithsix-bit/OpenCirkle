package com.opencirkle.app;

import com.getcapacitor.BridgeActivity;
import android.os.Build;
import android.view.Surface;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        registerPlugin(AppVersionPlugin.class);
        super.onCreate(savedInstanceState);
        // Hint the Android compositor to use high-refresh-rate presentation when
        // the device/display supports it. The system may choose a lower rate.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().getDecorView().setFrameRate(
                144f,
                Surface.FRAME_RATE_COMPATIBILITY_DEFAULT
            );
        }
    }
}
