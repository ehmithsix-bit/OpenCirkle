# Netlify deployment repair — V88

## What was corrected
- The source project is packaged with `package.json` and `netlify.toml` at the ZIP root. This prevents Netlify from treating the project as an empty parent directory when the archive is uploaded or connected.
- Explicit Netlify base directory (`.`), build command (`npm run build`), publish directory (`dist`), and Node 22 runtime are declared.
- Added `public/_redirects` for React single-page-app routes. Existing assets are served normally; unknown client-side routes fall back to `index.html`.
- Preserved the V87 Moonlight Manor wallpaper CSS and the existing app source.

## Deploy
1. Extract this ZIP. The extracted folder itself contains `package.json` and `netlify.toml`.
2. In Netlify, set Base directory to `.` (or leave it blank), Build command to `npm run build`, and Publish directory to `dist`.
3. Trigger a fresh deploy and inspect the Deploy log if it fails.

## Verification limitation
The ZIP archive and file layout were checked. Dependency installation could not complete in this environment, so a production Vite build and live Netlify deployment could not be verified here. Do not treat this archive as a verified live deployment.
