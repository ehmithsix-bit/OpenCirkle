# OpenCirkle v60 — Text-first real Home feed

- Home/Trending/Following now render posts fetched from Firestore only; locally generated virtual community posts are no longer injected into the feed or used as a fallback when Firestore fails.
- Latest feed is sorted by creation time instead of shuffled generated content.
- Removed the Home empty-state action that seeded starter/demo posts. Empty feed now encourages the user to publish a real text post or discover real accounts.
- Refreshed text post card styling and interaction spacing for a dark, text-first feed.
- Kept the existing functional PostCard handlers for views, likes, comments, quote/repost, save/bookmark, share, and author post options.
- Stories remain sourced from the Firestore `stories` collection, not local mock profiles.

Build status: not verified in this environment because `npm install` timed out. Run `npm install`, `npm run lint`, `npm test`, and `npm run build` before releasing.
