# OpenCirkle v75 — precise avatar frame and display-name correction

- Removed the extra avatar wrapper ring/shadow and disabled the avatar border/shadow in the feed post header, retaining the circular avatar itself.
- Restored the original post-author text layout: `@username` remains on the first line and the display name remains on the second line.
- Kept live Firestore profile subscription/fallback lookup so the second-line display name uses the user's latest non-empty `displayName`; it falls back to the post's stored display name/username only if no current profile value is available.
- Did not move username beside display name or change other app features.
- Validation: source edits and ZIP integrity checked. Full app build/device test not run in this environment.
