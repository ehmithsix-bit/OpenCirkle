# OpenCirkle v70 — Virtual Profile Post Sync

- Fixed virtual community profile IDs so they use the same stable `ai-community-N` IDs as Home/Trending feed posts.
- Made virtual profile post content derive from the persona's stable community index, aligning profile content with the same content generator used by the feed.
- Made sample profile posts appear as recent items instead of timestamps several hours apart.
- Kept virtual community users local-only; no dummy accounts or posts are written to Firebase.

Validation: source changes inspected; ZIP archive integrity checked. App build/device testing not performed in this environment.
