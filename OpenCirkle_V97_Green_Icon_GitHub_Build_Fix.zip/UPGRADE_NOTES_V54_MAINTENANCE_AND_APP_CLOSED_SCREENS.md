# OpenCirkle v54 — Maintenance and App Closed UI

- Added the two supplied screen designs as separate full-screen app lock experiences.
- Added optimized hero artwork assets cropped from the user-provided references.
- Maintenance screen displays a live DD:HH:MM:SS countdown and the supplied notification-email field/button.
- App Closed screen displays a cinematic dark hero, circular red countdown ring, error copy and Try Again action.
- Admin global service settings now include optional screen-specific maintenance end and app-closed reopen timestamps.
- Existing one-time schedule and fallback reopen time remain supported.
- The schedule uses absolute epoch-millisecond timestamps and refreshes the displayed countdown every second.
- Normal application screens and existing feature routes were not intentionally redesigned.

## Admin setup
Choose the scheduled lock screen type, set the app close time, then set the matching Maintenance screen end time or App Closed screen reopen time. The matching screen-specific timestamp takes precedence over the general fallback reopen time. Save Parameters to publish through `platformSettings/global`.

## Notes
The maintenance notification field is currently UI-only; no email notification backend is configured. Timer accuracy depends on the device clock being reasonably synchronized because the current app schedule stores absolute timestamps in Firestore and evaluates them client-side. Firebase/Netlify services are not physically shut down by the UI lock.
