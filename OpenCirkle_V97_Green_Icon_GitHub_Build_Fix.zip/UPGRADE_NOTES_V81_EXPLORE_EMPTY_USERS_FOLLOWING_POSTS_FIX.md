# OpenCirkle Explore filtering fix

- Explore People now excludes profiles with missing UID, username, or display name, as well as inactive profiles and the current account.
- People matching uses trimmed, normalized values so empty `@` handles and whitespace-only profile fields do not appear.
- Explore All Results and Posts only show public, non-scheduled posts authored by accounts the signed-in user follows.
- Signed-out users and users who follow nobody see a clear empty state instead of unrelated posts.
- Existing Home/Following/Trending feed behavior is unchanged.
