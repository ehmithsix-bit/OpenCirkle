# OpenCirkle v55 — Maintenance actions backend

## User-facing changes
- Maintenance `Notify Me` calls the `subscribeMaintenanceNotifications` Firebase callable function. Emails are normalized and validated server-side, SHA-256 keyed, and stored in `serviceNotificationSubscribers` as pending subscriptions. Duplicate pending/queued subscriptions are acknowledged without creating duplicates.
- App Closed `Try Again` calls `checkServiceAvailability`, which reads `platformSettings/global` using Firebase Admin SDK and returns the authoritative service mode, message, target timestamp, and server time. The app reloads only after the backend reports `normal`; otherwise it keeps the lock screen and explains that the service is still unavailable.
- Added loading and error/success feedback to both actions.
- Daily schedule saves the admin browser's IANA timezone so callable checks and the restoration scheduler evaluate the recurring window consistently.

## Email delivery setup required
The backend queues a message in the `mail` collection when scheduled/manual maintenance ends. To actually deliver email, install and configure the official Firebase **Trigger Email** extension for this Firebase project, pointed at the `mail` collection, with a working SMTP provider/sender. Without that extension and SMTP configuration, subscriptions are saved and outgoing messages are queued, but no email is delivered.

## Deployment required
Deploy the Firestore rules and Cloud Functions from the project root:

```bash
firebase deploy --only firestore:rules,functions
```

The `notifyMaintenanceRestored` function runs every minute using Cloud Scheduler. Firebase project billing/Blaze plan and Cloud Scheduler availability are required for scheduled execution. Callable functions use `us-central1`.

## Data collections
- `serviceNotificationSubscribers/{sha256(email)}` — pending/queued notification subscriptions. Client cannot directly read or write this collection; Admin SDK callable function manages it.
- `mail/{messageId}` — outgoing email queue consumed by Firebase Trigger Email extension.
- `platformSettings/serviceNotificationState` — server-side previous lock state used to detect restoration transitions.

No SMTP credentials or provider secrets are embedded in the app or repository.
