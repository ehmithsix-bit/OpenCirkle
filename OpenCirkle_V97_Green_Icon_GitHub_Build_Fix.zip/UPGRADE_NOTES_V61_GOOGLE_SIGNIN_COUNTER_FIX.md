# OpenCirkle v61 — Google Sign-In and counter fixes

- Preserved the existing virtual/sample community profiles and their profile/feed behavior; no dummy-user removal was performed.
- Normalized post like, comment, repost, bookmark, and view counters to non-negative integers when Firestore documents are mapped to the UI.
- Clamped optimistic post-action counters so the UI does not render negative values.
- Clamped comment count updates when a comment is added or deleted.
- Improved native Android Google Sign-In result parsing and error messages for common OAuth developer/SHA certificate configuration errors. The Web OAuth client ID remains aligned with the ID in `android/app/google-services.json`.
- Android versionCode bumped to 61 and versionName to 1.0.3.

## Google Sign-In deployment checklist

For native Google sign-in to work on a real APK, Firebase Authentication must have the Google provider enabled; the Android app must use package `com.opencirkle.app`; SHA-1 and SHA-256 fingerprints for the actual signing certificate (debug and release as applicable) must be added in Firebase; then download the refreshed `google-services.json` and rebuild. These console-side settings cannot be changed from source code alone.

Build/test status: source changes prepared; a full Gradle/Vite build has not been run in this environment.
