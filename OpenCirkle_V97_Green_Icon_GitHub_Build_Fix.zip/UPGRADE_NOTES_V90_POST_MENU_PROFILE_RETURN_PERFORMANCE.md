# OpenCirkle V90 – Post menu layering, profile return visibility, and feed rendering

- Post options menus now use a stacking level below the fixed mobile navigation dock, preventing the menu from painting over the app's fixed header/footer navigation.
- The profile return control is visible at the top of the profile and hides after the user scrolls; it reappears when the user returns to the top. The messages return behavior is unchanged.
- Feed post cards use CSS content visibility with an intrinsic size hint so off-screen cards can be skipped during rendering, and card transitions are limited to color changes rather than animating every property.

Validation: source changes reviewed. A production build could not be run because dependency installation did not complete in the available environment.
