# OpenCirkle v77 — Edit Profile Mobile Scroll Fix

## Changes
- The Edit Profile modal now uses a constrained dynamic viewport height (`dvh`) and a flex-column layout on mobile.
- The form itself is the scroll container, with touch scrolling, momentum scrolling, and contained overscroll for Android WebView.
- Save/Cancel controls remain in a sticky bottom area inside the form so the Save Profile button can be reached after scrolling.
- The top title stays visible while the form fields scroll.

## Validation
- Source-level change only. Run `npm run lint`, `npm run build`, then test in Android WebView with the keyboard open and closed. Real device testing was not available during this change.
