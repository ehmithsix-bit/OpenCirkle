# OpenCirkle v80 — Edit Post Mobile Scroll & Save Fix

## Changes
- Reworked the Edit Post modal into a viewport-constrained flex column.
- Made the editor body independently scrollable with touch scrolling and overscroll containment.
- Kept Cancel and Save Changes in a persistent footer outside the scrolling region.
- Added mobile safe-area bottom padding and raised the modal stacking level so controls remain accessible.
- Preserved existing post edit and collaborator update handlers and Firestore behavior.

## Validation
- Source-level change only. Run `npm install`, `npm run lint`, and `npm run build` before release, then test on a small Android screen with the keyboard open and closed.
- No Firestore documents or user data were deleted or migrated.
