OpenCirkle v64 — Navigation and Feed Pagination

Changes:
- Keep FeedView mounted when navigating to other main sections so its current feed state and scroll position are retained rather than re-fetching on every return to Home.
- Remove active-tab keyed error-boundary remounting, which reset the entire view boundary on every section switch.
- Improve latest-feed and Following-feed fallback pagination so subsequent pages can use a Firestore document cursor instead of returning a null cursor and silently stopping after the first page.
- Existing local virtual community profile/content generation is preserved; no dummy users were removed.
- User-authored post text already supports Unicode. Bengali and other scripts can be entered/stored as text; this patch does not automatically translate content.

Validation: source changes were made, but dependencies are not installed in this environment, so build/lint and on-device performance testing remain to be run. Firestore indexes/security rules and production data volume can still affect feed availability and speed.
