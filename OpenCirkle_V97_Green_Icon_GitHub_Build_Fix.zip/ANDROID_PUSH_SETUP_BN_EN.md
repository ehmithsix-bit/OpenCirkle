# OpenCirkle Android Studio + Native FCM Push

This source package preserves the existing React/Vite application, Firebase Authentication, Firestore services/rules/indexes, and Cloud Functions. It includes an Android Studio Gradle project scaffold and Capacitor Push Notifications wiring.

## Firebase identity
- Android applicationId / namespace: `com.opencirkle.app`
- Firebase project: `echo-bb04c`
- `google-services.json`: `android/app/google-services.json` (copied from the supplied file; package name checked)

## Build in Android Studio (internet and Android SDK required)
1. Extract the ZIP on a computer with Node.js LTS, Java 17, Android Studio, and Android SDK Platform 35 installed.
2. In the extracted project root, run `npm install`.
3. Run `npm run cap:sync`. This builds the Vite app into `dist` and generates/synchronizes Capacitor assets and plugin metadata into `android/`.
4. Open the `android/` directory in Android Studio and allow Gradle to download the Android Gradle Plugin/Gradle dependencies.
5. Build > Build APK(s). For Google Sign-In, add the SHA-1 and SHA-256 of the actual debug/release signing certificate to Firebase Console and download a refreshed `google-services.json` if the OAuth client configuration changes.

## Native push behavior implemented in source
- Uses `@capacitor/push-notifications` on native Android; browser builds continue to use the existing Web FCM/VAPID flow.
- Requests Android notification permission only when the user presses Allow in Push Notification settings.
- Creates the `opencirkle_updates` channel, registers with FCM, listens for registration errors, foreground notifications and notification taps.
- Saves native FCM token documents to Firestore `pushTokens` with `{ uid, token, platform: 'android', createdAt }`, compatible with `functions/index.js` token lookup.
- On sign-in, an already opted-in account attempts to restore native registration without prompting unexpectedly.
- Cloud Functions send both notification and data payloads. Android can display the notification payload while backgrounded; foreground events are forwarded to the app. Tap payload includes a URL and emits an `opencirkle:push-action` event.
- Explicit opt-out removes the user's token documents and the native listeners. Cloud Functions also honor `pushNotificationsEnabled: false`.

## Backend deployment and verification
From the project root, deploy rules/indexes/functions as appropriate (ensure the Firebase CLI is authenticated and the intended project is selected):

```bash
firebase use echo-bb04c
firebase deploy --only firestore:rules,firestore:indexes,functions
```

Cloud Functions are not deployed by building the Android app. Check Firebase Console for project billing/plan and Functions runtime requirements. Confirm the functions' triggers match your live Firestore collection names and fields. The supplied functions currently listen to `posts/{postId}`, `stories/{storyId}`, `conversations/{conversationId}/messages/{messageId}`, and user online status updates.

## Verification status / limitations
- Package name in the supplied `google-services.json` matches `com.opencirkle.app`.
- The Android Gradle project files, manifest, MainActivity, icon placeholder, and native push source wiring are included.
- A full Gradle build, emulator/device run, real FCM delivery, Google Sign-In, and live Cloud Functions test were **not performed** in this environment.
- `npm install` did not finish within the available execution window, so dependency installation, `npm run build`, `npm run lint`, Capacitor sync, and Gradle compilation remain unverified. The generated `dist/` and Capacitor plugin metadata/assets are created by `npm run cap:sync`; they are not claimed to be prebuilt here.
- The ZIP includes `gradle-wrapper.properties`, but not the Gradle wrapper JAR/scripts. Open `android/` in Android Studio to use its Gradle integration, or generate a wrapper locally after Gradle is installed.
- If Google Sign-In fails, the JSON's Android OAuth certificate fingerprint must match the key signing the APK. The included config cannot supply or infer your private keystore.


## Native Android Google Sign-In + feed upgrade (2026-10-24)

- Added `@capgo/capacitor-social-login` for native Android Google account selection. On Android, the app exchanges the Google ID token with Firebase Auth using `GoogleAuthProvider.credential`; web retains popup sign-in.
- Web OAuth client ID configured: `45625028258-a628p4d4pvak822hjq7gguo04njvll0i.apps.googleusercontent.com`. Ensure the Firebase Android app `com.opencirkle.app` has the current signing SHA-1 and SHA-256 registered.
- Profile label is now `Followers`; `Update This App` is only rendered on the signed-in user's own profile; post options menu has an X close control.
- Home/Trending has 20,000 virtual community profile identities, batched virtual posts, intersection-observer infinite loading and a refresh reset. These are not real Firebase Auth accounts/Firestore user records.
- Quran.com, Sunnah.com and BBC Bangla are linked as sources in community prompts. Actual live article/ayah ingestion has not been implemented; do not represent generated prompts as live website content.
- Build validation pending: run `npm install`, `npm run lint`, `npm run build`, `npx cap sync android`, then Android Studio Gradle sync/build and test Google login on a physical Android device.
