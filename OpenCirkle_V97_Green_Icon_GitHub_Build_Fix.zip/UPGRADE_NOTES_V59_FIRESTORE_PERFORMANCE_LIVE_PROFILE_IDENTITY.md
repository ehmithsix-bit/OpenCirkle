# OpenCirkle v59 — Firestore performance and live profile identity

## Changes
- Removed the optional extra `fetchUserPosts()` request from the initial Home feed path. It was awaited after the main feed query and could delay the first render.
- Run profile-authored-post and collaboration-response reads concurrently; retain a safe authored-post fallback if the ordered query fails.
- Run follow and follow-request lookups concurrently to reduce per-user Explore follow-status latency.
- Ensure suggested user profiles take their UID from the Firestore document ID, so user cards remain usable when older documents omit `uid` in their fields.
- Profile presence listener now refreshes public identity fields (including username and display name) from the live Firestore user document, so edits appear without reopening the screen.
- Replace the misleading `Activity unavailable` label with `Offline` when no last-active timestamp exists. The actual last-active time still depends on the user having a timestamp stored in Firestore.

## Validation
- Source edits applied. A full Vite/TypeScript build was not verified in this environment because dependency installation timed out.
- No Firestore rules, credentials, indexes, or production data were changed.
