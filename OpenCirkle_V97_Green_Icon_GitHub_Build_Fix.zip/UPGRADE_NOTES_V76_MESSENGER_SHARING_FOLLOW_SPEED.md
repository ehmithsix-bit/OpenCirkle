# OpenCirkle v76 — Messenger sharing and follow responsiveness

## Changes
- Added `src/components/messages/ShareToUserModal.tsx`: loads real active user profiles, supports search, and shares a post/story to a selected user through the existing Firestore conversation/message service. It does not create fake users or bypass the current messaging model.
- Updated `src/components/post/PostCard.tsx`: the post share action opens the in-app Messenger recipient picker and sends a post link plus a text excerpt.
- Updated `src/components/feed/DiscourseSphereModal.tsx`: the story share action opens the same picker and sends a story link plus story text.
- Updated `src/services/socialService.ts`: follow/unfollow counter writes run concurrently; notification creation is fire-and-forget so push/in-app notification latency no longer blocks the follow button response.
- Updated `src/components/explore/ExploreView.tsx`: optimistic follow state, per-user busy lock and disabled button while the Firestore operation is pending.
- Updated `src/components/profile/ProfileView.tsx`: optimistic follow state, busy lock, rollback on failure and disabled follow button during the request.

## Notes / verification
- Existing `#post-...` and `#story-...` hash handlers are used for shared links.
- The app remains text-first and uses the existing Firestore `conversations/{id}/messages` schema.
- Build/device testing was not run in this environment because `node_modules` is absent and no Firebase credentials/device are available. Install dependencies and run `npm run lint`, `npm run build`, then test sharing and follow/unfollow using two real accounts.
