# OpenCirkle v40 — Story age and 24-hour expiry fix

- Replaced the hard-coded `2h ago` label with a live relative timestamp based on each story's `createdAt`.
- Refreshes the age label every 30 seconds while the story viewer is open.
- Story rings now hide stories after a hard 24 hours from `createdAt`, even when an old/malformed `expiresAt` field is later.
- The open story viewer closes when the current story reaches 24 hours.
- Normalizes Firestore Timestamp values and numeric seconds/milliseconds for story timestamps.
- Story deletion remains best-effort for the signed-in user's own expired stories; Firestore TTL can be configured for server-side cleanup.

Build verification: not yet run in this environment.
