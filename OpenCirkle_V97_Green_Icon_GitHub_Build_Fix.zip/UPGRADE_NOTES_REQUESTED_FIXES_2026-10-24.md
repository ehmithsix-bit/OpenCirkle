# OpenCirkle requested fixes — 2026-10-24

Implemented in source:
- Android uses `@capgo/capacitor-social-login` Google account chooser and exchanges its ID token with Firebase Auth credentials; web continues to use the web popup.
- All profile counters now say `Followers`.
- `Update This App` and its release notes are rendered only on the signed-in user's own profile menu.
- Post options menu includes a visible X close control.
- Home/Trending feed now generates batches from a 20,000-entry local virtual community pool, loads more on scroll using an IntersectionObserver, and keeps a manual load-more fallback. Refresh resets the feed cursor and community offset.
- Community posts contain links to Quran.com, Sunnah.com and BBC Bangla for source checking.

Important limitations / verification status:
- The 20,000 profiles are virtual client-side profiles, NOT 20,000 Firebase Authentication accounts or Firestore user documents. Creating actual accounts safely requires a trusted Admin SDK backend and explicit database/rules design; this client code does not create them.
- Community post text is curated source-attributed prompts and references; this change does not ingest live Quran/Hadith/news articles from those websites. Live ingestion requires a backend feed/API integration, source validation and scheduled Cloud Functions.
- Native Google Sign-In depends on the installed plugin version and correct Firebase Android OAuth SHA-1/SHA-256 fingerprints. Must install dependencies, run `npm run lint`, `npm run build`, `npx cap sync android`, then Gradle build and real-device test. Not verified in this environment.
- No build/APK or live FCM/Google OAuth test is claimed.
