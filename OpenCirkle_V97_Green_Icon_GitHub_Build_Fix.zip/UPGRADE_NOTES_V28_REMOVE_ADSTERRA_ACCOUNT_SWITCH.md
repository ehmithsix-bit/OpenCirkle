# OpenCirkle v2.8 — Adsterra removal and account switching

- Removed all Adsterra placements from the feed (native banner, banner, and sponsored smartlink).
- Removed the Adsterra Social Bar script from `index.html` and deleted the Adsterra component module.
- Added a remembered-account picker to the sign-in modal. Successful sign-ins and registrations remember account email addresses locally; passwords are never saved.
- The profile menu's Add / Switch Account and Log out actions now sign out and return to the sign-in/account picker instead of leaving the user on the unauthenticated welcome screen.
- When switching/logging out, the picker selects a different remembered email when one is available. The user must enter that account's password because Firebase does not allow safe automatic switching between accounts without re-authentication.
- The sign-in modal includes “Forget all saved accounts · Create a new account”, which clears remembered email addresses and opens registration.

Only Adsterra was removed. Other ad integrations, including Google AdSense and the existing admin-controlled Monetag slot, were not changed.
