# v69 — Full-screen Story Viewer

- Story viewer now fills the phone viewport instead of appearing as a small centered card.
- Removed large outer margins and rounded-card framing on mobile to reclaim screen space.
- Uses dynamic/small viewport height and safe-area padding for mobile browsers and Android WebView.
- Story media can use more of the screen while remaining contained (not cropped); text stories are centered and more readable.
- Keeps progress, author header, close button, viewer list, pause behavior, and story actions.
- Source ZIP integrity checked; app build/device verification not performed.
