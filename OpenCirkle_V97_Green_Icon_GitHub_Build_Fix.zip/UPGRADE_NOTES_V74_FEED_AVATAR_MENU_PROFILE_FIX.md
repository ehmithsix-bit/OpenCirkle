# OpenCirkle v74 — Feed avatar, post menu, live author names

Changes based on v73:
- Changed CrystalAvatar rendering to circular avatars instead of rounded-square avatars; kept the existing color themes and avatar artwork.
- Rendered the post options menu through React DOM portal to `document.body`, so feed/header/footer stacking contexts and overflow containers cannot cover or clip the menu.
- Feed post headers now show the current display name prominently and the current `@username` beside it.
- Live author profile subscription reads `users/{authorId}` and falls back to looking up a legacy profile by its `uid` field when the direct document does not exist.

Validation: source changes reviewed and ZIP archive integrity checked. Full build and real-device visual test were not run because dependencies are not installed in this environment.
