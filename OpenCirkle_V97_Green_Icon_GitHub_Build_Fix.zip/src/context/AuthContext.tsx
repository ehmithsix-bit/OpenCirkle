import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, onSnapshot, getDoc, setDoc } from 'firebase/firestore';
import { UserProfile, UserRole } from '../types';
import { logoutUser } from '../services/authService';
import { initializeNativePushForUser } from '../services/pushNotificationService';

interface AuthContextType {
  firebaseUser: FirebaseUser | null;
  currentUserProfile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  isModerator: boolean;
  isSuperAdmin: boolean;
  refreshProfile: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  firebaseUser: null,
  currentUserProfile: null,
  loading: true,
  isAdmin: false,
  isModerator: false,
  isSuperAdmin: false,
  refreshProfile: async () => {},
  logout: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [currentUserProfile, setCurrentUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribeProfileSnapshot: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (unsubscribeProfileSnapshot) {
        unsubscribeProfileSnapshot();
        unsubscribeProfileSnapshot = null;
      }

      if (user) {
        const userDocRef = doc(db, 'users', user.uid);
        
        // Listen to live changes to the user's profile
        unsubscribeProfileSnapshot = onSnapshot(userDocRef, async (snap) => {
          if (snap.exists()) {
            const data = snap.data() as UserProfile;
            const moderationStatus = String((data as any).status || (data as any).accountStatus || '').toLowerCase();
            const blockedByModeration = (data as any).isBanned === true || (data as any).banned === true || (data as any).isSuspended === true || ['banned', 'suspended'].includes(moderationStatus);
            if (blockedByModeration) {
              // Account status is watched live, so a moderator's ban/suspension takes effect in an open session too.
              setCurrentUserProfile(null);
              setLoading(false);
              console.warn(`OpenCirkle account access blocked (${moderationStatus || 'moderation flag'}).`);
              window.alert(moderationStatus === 'suspended' || (data as any).isSuspended === true
                ? 'Your OpenCirkle account has been suspended. Please contact support.'
                : 'Your OpenCirkle account has been banned. Please contact support.');
              await logoutUser().catch((err) => console.error('Could not sign out blocked account:', err));
              return;
            }
            if ((data as any).pushNotificationsEnabled === true) void initializeNativePushForUser(user.uid);
            setCurrentUserProfile((current) => {
              if (!current) return data;
              const keys = new Set([...Object.keys(current), ...Object.keys(data)]);
              keys.delete('lastActiveAt');
              const changed = [...keys].some((key) => JSON.stringify((current as unknown as Record<string, unknown>)[key]) !== JSON.stringify((data as unknown as Record<string, unknown>)[key]));
              return changed ? data : current;
            });
          } else {
            // Profile document might need initial creation if registered via external link or missing
            const email = user.email || '';
            const fallbackUsername = (user.email?.split('@')[0] || `user_${user.uid.slice(0, 5)}`).toLowerCase().replace(/[^a-z0-9_]/g, '');
            const isSuperAdminEmail = email.toLowerCase() === 'rabiafroj43@gmail.com';
            const role: UserRole = isSuperAdminEmail ? 'superadmin' : 'user';

            const defaultProfile: UserProfile = {
              uid: user.uid,
              email,
              username: fallbackUsername,
              displayName: user.displayName || fallbackUsername,
              bio: 'Exploring the crystalline depths of OpenCirkle.',
              joinedAt: Date.now(),
              followersCount: 0,
              followingCount: 0,
              postsCount: 0,
              likesCount: 0,
              verified: isSuperAdminEmail,
              isPrivate: false,
              role,
              status: 'active',
              avatarSymbol: 'gem',
              avatarColor: 'electric',
              blockedUsers: [],
              mutedWords: [],
              themePreference: 'crystal_dark',
              notificationsEnabled: true,
            };

            await setDoc(userDocRef, defaultProfile);
            setCurrentUserProfile(defaultProfile);
          }
          setLoading(false);
        }, (err) => {
          console.error('Error listening to user profile:', err);
          setLoading(false);
        });
      } else {
        setCurrentUserProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfileSnapshot) {
        unsubscribeProfileSnapshot();
      }
    };
  }, []);

  const refreshProfile = async () => {
    if (!firebaseUser) return;
    const snap = await getDoc(doc(db, 'users', firebaseUser.uid));
    if (snap.exists()) {
      setCurrentUserProfile(snap.data() as UserProfile);
    }
  };

  const logout = async () => {
    await logoutUser();
    setFirebaseUser(null);
    setCurrentUserProfile(null);
  };

  const isSuperAdmin = currentUserProfile?.role === 'superadmin' || firebaseUser?.email === 'rabiafroj43@gmail.com';
  const isAdmin = isSuperAdmin || currentUserProfile?.role === 'admin';
  const isModerator = isAdmin || currentUserProfile?.role === 'moderator';

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        currentUserProfile,
        loading,
        isAdmin,
        isModerator,
        isSuperAdmin,
        refreshProfile,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
