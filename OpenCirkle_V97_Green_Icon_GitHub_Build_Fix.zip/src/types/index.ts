export type UserRole = 'user' | 'moderator' | 'admin' | 'superadmin';
export type UserStatus = 'active' | 'suspended' | 'banned';

export interface UserProfile {
  uid: string;
  email: string;
  username: string;
  usernameChangeCount?: number;
  usernameCooldownUntil?: number;
  displayName: string;
  bio: string;
  joinedAt: number;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  likesCount: number;
  verified: boolean;
  isPrivate: boolean;
  role: UserRole;
  status: UserStatus;
  pinnedPostId?: string | null;
  avatarSymbol: 'gem' | 'prism' | 'hexagon' | 'star' | 'orb' | 'sparkle' | 'shield' | 'diamond';
  avatarColor: 'electric' | 'ice' | 'sapphire' | 'cyan' | 'neon';
  /** Profile photo supplied by Google Sign-In, when available. */
  avatarUrl?: string;
  blockedUsers?: string[];
  mutedWords?: string[];
  themePreference?: 'crystal_dark' | 'moonlight_manor' | 'crystal_light';
  notificationsEnabled?: boolean;
  pushNotificationsEnabled?: boolean;
  onlineVisibility?: boolean;
  showOnlineStatus?: boolean;
  pushPreferences?: { messages: boolean; posts: boolean; stories: boolean; online: boolean; likes?: boolean; comments?: boolean; follows?: boolean };
}

export interface PostCollaborator {
  uid: string; username: string; displayName: string; status: 'pending' | 'accepted' | 'rejected'; invitedAt: number; respondedAt?: number;
}

export interface Post {
  id: string;
  authorId: string;
  authorUsername: string;
  authorDisplayName: string;
  authorVerified: boolean;
  authorAvatarSymbol: UserProfile['avatarSymbol'];
  authorAvatarColor: UserProfile['avatarColor'];
  authorAvatarUrl?: string;
  content: string; // Strictly text-only
  communityCategory?: string; // Optional category selected by any member when publishing
  privacy?: 'public' | 'private';
  scheduledAt?: number | null;
  isScheduled?: boolean;
  tags: string[];
  mentions: string[];
  createdAt: number;
  editedAt?: number | null;
  likesCount: number;
  commentsCount: number;
  repostsCount: number;
  bookmarksCount: number;
  viewsCount?: number;
  isPinned?: boolean;
  isRepost?: boolean;
  collaborators?: PostCollaborator[];
  collaboratorIds?: string[];
  repostOf?: {
    id: string;
    authorUsername: string;
    authorDisplayName: string;
    authorVerified?: boolean;
    content: string;
    createdAt: number;
  } | null;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  authorUsername: string;
  authorDisplayName: string;
  authorVerified: boolean;
  authorAvatarSymbol: UserProfile['avatarSymbol'];
  authorAvatarColor: UserProfile['avatarColor'];
  authorAvatarUrl?: string;
  content: string;
  createdAt: number;
  editedAt?: number | null;
}

export type NotificationType = 'like' | 'comment' | 'reply' | 'post' | 'story' | 'online' | 'message' | 'repost' | 'follow' | 'follow_request' | 'mention' | 'monetization_approved' | 'monetization_rejected' | 'monetization_payout' | 'collab_invite' | 'collab_accepted' | 'collab_rejected';

export interface NotificationItem {
  id: string;
  recipientId: string;
  senderId: string;
  senderUsername: string;
  senderDisplayName: string;
  senderAvatarSymbol: UserProfile['avatarSymbol'];
  senderAvatarColor: UserProfile['avatarColor'];
  senderAvatarUrl?: string;
  type: NotificationType;
  targetPostId?: string;
  storyId?: string;
  messageId?: string;
  textSnippet?: string;
  /** Invitee's recorded response to a collaboration invitation, when applicable. */
  collaborationResponse?: 'accepted' | 'rejected';
  read: boolean;
  createdAt: number;
}

export interface ConversationParticipant {
  username: string;
  displayName: string;
  avatarSymbol: UserProfile['avatarSymbol'];
  avatarColor: UserProfile['avatarColor'];
  avatarUrl?: string;
  verified?: boolean;
}

export interface Conversation {
  id: string;
  participantIds: string[];
  participantData: Record<string, ConversationParticipant>;
  lastMessageText: string;
  lastMessageTimestamp: number;
  lastSenderId: string;
  unreadCount: Record<string, number>;
  updatedAt: number;
}

export interface DirectMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderUsername: string;
  text: string;
  createdAt: number;
  read: boolean;
  readBy?: string[];
}

export interface FollowRecord {
  id: string;
  followerId: string;
  followingId: string;
  createdAt: number;
}

export interface FollowRequestRecord {
  id: string;
  requesterId: string;
  targetId: string;
  requesterUsername: string;
  requesterDisplayName: string;
  requesterAvatarSymbol: UserProfile['avatarSymbol'];
  requesterAvatarColor: UserProfile['avatarColor'];
  requesterAvatarUrl?: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: number;
}

export interface ReportItem {
  id: string;
  reporterId: string;
  reporterUsername: string;
  targetType: 'post' | 'comment' | 'user';
  targetId: string;
  targetAuthorId?: string;
  targetAuthorUsername?: string;
  targetSnippet?: string;
  reason: 'spam' | 'harassment' | 'hate_speech' | 'impersonation' | 'misinformation' | 'other';
  explanation?: string;
  status: 'pending' | 'resolved' | 'dismissed';
  resolvedBy?: string;
  resolvedAt?: number;
  actionTaken?: string;
  createdAt: number;
}

export interface AdminAuditLog {
  id: string;
  adminId: string;
  adminUsername: string;
  action: string;
  targetId: string;
  details: string;
  timestamp: number;
}

export interface PlatformAnnouncement {
  id: string;
  title: string;
  content: string;
  type: 'info' | 'maintenance' | 'feature' | 'alert';
  active: boolean;
  createdAt: number;
  createdBy: string;
}

export interface PlatformSettings {
  /** Admin-configured one-time profile verification fee in BDT. */
  verificationFee?: number;
  bKashPaymentNumber?: string;
  nagadPaymentNumber?: string;
  verificationPaymentInstructions?: string;
  postCharLimit: number;
  allowRegistrations: boolean;
  defaultPostPrivacy: 'public' | 'private';
  allowFollowRequests: boolean;
  requireEmailVerification: boolean;
  maintenanceMode: boolean;
  /** Global lock screen shown to non-admin users when enabled. */
  serviceMode?: 'normal' | 'maintenance' | 'closed' | 'server_error' | 'not_found' | 'try_again';
  serviceModeMessage?: string;
  /** Daily recurring close/open window, expressed as local HH:mm values. */
  scheduledServiceMode?: 'maintenance' | 'closed';
  dailyScheduleEnabled?: boolean;
  dailyCloseTime?: string;
  dailyOpenTime?: string;
  /** IANA timezone captured from the admin browser when saving the daily schedule. */
  dailyTimezone?: string;
  /** When enabled, scheduled close/open times override manual service mode. Epoch milliseconds. */
  scheduledServiceEnabled?: boolean;
  serviceCloseAt?: number;
  serviceOpenAt?: number;
  /** Optional screen-specific absolute epoch-ms countdown targets. */
  maintenanceEndAt?: number;
  appClosedReopenAt?: number;
  monetagEnabled?: boolean;
  monetagZoneId?: string;
  monetagScriptUrl?: string;
  /** Full ad snippet copied from the Monetag dashboard. Only trusted admins should edit this. */
  monetagAdCode?: string;
  /** Optional HTTPS link to the latest downloadable app package/release. */
  appUpdateEnabled?: boolean;
  appUpdateUrl?: string;
  appUpdateVersion?: string;
  /** Minimum Android versionCode required to continue using the app. */
  appUpdateVersionCode?: number;
  appUpdateNotes?: string;
  sponsorAdsEnabled?: boolean;
  sponsorClickAdsEnabled?: boolean;
  sponsorAdCode?: string;
}
