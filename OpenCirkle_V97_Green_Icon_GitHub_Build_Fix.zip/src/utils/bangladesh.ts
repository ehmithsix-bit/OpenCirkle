/** Bangladesh-focused formatting helpers. UI language remains English. */
export const BANGLADESH_TIME_ZONE = 'Asia/Dhaka';
export const BANGLADESH_LOCALE = 'en-BD';

export function formatDhakaDateTime(value: string | number | Date, options: Intl.DateTimeFormatOptions = {}): string {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat(BANGLADESH_LOCALE, { timeZone: BANGLADESH_TIME_ZONE, dateStyle: 'medium', timeStyle: 'short', ...options }).format(date);
}
export function formatDhakaDate(value: string | number | Date, options: Intl.DateTimeFormatOptions = {}): string {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat(BANGLADESH_LOCALE, { timeZone: BANGLADESH_TIME_ZONE, dateStyle: 'medium', ...options }).format(date);
}
export function formatDhakaTime(value: string | number | Date, options: Intl.DateTimeFormatOptions = {}): string {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat(BANGLADESH_LOCALE, { timeZone: BANGLADESH_TIME_ZONE, hour: '2-digit', minute: '2-digit', ...options }).format(date);
}
export function formatBDT(value: number, options: Intl.NumberFormatOptions = {}): string {
  return new Intl.NumberFormat(BANGLADESH_LOCALE, { style: 'currency', currency: 'BDT', maximumFractionDigits: 2, ...options }).format(Number.isFinite(value) ? value : 0);
}
/** Accepts local 01XXXXXXXXX or international +8801XXXXXXXXX Bangladesh mobile format. */
export function isBangladeshMobile(value: string): boolean {
  const digits = value.replace(/[\s()-]/g, '');
  return /^(?:\+?8801[3-9]\d{8}|01[3-9]\d{8})$/.test(digits);
}
