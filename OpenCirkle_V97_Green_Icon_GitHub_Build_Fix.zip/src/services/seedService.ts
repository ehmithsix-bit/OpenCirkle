import { collection, getDocs, doc, setDoc, limit, query, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Post, UserProfile } from '../types';

export const STARTER_POSTS = [
  {
    content: "Welcome to OpenCirkle — a pure, text-first sanctuary designed for deep thought, crystal clarity, and unfiltered human communication. No media bloat, no algorithmic noise. Just ideas polished to crystalline perfection. #OpenCirkle #CrystalBlue #TextOnly",
    tags: ["opencirkle", "crystalblue", "textonly"],
  },
  {
    content: "The philosophy of the Crystal Crypt: true ideas endure without sensationalist imagery. When we strip away the visual noise, our prose is forced to be sharper, our questions more profound. What brought you to this node today? #Philosophy #DigitalMinimalism",
    tags: ["philosophy", "digitalminimalism"],
  },
  {
    content: "Crystalline lattices have fascinated mathematicians for centuries. Every vertex connects with mathematical certainty. In social graph theory, how do we design communities that balance high connectivity with privacy and safety? #NetworkTheory #Mathematics",
    tags: ["networktheory", "mathematics"],
  },
  {
    content: "Rule of discourse on OpenCirkle: Argue the premise, not the person. Write with the luminescence of sapphire under pressure. Share your favorite thought experiment below. #Discourse #OpenCirkle",
    tags: ["discourse", "opencirkle"],
  },
];

export const seedInitialPostsIfEmpty = async (currentUser: UserProfile): Promise<boolean> => {
  const postsQuery = query(collection(db, 'posts'), where('privacy', '==', 'public'), limit(1));
  const snap = await getDocs(postsQuery);

  if (!snap.empty) {
    return false; // Already has posts
  }

  const now = Date.now();
  for (let i = 0; i < STARTER_POSTS.length; i++) {
    const item = STARTER_POSTS[i];
    const postRef = doc(collection(db, 'posts'));
    const postData: Post = {
      id: postRef.id,
      authorId: currentUser.uid,
      authorUsername: currentUser.username,
      authorDisplayName: currentUser.displayName,
      authorVerified: Boolean(currentUser.verified),
      authorAvatarSymbol: currentUser.avatarSymbol,
      authorAvatarColor: currentUser.avatarColor,
      content: item.content,
      tags: item.tags,
      mentions: [],
      createdAt: now - (i * 1000 * 60 * 15),
      editedAt: null,
      likesCount: (4 - i) * 3,
      commentsCount: 2,
      repostsCount: 1,
      bookmarksCount: 2,
      isPinned: i === 0,
      isRepost: false,
      repostOf: null,
    };
    await setDoc(postRef, postData);
  }

  return true;
};
