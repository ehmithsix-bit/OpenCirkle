export const AI_COMMUNITY_SIZE = 20000;

const COMMUNITY_FIRST_NAMES = ['Rahim', 'Nusrat', 'Sabbir', 'Ayesha', 'Tanvir', 'Sumaiya', 'Mehedi', 'Mim', 'Fahim', 'Jannat', 'Arif', 'Tasnim', 'Imran', 'Farzana', 'Rafi', 'Sadia', 'Sakib', 'Mahi', 'Nabil', 'Tanjila', 'Adnan', 'Samira', 'Shakib', 'Ishrat', 'Raisa', 'Omar', 'Zarin', 'Mahmud', 'Nabila', 'Saif', 'Anika', 'Fardin', 'Lamisa', 'Rakib', 'Afia', 'Tahmid', 'Sanjida', 'Ashik', 'Nafisa', 'Zubair', 'Muntaha', 'Riyad', 'Tasmia', 'Abrar', 'Iffat', 'Shuvo', 'Purnima', 'Aminul', 'Sharmin', 'Rohan', 'Maliha', 'Farhan', 'Orin', 'Shahriar', 'Nishi', 'Arafat', 'Sohana', 'Tareq', 'Lamia', 'Mahir', 'Rumana', 'Faisal', 'Nusaira', 'Emon', 'Tuba', 'Afnan', 'Samiha', 'Jubayer', 'Afsana', 'Rashed', 'Elma', 'Anik', 'Nawar', 'Sajid', 'Muntasir', 'Rifat', 'Moumita', 'Ibrahim', 'Faria', 'Shafin', 'Rukhsar', 'Asif', 'Nayeem', 'Raihan', 'Muna', 'Shahadat', 'Tisha', 'Ahsan', 'Mahin', 'Zayan', 'Fariha', 'Siam', 'Mithila', 'Khalid', 'Tanjim', 'Rahat', 'Sabrina', 'Yusuf', 'Nafis', 'Nadia', 'Sifat', 'Mariya', 'Tanim', 'Ariyan', 'Ayman', 'Arohi', 'Shadman', 'Nuzhat', 'Rafiul', 'Jerin', 'Abir', 'Nishat', 'Jubeda', 'Samin', 'Tamim', 'Afsara', 'Mushfiq', 'Muntasim', 'Areeba', 'Naim', 'Sami', 'Zara', 'Tawhid', 'Morsalin', 'Rafsan', 'Kawsar', 'Mubarak', 'Rumman', 'Moin', 'Aminur', 'Faruq', 'Raihanul', 'Sabbirul', 'Aarav', 'Anaya', 'Ishaan', 'Maya', 'Aarohi', 'Kabir', 'Diya', 'Rehan', 'Kiara', 'Zain', 'Alina', 'Adam', 'Sara', 'Daniel', 'Olivia', 'Noah', 'Emma', 'Liam', 'Sophia', 'Ethan', 'Amelia', 'Lucas', 'Isabella', 'Mason', 'Ava', 'Leo', 'Mila', 'Arjun', 'Priya', 'Dev', 'Ira', 'Rayan', 'Lina', 'Ayaan', 'Inaya', 'Hamza', 'Zoya', 'Hana', 'Maryam', 'Amin', 'Layla', 'Amina', 'Tariq', 'Samir', 'Leila', 'Farid', 'Yasmin', 'Amir', 'Noor', 'Jamal', 'Salma', 'Rami', 'Dina', 'Bilal', 'Hiba', 'Karim', 'Laila', 'Zayd', 'Safiya', 'Idris', 'Mariam', 'Elias', 'Aaliyah', 'Kian', 'Aisha', 'Niko', 'Luca', 'Milan', 'Anya', 'Theo', 'Mira', 'Alex', 'Jamie', 'Jordan', 'Taylor', 'Morgan', 'Avery', 'Riley', 'Casey', 'Rowan', 'Skyler', 'Quinn'];
const COMMUNITY_LAST_NAMES = ['Jahan', 'Ahmed', 'Akter', 'Islam', 'Rahman', 'Chowdhury', 'Hossain', 'Khan', 'Sultana', 'Haque', 'Kabir', 'Mahmud', 'Uddin', 'Miah', 'Karim', 'Alam', 'Sarker', 'Das', 'Roy', 'Biswas', 'Molla', 'Talukder', 'Bhuiyan', 'Anwar', 'Rashid', 'Faruque', 'Nawaz', 'Shikder', 'Amin', 'Siddique', 'Kamal', 'Bashar', 'Jamal', 'Morshed', 'Noman', 'Rony', 'Saha', 'Paul', 'Dey', 'Ghosh', 'Sen', 'Dutta', 'Chakraborty', 'Mitra', 'Bhowmik', 'Karmakar', 'Mondal', 'Sheikh', 'Bari', 'Mannan', 'Sajjad', 'Shah', 'Zaman', 'Iqbal', 'Azad', 'Noor', 'Tasnim', 'Nahar', 'Arefin', 'Foysal', 'Sikder', 'Shuvo', 'Ahsan', 'Shahriar', 'Tarek', 'Munna', 'Sabbir', 'Muntasir', 'Jubayer', 'Nayeem', 'Rifat', 'Shakil', 'Sajib', 'Rashed', 'Riyad', 'Siam', 'Tanvir', 'Fahad', 'Adib', 'Araf', 'Ariyan', 'Tanim', 'Nafis', 'Tamim', 'Rahat', 'Sifat', 'Mahir', 'Nabil', 'Fardin', 'Sakib', 'Ayman', 'Zayan', 'Mushfiq', 'Shafin', 'Afnan', 'Ibrahim', 'Yusuf', 'Omar', 'Saif', 'Farhan', 'Faisal', 'Ashik', 'Rakib', 'Emon', 'Anik', 'Abir', 'Sajid', 'Mahin', 'Ahsanul', 'Muntasim', 'Shadman', 'Zubair', 'Tahmid', 'Adnan', 'Jamil', 'Niaz', 'Rafsan', 'Samin', 'Kawsar', 'Shahadat', 'Mubarak', 'Fahim', 'Aref', 'Morsalin', 'Tawhid', 'Nayeemul', 'Rumman', 'Aminur', 'Moin', 'Sajjadul', 'Faruq', 'Khalid', 'Raihanul', 'Rafiul', 'Sabbirul', 'Smith', 'Johnson', 'Brown', 'Wilson', 'Taylor', 'Anderson', 'Thomas', 'Jackson', 'White', 'Harris', 'Martin', 'Thompson', 'Garcia', 'Martinez', 'Robinson', 'Clark', 'Lewis', 'Walker', 'Hall', 'Allen', 'Young', 'King', 'Wright', 'Scott', 'Green', 'Baker', 'Adams', 'Nelson', 'Carter', 'Mitchell', 'Perez', 'Roberts', 'Turner', 'Phillips', 'Campbell', 'Parker', 'Evans', 'Edwards', 'Collins', 'Stewart', 'Morris', 'Rogers', 'Reed', 'Cook', 'Morgan', 'Bell', 'Murphy', 'Bailey', 'Rivera', 'Cooper', 'Richardson', 'Cox', 'Howard', 'Ward', 'Torres', 'Peterson', 'Gray', 'Ramirez', 'James', 'Watson', 'Brooks', 'Kelly', 'Sanders', 'Price', 'Bennett', 'Wood', 'Barnes', 'Ross', 'Henderson', 'Coleman', 'Jenkins', 'Perry', 'Powell', 'Long', 'Patterson', 'Hughes', 'Flores', 'Washington', 'Butler', 'Simmons', 'Foster', 'Gonzalez', 'Bryant', 'Alexander', 'Russell', 'Griffin', 'Diaz', 'Hayes'];
const COMMUNITY_REGIONS = ['Dhaka', 'Chattogram', 'Sylhet', 'Rajshahi', 'Khulna', 'Barishal', 'Rangpur', 'Cumilla', 'Mymensingh', 'Bogura', 'London', 'Toronto', 'New York', 'Kuala Lumpur', 'Dubai', 'Doha', 'Sydney', 'Singapore'];
const HANDLE_STYLES = ['dot', 'underscore', 'joined', 'its', 'writes', 'bd', 'x', 'the', 'reverse', 'daily'] as const;

// Interleave first names across the entire community instead of grouping thousands
// of profiles under the same first name. Every generated display name is a distinct
// first/last combination; handles are also unique and use varied natural styles.
const lastNameIndexAt = (i: number) => (i * 37 + Math.floor(i / COMMUNITY_FIRST_NAMES.length) * 17) % COMMUNITY_LAST_NAMES.length;
const nameAt = (i: number) => `${COMMUNITY_FIRST_NAMES[i % COMMUNITY_FIRST_NAMES.length]} ${COMMUNITY_LAST_NAMES[lastNameIndexAt(i)]}`;
const makeHandle = (i: number) => {
  const first = COMMUNITY_FIRST_NAMES[i % COMMUNITY_FIRST_NAMES.length].toLowerCase().replace(/[^a-z0-9]/g, '');
  const last = COMMUNITY_LAST_NAMES[lastNameIndexAt(i)].toLowerCase().replace(/[^a-z0-9]/g, '');
  const style = HANDLE_STYLES[i % HANDLE_STYLES.length];
  return style === 'dot' ? `${first}.${last}`
    : style === 'underscore' ? `${first}_${last}`
    : style === 'joined' ? `${first}${last}`
    : style === 'its' ? `its${first}${last}`
    : style === 'writes' ? `${first}writes${last}`
    : style === 'bd' ? `${first}${last}bd`
    : style === 'x' ? `${first}x${last}`
    : style === 'the' ? `the${first}${last}`
    : style === 'reverse' ? `${last}.${first}`
    : `${first}daily${last}`;
};
const usedHandles = new Set<string>();
const makeUniqueHandle = (i: number) => {
  const base = makeHandle(i);
  let candidate = base;
  let attempt = 0;
  const suffixes = ['bd', 'hq', 'online', 'notes', 'talks', 'daily', 'hub', 'world', 'space', 'life'];
  while (usedHandles.has(candidate)) {
    candidate = `${base}${suffixes[(i + attempt) % suffixes.length]}${attempt ? String.fromCharCode(97 + (attempt % 26)) : ''}`;
    attempt += 1;
  }
  usedHandles.add(candidate);
  return candidate;
};

export const AI_COMMUNITY_PROFILES = Array.from({ length: AI_COMMUNITY_SIZE }, (_, i) => ({
  id: `ai-community-${i + 1}`, username: makeUniqueHandle(i), name: nameAt(i), region: COMMUNITY_REGIONS[i % COMMUNITY_REGIONS.length], index: i, verified: (i % 200) === 0,
}));

const VIRTUAL_PROFILE_BY_USERNAME = new Map(AI_COMMUNITY_PROFILES.map(profile => [profile.username, profile]));
export const getVirtualCommunityProfile = (username: string) => VIRTUAL_PROFILE_BY_USERNAME.get(username.toLowerCase().replace(/^@/, ''));
