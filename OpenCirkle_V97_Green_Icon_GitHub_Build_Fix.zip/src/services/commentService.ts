import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  increment,
  updateDoc,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Comment, Post, UserProfile } from '../types';
import { sanitizeTextOnlyContent } from './postService';
import { createNotification } from './notificationService';

export const addComment = async (
  postId: string,
  author: UserProfile,
  rawContent: string
): Promise<Comment> => {
  const content = sanitizeTextOnlyContent(rawContent);
  if (content.length > 1000) {
    throw new Error('Comment cannot exceed 1000 characters.');
  }

  const postRef = doc(db, 'posts', postId);
  const postSnap = await getDoc(postRef);
  if (!postSnap.exists()) {
    throw new Error('Post not found.');
  }
  const postData = postSnap.data() as Post;

  const commentsCol = collection(db, 'comments');
  const commentRef = doc(commentsCol);
  const now = Date.now();

  const commentData: Comment = {
    id: commentRef.id,
    postId,
    authorId: author.uid,
    authorUsername: author.username,
    authorDisplayName: author.displayName,
    authorVerified: Boolean(author.verified),
    authorAvatarSymbol: author.avatarSymbol || 'gem',
    authorAvatarColor: author.avatarColor || 'electric',
    ...(typeof author.avatarUrl === 'string' && author.avatarUrl.trim() ? { authorAvatarUrl: author.avatarUrl.trim() } : {}),
    content,
    createdAt: now,
    editedAt: null,
  };

  await setDoc(commentRef, commentData);
  await updateDoc(postRef, {
    commentsCount: increment(1),
  });

  // Notify post author if not self
  if (postData.authorId !== author.uid) {
    await createNotification({
      recipientId: postData.authorId,
      senderId: author.uid,
      senderUsername: author.username,
      senderDisplayName: author.displayName,
      senderAvatarSymbol: author.avatarSymbol,
      senderAvatarColor: author.avatarColor,
      senderAvatarUrl: author.avatarUrl,
      type: 'comment',
      targetPostId: postId,
      textSnippet: content.slice(0, 80),
    });
  }

  return commentData;
};

export const deleteComment = async (
  commentId: string,
  postId: string,
  requesterUid: string,
  isModOrAdmin = false
): Promise<void> => {
  const commentRef = doc(db, 'comments', commentId);
  const snap = await getDoc(commentRef);
  if (!snap.exists()) return;

  const data = snap.data() as Comment;
  if (data.authorId !== requesterUid && !isModOrAdmin) {
    throw new Error('Unauthorized to delete this comment.');
  }

  await deleteDoc(commentRef);
  try {
    const postRef = doc(db, 'posts', postId);
    const postSnap = await getDoc(postRef);
    if (postSnap.exists()) {
      const currentCount = Number(postSnap.data().commentsCount || 0);
      await updateDoc(postRef, { commentsCount: Math.max(0, currentCount - 1) });
    }
  } catch (err) {
    console.warn('Could not decrement post comments count:', err);
  }
};

export const fetchPostComments = async (postId: string): Promise<Comment[]> => {
  try {
    const q = query(
      collection(db, 'comments'),
      where('postId', '==', postId),
      orderBy('createdAt', 'asc')
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as Comment);
  } catch (err) {
    console.warn('Falling back for post comments query without index:', err);
    const fallbackQ = query(
      collection(db, 'comments'),
      where('postId', '==', postId),
      limit(100)
    );
    const snap = await getDocs(fallbackQ);
    return snap.docs
      .map((d) => d.data() as Comment)
      .sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
  }
};
