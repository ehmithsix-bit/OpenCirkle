import {
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithCredential,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  deleteUser as firebaseDeleteUser,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
  runTransaction,
  deleteDoc,
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { Capacitor } from '@capacitor/core';
import { SocialLogin } from '@capgo/capacitor-social-login';
import { UserProfile, UserRole } from '../types';

const SUPER_ADMIN_EMAILS = ['rabiafroj43@gmail.com', 'admin@opencirkle.com'];

export const checkUsernameAvailable = async (username: string): Promise<boolean> => {
  const cleanUsername = username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
  if (!cleanUsername || cleanUsername.length < 3 || cleanUsername.length > 20) {
    return false;
  }
  
  const usernameRef = doc(db, 'usernames', cleanUsername);
  const snap = await getDoc(usernameRef);
  return !snap.exists();
};

export const registerUser = async (
  email: string,
  pass: string,
  rawUsername: string,
  displayName: string,
  countryCode = 'BD',
  languageCode = 'en'
): Promise<UserProfile> => {
  const cleanUsername = rawUsername.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
  if (cleanUsername.length < 3 || cleanUsername.length > 20) {
    throw new Error('Username must be 3-20 characters long and contain only letters, numbers, and underscores.');
  }

  // Atomically claim username and create user record
  const usernameRef = doc(db, 'usernames', cleanUsername);
  const usernameSnap = await getDoc(usernameRef);
  if (usernameSnap.exists()) {
    throw new Error('This username is already taken. Please choose another.');
  }

  const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
  const fbUser = userCredential.user;

  // Send verification email in the background
  try {
    await sendEmailVerification(fbUser);
  } catch (err) {
    console.warn('Could not send initial email verification:', err);
  }

  const isSuperAdmin = SUPER_ADMIN_EMAILS.includes(email.toLowerCase());
  const initialRole: UserRole = isSuperAdmin ? 'superadmin' : 'user';

  const newProfile: UserProfile = {
    uid: fbUser.uid,
    email: fbUser.email || email,
    username: cleanUsername,
    displayName: displayName.trim() || cleanUsername,
    bio: 'Exploring the crystalline depths of OpenCirkle.',
    joinedAt: Date.now(),
    followersCount: 0,
    followingCount: 0,
    postsCount: 0,
    likesCount: 0,
    verified: isSuperAdmin,
    isPrivate: false,
    role: initialRole,
    status: 'active',
    avatarSymbol: 'gem',
    avatarColor: 'electric',
    blockedUsers: [],
    mutedWords: [],
    themePreference: 'crystal_dark',
    notificationsEnabled: true,
    countryCode,
    languageCode,
  } as UserProfile;

  await setDoc(doc(db, 'users', fbUser.uid), newProfile);
  await setDoc(usernameRef, { uid: fbUser.uid, username: cleanUsername, createdAt: Date.now() });

  return newProfile;
};


let nativeGoogleInitialized = false;

export const registerWithGoogle = async (countryCode: string, languageCode: string): Promise<UserProfile> => {
  let fbUser: FirebaseUser;
  if (Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android') {
    // Android uses the native Google account chooser; the web OAuth popup is web-only.
    if (!nativeGoogleInitialized) {
      await SocialLogin.initialize({ google: { webClientId: '45625028258-a628p4d4pvak822hjq7gguo04njvll0i.apps.googleusercontent.com', mode: 'online' } });
      nativeGoogleInitialized = true;
    }
    let nativeResult: any;
    try {
      nativeResult = await SocialLogin.login({ provider: 'google', options: { scopes: ['email', 'profile'] } });
    } catch (error: any) {
      const code = String(error?.code || error?.message || '').toLowerCase();
      if (code.includes('cancel')) throw new Error('Google sign-in was cancelled.');
      if (code.includes('developer_error') || code.includes('10') || code.includes('12500')) {
        throw new Error('Google Sign-In configuration error. Confirm com.opencirkle.app, add the release/debug SHA-1 and SHA-256 fingerprints in Firebase, enable Google provider, then download the updated google-services.json.');
      }
      throw new Error(error?.message || 'Could not open Google Sign-In. Check your internet connection and Google Play services.');
    }
    const result = nativeResult?.result ?? nativeResult?.data ?? nativeResult;
    const idToken = result?.idToken ?? result?.authentication?.idToken ?? nativeResult?.idToken ?? nativeResult?.authentication?.idToken;
    if (!idToken || typeof idToken !== 'string') {
      throw new Error('Google did not return an ID token. Verify the Web OAuth client ID and Android SHA-1/SHA-256 fingerprints in Firebase.');
    }
    const firebaseCredential = GoogleAuthProvider.credential(idToken);
    fbUser = (await signInWithCredential(auth, firebaseCredential)).user;
  } else {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    fbUser = (await signInWithPopup(auth, provider)).user;
  }
  const userRef = doc(db, 'users', fbUser.uid);
  const existing = await getDoc(userRef);
  // Keep the Google account's current profile photo in sync on every Google sign-in.
  // Firebase may expose it on either the main user object or the Google provider data.
  const googlePhotoUrl = fbUser.photoURL || fbUser.providerData.find((provider) => provider.providerId === 'google.com')?.photoURL || undefined;
  if (existing.exists()) {
    const existingProfile = existing.data() as UserProfile;
    if (googlePhotoUrl && existingProfile.avatarUrl !== googlePhotoUrl) {
      await updateDoc(userRef, { avatarUrl: googlePhotoUrl });
      existingProfile.avatarUrl = googlePhotoUrl;
    }
    return existingProfile;
  }

  const emailBase = (fbUser.email || fbUser.displayName || 'google_user').split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 14) || 'google_user';
  let username = emailBase;
  let suffix = 1;
  while (!(await checkUsernameAvailable(username))) {
    username = `${emailBase}_${suffix++}`;
    if (suffix > 1000) throw new Error('Could not create a unique username. Please try again.');
  }
  const isSuperAdmin = SUPER_ADMIN_EMAILS.includes((fbUser.email || '').toLowerCase());
  const profile: UserProfile = {
    uid: fbUser.uid, email: fbUser.email || '', username,
    displayName: fbUser.displayName || username, avatarUrl: googlePhotoUrl, bio: 'Exploring the crystalline depths of OpenCirkle.',
    joinedAt: Date.now(), followersCount: 0, followingCount: 0, postsCount: 0, likesCount: 0,
    verified: isSuperAdmin, isPrivate: false, role: isSuperAdmin ? 'superadmin' : 'user', status: 'active',
    avatarSymbol: 'gem', avatarColor: 'electric', blockedUsers: [], mutedWords: [],
    themePreference: 'crystal_dark', notificationsEnabled: true,
    countryCode, languageCode,
  } as UserProfile;
  await setDoc(userRef, profile);
  await setDoc(doc(db, 'usernames', username), { uid: fbUser.uid, username, createdAt: Date.now() });
  return profile;
};

export const loginUser = async (email: string, pass: string): Promise<FirebaseUser> => {
  const userCredential = await signInWithEmailAndPassword(auth, email, pass);
  return userCredential.user;
};

export const logoutUser = async (): Promise<void> => {
  await signOut(auth);
};

export const resetPassword = async (email: string): Promise<void> => {
  await sendPasswordResetEmail(auth, email);
};

export const resendVerificationEmail = async (): Promise<void> => {
  if (auth.currentUser) {
    await sendEmailVerification(auth.currentUser);
  } else {
    throw new Error('No user is currently signed in.');
  }
};

export const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
  const docRef = doc(db, 'users', uid);
  const snap = await getDoc(docRef);
  if (!snap.exists()) return null;
  return snap.data() as UserProfile;
};

export const getUserByUsername = async (username: string): Promise<UserProfile | null> => {
  const clean = username.trim().toLowerCase().replace(/^@/, '');
  const q = query(collection(db, 'users'), where('username', '==', clean));
  const snap = await getDocs(q);
  if (snap.empty) return null;
  return snap.docs[0].data() as UserProfile;
};

export const updateUserProfile = async (
  uid: string,
  updates: Partial<Pick<UserProfile, 'displayName' | 'bio' | 'isPrivate' | 'avatarSymbol' | 'avatarColor' | 'mutedWords' | 'themePreference' | 'notificationsEnabled'>>
): Promise<void> => {
  const docRef = doc(db, 'users', uid);
  await updateDoc(docRef, updates);
};


export const changeUsername = async (uid: string, rawUsername: string): Promise<void> => {
  const clean = rawUsername.trim().toLowerCase().replace(/^@/, '').replace(/[^a-z0-9_]/g, '');
  if (clean.length < 3 || clean.length > 20) throw new Error('Username must be 3–20 characters (letters, numbers, underscores).');
  await runTransaction(db, async (tx) => {
    const userRef = doc(db, 'users', uid);
    const userSnap = await tx.get(userRef);
    if (!userSnap.exists()) throw new Error('User profile not found.');
    const data = userSnap.data();
    const old = String(data.username || '').toLowerCase();
    if (clean === old) return;
    const now = Date.now();
    const cooldownUntil = Number(data.usernameCooldownUntil || 0);
    if (cooldownUntil > now) {
      const days = Math.ceil((cooldownUntil - now) / 86400000);
      throw new Error(`Username change is locked. Try again in ${days} day(s).`);
    }
    const newRef = doc(db, 'usernames', clean);
    const newSnap = await tx.get(newRef);
    if (newSnap.exists() && newSnap.data().uid !== uid) throw new Error('This username is already taken.');
    const oldRef = old ? doc(db, 'usernames', old) : null;
    const count = Number(data.usernameChangeCount || 0) + 1;
    tx.set(newRef, { uid, username: clean, createdAt: now });
    if (oldRef) tx.delete(oldRef);
    tx.update(userRef, { username: clean, usernameChangeCount: count >= 2 ? 0 : count, usernameCooldownUntil: count >= 2 ? now + 60 * 24 * 60 * 60 * 1000 : 0 });
  });
};

export const toggleBlockUser = async (currentUid: string, targetUid: string): Promise<boolean> => {
  const userRef = doc(db, 'users', currentUid);
  const snap = await getDoc(userRef);
  if (!snap.exists()) return false;
  
  const profile = snap.data() as UserProfile;
  const currentBlocked = profile.blockedUsers || [];
  const isBlocked = currentBlocked.includes(targetUid);
  
  const newBlocked = isBlocked
    ? currentBlocked.filter((id) => id !== targetUid)
    : [...currentBlocked, targetUid];

  await updateDoc(userRef, { blockedUsers: newBlocked });
  return !isBlocked;
};

export const deactivateAccount = async (uid: string): Promise<void> => {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, { status: 'suspended' });
  await signOut(auth);
};

export const deleteUserAccount = async (uid: string): Promise<void> => {
  const user = auth.currentUser;
  if (!user || user.uid !== uid) {
    throw new Error('Unauthorized account deletion attempt.');
  }

  // Get user profile to release username
  const userDoc = await getDoc(doc(db, 'users', uid));
  if (userDoc.exists()) {
    const data = userDoc.data() as UserProfile;
    if (data.username) {
      await updateDoc(doc(db, 'usernames', data.username), { released: true });
    }
  }

  // Mark account as deleted/banned in firestore
  await updateDoc(doc(db, 'users', uid), { status: 'banned', bio: '[Account Deleted]' });
  
  // Delete from firebase auth
  await firebaseDeleteUser(user);
};
