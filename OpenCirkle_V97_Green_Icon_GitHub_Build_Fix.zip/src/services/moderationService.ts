import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { AdminAuditLog, PlatformAnnouncement, PlatformSettings, ReportItem, UserProfile, UserRole } from '../types';

export const submitReport = async ({
  reporter,
  targetType,
  targetId,
  targetAuthorId,
  targetAuthorUsername,
  targetSnippet,
  reason,
  explanation,
}: {
  reporter: UserProfile;
  targetType: 'post' | 'comment' | 'user';
  targetId: string;
  targetAuthorId?: string;
  targetAuthorUsername?: string;
  targetSnippet?: string;
  reason: ReportItem['reason'];
  explanation?: string;
}): Promise<void> => {
  // Check if reporter already reported this exact target
  const checkQ = query(
    collection(db, 'reports'),
    where('reporterId', '==', reporter.uid),
    where('targetId', '==', targetId)
  );
  const snap = await getDocs(checkQ);
  if (!snap.empty) {
    throw new Error('You have already submitted a report for this content.');
  }

  const reportRef = doc(collection(db, 'reports'));
  const reportData: ReportItem = {
    id: reportRef.id,
    reporterId: reporter.uid,
    reporterUsername: reporter.username,
    targetType,
    targetId,
    targetAuthorId: targetAuthorId || '',
    targetAuthorUsername: targetAuthorUsername || '',
    targetSnippet: targetSnippet ? targetSnippet.slice(0, 150) : '',
    reason,
    explanation: explanation ? explanation.slice(0, 500) : '',
    status: 'pending',
    createdAt: Date.now(),
  };

  await setDoc(reportRef, reportData);
};

export const fetchPendingReports = async (): Promise<ReportItem[]> => {
  try {
    const q = query(
      collection(db, 'reports'),
      where('status', '==', 'pending'),
      limit(50)
    );
    const snap = await getDocs(q);
    const list = snap.docs.map((d) => ({ ...(d.data() as ReportItem), id: d.id }));
    return list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  } catch (err) {
    console.warn('Error fetching pending reports:', err);
    return [];
  }
};

export const resolveReport = async (
  reportId: string,
  admin: UserProfile,
  status: 'resolved' | 'dismissed',
  actionTaken?: string
): Promise<void> => {
  const ref = doc(db, 'reports', reportId);
  await updateDoc(ref, {
    status,
    resolvedBy: admin.username,
    resolvedAt: Date.now(),
    actionTaken: actionTaken || status,
  });

  await logAdminAction(
    admin,
    `REPORT_${status.toUpperCase()}`,
    reportId,
    `Resolved report ${reportId} as ${status}. Action: ${actionTaken || 'None'}`
  );
};

export const updateUserModerationStatus = async (
  admin: UserProfile,
  targetUserId: string,
  newStatus: 'active' | 'suspended' | 'banned'
): Promise<void> => {
  const userRef = doc(db, 'users', targetUserId);
  await updateDoc(userRef, { status: newStatus });

  await logAdminAction(
    admin,
    `USER_${newStatus.toUpperCase()}`,
    targetUserId,
    `Changed user status to ${newStatus}`
  );
};

export const toggleUserVerification = async (
  admin: UserProfile,
  targetUserId: string,
  verified: boolean
): Promise<void> => {
  const userRef = doc(db, 'users', targetUserId);
  await updateDoc(userRef, { verified });

  await logAdminAction(
    admin,
    verified ? 'USER_VERIFIED' : 'USER_UNVERIFIED',
    targetUserId,
    `Set verified status to ${verified}`
  );
};

export const updateUserRole = async (
  superAdmin: UserProfile,
  targetUserId: string,
  newRole: UserRole
): Promise<void> => {
  if (superAdmin.role !== 'superadmin' && superAdmin.email !== 'rabiafroj43@gmail.com') {
    throw new Error('Only the Super Admin may assign or revoke privileged roles.');
  }

  // Prevent demoting the primary super admin
  const targetUserSnap = await getDoc(doc(db, 'users', targetUserId));
  if (targetUserSnap.exists()) {
    const target = targetUserSnap.data() as UserProfile;
    if (target.email === 'rabiafroj43@gmail.com' && newRole !== 'superadmin') {
      throw new Error('Cannot demote the primary Super Admin account.');
    }
  }

  await updateDoc(doc(db, 'users', targetUserId), { role: newRole });

  await logAdminAction(
    superAdmin,
    'ROLE_CHANGED',
    targetUserId,
    `Updated role to ${newRole}`
  );
};

export const logAdminAction = async (
  admin: UserProfile,
  action: string,
  targetId: string,
  details: string
): Promise<void> => {
  const logRef = doc(collection(db, 'adminAuditLogs'));
  const logData: AdminAuditLog = {
    id: logRef.id,
    adminId: admin.uid,
    adminUsername: admin.username,
    action,
    targetId,
    details,
    timestamp: Date.now(),
  };
  await setDoc(logRef, logData);
};

export const fetchAdminAuditLogs = async (limitCount = 30): Promise<AdminAuditLog[]> => {
  const q = query(
    collection(db, 'adminAuditLogs'),
    orderBy('timestamp', 'desc'),
    limit(limitCount)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as AdminAuditLog);
};

export const fetchPlatformSettings = async (): Promise<PlatformSettings> => {
  const ref = doc(db, 'platformSettings', 'global');
  const snap = await getDoc(ref);
  if (snap.exists()) {
    return snap.data() as PlatformSettings;
  }
  const defaultSettings: PlatformSettings = {
    postCharLimit: 5000,
    allowRegistrations: true,
    defaultPostPrivacy: 'public',
    allowFollowRequests: true,
    requireEmailVerification: false,
    maintenanceMode: false,
    serviceMode: 'normal',
    serviceModeMessage: 'We are improving OpenCirkle. Please try again shortly.',
    scheduledServiceEnabled: false,
    serviceCloseAt: 0,
    serviceOpenAt: 0,
    scheduledServiceMode: 'maintenance',
    dailyScheduleEnabled: false,
    dailyCloseTime: '',
    dailyOpenTime: '',
    monetagEnabled: false,
    monetagZoneId: '',
    monetagScriptUrl: '',
    monetagAdCode: '',
    appUpdateEnabled: false,
    appUpdateUrl: '',
    appUpdateVersion: '',
    appUpdateVersionCode: 0,
    appUpdateNotes: '',
  };
  await setDoc(ref, defaultSettings);
  return defaultSettings;
};

export const updatePlatformSettings = async (
  admin: UserProfile,
  settings: Partial<PlatformSettings>
): Promise<void> => {
  const ref = doc(db, 'platformSettings', 'global');
  await updateDoc(ref, settings);

  await logAdminAction(
    admin,
    'PLATFORM_SETTINGS_UPDATED',
    'global',
    `Updated platform settings: ${JSON.stringify(settings)}`
  );
};

export const createAnnouncement = async (
  admin: UserProfile,
  title: string,
  content: string,
  type: PlatformAnnouncement['type']
): Promise<PlatformAnnouncement> => {
  const ref = doc(collection(db, 'announcements'));
  const announcement: PlatformAnnouncement = {
    id: ref.id,
    title,
    content,
    type,
    active: true,
    createdAt: Date.now(),
    createdBy: admin.username,
  };
  await setDoc(ref, announcement);
  await logAdminAction(admin, 'ANNOUNCEMENT_CREATED', ref.id, `Created announcement: ${title}`);
  return announcement;
};

export const fetchActiveAnnouncements = async (): Promise<PlatformAnnouncement[]> => {
  try {
    const q = query(
      collection(db, 'announcements'),
      limit(25)
    );
    const snap = await getDocs(q);
    const list = snap.docs.map((d) => ({ ...(d.data() as PlatformAnnouncement), id: d.id }));
    return list
      .filter((a) => a.active)
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
      .slice(0, 5);
  } catch (err) {
    console.warn('Error fetching active announcements:', err);
    return [];
  }
};

export const fetchAdminAnalytics = async (): Promise<{
  totalUsers: number;
  totalPosts: number;
  pendingReports: number;
  activeAnnouncements: number;
}> => {
  try {
    const [usersSnap, postsSnap, reportsSnap, announcementsSnap] = await Promise.all([
      getDocs(query(collection(db, 'users'), limit(500))).catch(() => ({ size: 0 })),
      getDocs(query(collection(db, 'posts'), limit(500))).catch(() => ({ size: 0 })),
      getDocs(query(collection(db, 'reports'), where('status', '==', 'pending'), limit(100))).catch(() => ({ size: 0 })),
      getDocs(query(collection(db, 'announcements'), limit(100))).catch(() => ({ size: 0 })),
    ]);

    return {
      totalUsers: usersSnap.size,
      totalPosts: postsSnap.size,
      pendingReports: reportsSnap.size,
      activeAnnouncements: announcementsSnap.size,
    };
  } catch (err) {
    console.warn('Error fetching analytics:', err);
    return {
      totalUsers: 0,
      totalPosts: 0,
      pendingReports: 0,
      activeAnnouncements: 0,
    };
  }
};
