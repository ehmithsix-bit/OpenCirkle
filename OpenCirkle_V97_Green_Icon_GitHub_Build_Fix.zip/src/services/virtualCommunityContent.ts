/** Deterministic, varied sample content for locally-rendered community personas.
 * These are illustrative community posts, not live news or claims from real users.
 */
const CONTENT_BANK = [
  { category: 'Technology', posts: [
    'ফোনে অপ্রয়োজনীয় notification বন্ধ করার পর মনোযোগ অনেক বেড়েছে। কোন app-এর notification তোমরা সবসময় off রাখো?',
    'AI tools কাজ দ্রুত করে, কিন্তু output যাচাই না করে publish করা ঠিক না। তোমাদের favourite productivity tool কোনটা?',
    'পুরোনো laptop-এ lightweight Linux ব্যবহার করেছেন কেউ? দৈনন্দিন browsing আর writing-এর জন্য কেমন experience?',
    'Password manager ব্যবহার শুরু করেছি। আলাদা আলাদা password মনে রাখার ঝামেলা অনেক কমেছে। তোমরা কোন পদ্ধতি follow করো?',
  ]},
  { category: 'Sports', posts: [
    'শেষ কয়েক মিনিটের ম্যাচই অনেক সময় পুরো tournament-এর গল্প বদলে দেয়। তোমাদের দেখা সবচেয়ে memorable comeback কোনটি?',
    'ফুটবলে শুধু গোল নয়—midfield control আর off-the-ball movement-ও ম্যাচ জেতায়। তোমাদের favourite playmaker কে?',
    'ক্রিকেটে powerplay strategy নিয়ে মতভেদ থাকতেই পারে। আগে wicket বাঁচানো, নাকি শুরু থেকেই attack?',
    'একটা ভালো sports documentary পুরো খেলাটাকে নতুনভাবে দেখতে শেখায়। সাম্প্রতিক সময়ে কোনটা দেখেছ?',
  ]},
  { category: 'Daily life', posts: [
    'আজ একটা ছোট experiment করলাম—সকালে ঘুম থেকে উঠে প্রথম ৩০ মিনিট social media খুলিনি। দিনটা বেশ focused গেছে।',
    'ব্যস্ত দিনের মাঝে নিজের জন্য ১৫ মিনিট রাখা luxury না, দরকার। তোমরা কীভাবে ছোট break নাও?',
    'আজকের সবচেয়ে ভালো মুহূর্তটা খুব সাধারণ ছিল: রাস্তার পাশের চায়ের দোকানে পুরোনো বন্ধুর সঙ্গে দেখা।',
    'কাজের তালিকা ছোট রাখলে শেষ করার satisfaction-টা আলাদা। তোমাদের daily planning method কী?',
  ]},
  { category: 'Question', posts: [
    'একটা প্রশ্ন: নতুন কিছু শেখার সময় video tutorial ভালো লাগে, নাকি লিখিত guide? কেন?',
    'যদি এক মাসের জন্য যেকোনো একটি skill শেখার সুযোগ পাও, কোন skill বেছে নেবে?',
    'তোমাদের মতে online community-কে সত্যিকারের helpful করে তোলে কোন জিনিসটা?',
    'একটা app feature বেছে নিতে হলে—clean design, speed, নাকি privacy—কোনটাকে আগে রাখবে?',
  ]},
  { category: 'Opinion', posts: [
    'আমার মনে হয় internet-এ দ্রুত reply দেওয়ার চেয়ে ভেবে উত্তর দেওয়া বেশি গুরুত্বপূর্ণ। একমত, নাকি দ্বিমত?',
    'সব trend follow করার দরকার নেই। নিজের কাজে লাগে এমন জিনিস বেছে নেওয়াই smart move.',
    'ভালো design মানে শুধু সুন্দর রং না; মানুষ যেন প্রথমবারেই বুঝতে পারে কোথায় কী আছে।',
    'কম comment মানেই খারাপ discussion নয়। কয়েকটি thoughtful reply-ও অনেক মূল্যবান হতে পারে।',
  ]},
  { category: 'Books', posts: [
    'বই পড়ার সময় interesting line আলাদা করে note রাখার অভ্যাস করছি। পরে ফিরে দেখলে নিজের চিন্তার পরিবর্তন বোঝা যায়।',
    'শেষ কোন বইটা তোমাকে নতুনভাবে ভাবতে বাধ্য করেছে? spoiler ছাড়া নামটা বলো।',
    'কাগজের বইয়ের আলাদা অনুভূতি আছে, তবে e-reader-এ library সঙ্গে রাখা যায়—দুটোরই সুবিধা আছে।',
    'আজ fiction পড়তে ইচ্ছে করছে। ছোট, engaging কোনো উপন্যাস recommend করবে?',
  ]},
  { category: 'Food', posts: [
    'বৃষ্টির দিনে খিচুড়ি আর ডিমভাজি—এর চেয়ে simple comfort food আর কী হতে পারে? তোমাদের rainy-day favourite কী?',
    'নতুন একটা local cafe try করলাম। ambience ভালো হলে খাবারের experience-টাও অন্যরকম লাগে।',
    'চা নাকি coffee? আমি mood অনুযায়ী দুটোই খাই, তবে বিকেলের চায়ের জায়গা আলাদা।',
    'ঘরে রান্না করা খাবারের সবচেয়ে ভালো দিক হলো নিজের মতো করে flavour adjust করা। তোমাদের signature dish কী?',
  ]},
  { category: 'Travel', posts: [
    'একদিনের short trip-এর জন্য খুব দূরে যাওয়ার দরকার নেই। কাছের কোনো নদী বা সবুজ জায়গাও মন ভালো করে দেয়।',
    'Travel plan করার সময় itinerary-তে কিছু free time রাখি। সবকিছু schedule করলে জায়গাটা অনুভব করার সময়ই থাকে না।',
    'বাংলাদেশের কোন জায়গায় আবার যেতে ইচ্ছে করে? আমার list-এ এখনো কয়েকটা পাহাড়ি route বাকি।',
    'একটা ভালো travel memory অনেক সময় ছবির চেয়ে ছোট কোনো ঘটনা হয়ে থাকে। তোমাদের এমন memory আছে?',
  ]},
  { category: 'Entertainment', posts: [
    'গত রাতে একটা thriller দেখলাম—শেষের twist নিয়ে এখনো ভাবছি। spoiler না দিয়ে ভালো mystery recommend করো।',
    'পুরোনো গান আবার শুনলে নির্দিষ্ট সময়ের কথা মনে পড়ে যায়। তোমাদের nostalgia playlist-এ কোন গান আছে?',
    'একটা series শুরু করার আগে episode count দেখি। খুব লম্বা হলে weekend plan বদলে যায়!',
    'Cinema hall-এর big-screen experience এখনো আলাদা। শেষ কোন movie theatre-এ দেখেছ?',
  ]},
  { category: 'Education', posts: [
    'একটানা অনেকক্ষণ পড়ার চেয়ে ছোট focused session আমার জন্য বেশি কাজ করে। তোমাদের study routine কেমন?',
    'কোনো topic বুঝতে না পারলে নিজের ভাষায় explain করার চেষ্টা করি। এতে gap-গুলো ধরা পড়ে।',
    'পরীক্ষার preparation-এ শুধু পড়া নয়, revision schedule-ও equally important.',
    'Free online course দিয়ে নতুন subject explore করা সহজ হয়েছে। ভালো learning resource থাকলে share করো।',
  ]},
  { category: 'Career', posts: [
    'Portfolio-তে শুধু final result না, problem-solving process-টাও দেখানো উচিত—এটা recently বুঝলাম।',
    'কাজের feedback personal ভাবে না নিয়ে improvement-এর জায়গা হিসেবে দেখার চেষ্টা করছি। সহজ নয়, কিন্তু useful.',
    'Remote work-এ clear communication অনেক misunderstanding বাঁচায়। তোমাদের team-এর best practice কী?',
    'নতুন career শুরু করলে perfect হওয়ার অপেক্ষা না করে ছোট project দিয়ে শুরু করাই ভালো মনে হয়।',
  ]},
  { category: 'News & Media', posts: [
    'কোনো headline share করার আগে publication date আর original source দেখে নেওয়া জরুরি। পুরোনো খবর নতুন করে ছড়িয়ে পড়তে পারে।',
    'একই ঘটনার coverage কয়েকটি outlet-এ পড়লে framing-এর পার্থক্য বোঝা যায়। তোমরা news verify করো কীভাবে?',
    'আজকের feed-এ একটা interesting policy discussion দেখলাম। মত দেওয়ার আগে primary document পড়া উচিত বলে মনে করি।',
    'Breaking label দেখলেই সব তথ্য confirmed ধরে নেওয়া ঠিক নয়। update আর verified fact আলাদা করে দেখা দরকার।',
  ]},
  { category: 'Lifestyle', posts: [
    'ঘর গুছিয়ে রাখার ছোট routine দিনের শেষে stress কমায়। তোমাদের সবচেয়ে useful home habit কোনটা?',
    'Weekend-এ কিছু সময় offline থাকা surprisingly refreshing. সবসময় connected থাকারও একটা ক্লান্তি আছে।',
    'আজ হাঁটতে বের হয়ে বুঝলাম একই রাস্তা প্রতিদিন দেখলেও নতুন কিছু চোখে পড়তে পারে।',
    'কম জিনিস কিনে প্রয়োজনীয় জিনিস ভালোভাবে ব্যবহার করা—এই approach-টা adopt করার চেষ্টা করছি।',
  ]},
  { category: 'Photography', posts: [
    'আজ বিকেলের আলোটা অসাধারণ ছিল। golden hour-এ mobile camera দিয়েও সুন্দর frame পাওয়া যায়।',
    'ছবি তোলার সময় subject-এর চেয়ে background কখনো কখনো বেশি গুরুত্বপূর্ণ হয়ে যায়।',
    'Street photography-তে candid moment capture করতে patience লাগে। তোমাদের favourite photography style কী?',
    'একই জায়গা সকাল আর সন্ধ্যায় photograph করলে mood পুরো বদলে যায়—light-ই আসল magic.',
  ]},
  { category: 'Finance', posts: [
    'মাসের শুরুতে খরচের একটা simple list রাখলে কোথায় টাকা যাচ্ছে বোঝা যায়। fancy app দরকার হয় না।',
    'কেনার আগে ২৪ ঘণ্টা অপেক্ষা করার habit impulsive shopping কমাতে সাহায্য করছে।',
    'Budget করা মানে সব আনন্দ বাদ দেওয়া নয়; বরং কোন খরচটা priority সেটা বোঝা।',
    'কোনো financial advice follow করার আগে নিজের situation আর reliable source যাচাই করা উচিত।',
  ]},
  { category: 'Community', posts: [
    'নতুন কাউকে community-তে welcome জানানো ছোট কাজ, কিন্তু এতে জায়গাটা অনেক বেশি friendly লাগে।',
    'Disagreement থাকলেও respectful থাকা যায়। ভালো discussion-এর জন্য সেটাই সবচেয়ে জরুরি।',
    'আজ একজনের helpful comment থেকে নতুন একটা resource পেলাম। এমন exchange-ই social platform-কে valuable করে।',
    'তোমাদের এলাকায় কোন local initiative-টা আরও মানুষের support পাওয়া উচিত বলে মনে হয়?',
  ]},
];

const VOICES = [
  (s: string) => s,
  (s: string) => `একটা personal note ✍️\n${s}`,
  (s: string) => `${s}\n\nতোমাদের অভিজ্ঞতাও শুনতে চাই।`,
  (s: string) => `আজকের ভাবনা — ${s}`,
  (s: string) => `${s}\n\nShort version: ছোট ছোট অভ্যাসই বড় difference তৈরি করে।`,
  (s: string) => `বন্ধুরা, ${s.charAt(0).toLowerCase()}${s.slice(1)}`,
  (s: string) => `${s}\n\nকেউ ভিন্নভাবে ভাবলে comments-এ বলো, আলোচনা করি।`,
  (s: string) => `📌 ${s}`,
  (s: string) => `${s}\n\nআজকের জন্য এটুকুই—ভালো থাকো সবাই।`,
  (s: string) => `একটা বিষয় share করি:\n${s}`,
];
const TAGS: Record<string, string[]> = {
  Technology: ['TechTalk', 'DigitalLife'], Sports: ['SportsTalk', 'GameDay'], 'Daily life': ['DailyMoments', 'Life'],
  Question: ['Question', 'Community'], Opinion: ['MyTake', 'Discussion'], Books: ['Reading', 'Books'],
  Food: ['FoodTalk', 'Foodie'], Travel: ['Travel', 'Explore'], Entertainment: ['Movies', 'Entertainment'],
  Education: ['Learning', 'Study'], Career: ['Career', 'WorkLife'], 'News & Media': ['MediaLiteracy', 'NewsDiscussion'],
  Lifestyle: ['Lifestyle', 'Wellbeing'], Photography: ['Photography', 'Creative'], Finance: ['MoneyHabits', 'PersonalFinance'],
  Community: ['Community', 'OpenCirkle'],
};

export const makeVirtualCommunityPostContent = (seed: number) => {
  const categoryIndex = Math.abs(seed * 7 + Math.floor(seed / 11)) % CONTENT_BANK.length;
  const category = CONTENT_BANK[categoryIndex];
  const postIndex = Math.abs(seed * 13 + Math.floor(seed / 7)) % category.posts.length;
  const voiceIndex = Math.abs(seed * 5 + Math.floor(seed / 3)) % VOICES.length;
  const base = category.posts[postIndex];
  const content = VOICES[voiceIndex](base);
  return { content, category: category.category, tags: TAGS[category.category] || ['Community'], sourceUrl: undefined as string | undefined };
};
