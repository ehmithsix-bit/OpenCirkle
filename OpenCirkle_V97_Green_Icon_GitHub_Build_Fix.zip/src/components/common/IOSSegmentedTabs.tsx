import React from 'react';

interface TabOption {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface IOSSegmentedTabsProps {
  options: TabOption[];
  activeId: string;
  onChange: (id: string) => void;
  className?: string;
}

export const IOSSegmentedTabs: React.FC<IOSSegmentedTabsProps> = ({
  options,
  activeId,
  onChange,
  className = '',
}) => {
  return (
    <div
      className={`relative p-1 rounded-full ios-liquid-glass-subtle border border-[#8DDCFF]/20 flex items-center justify-between ${className}`}
    >
      {options.map((opt) => {
        const isActive = activeId === opt.id;
        return (
          <button
            key={opt.id}
            onClick={() => onChange(opt.id)}
            className={`relative flex-1 py-1.5 px-3 rounded-full text-xs font-semibold ios-press transition-all flex items-center justify-center gap-1.5 z-10 ${
              isActive
                ? 'text-white shadow-[0_2px_12px_rgba(22,139,255,0.4)]'
                : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
            }`}
          >
            {isActive && (
              <span className="absolute inset-0 rounded-full bg-gradient-to-r from-[#0D47A1] to-[#168BFF] -z-10 animate-in fade-in zoom-in-95 duration-150 border border-[#8DDCFF]/30" />
            )}
            {opt.icon}
            <span className="truncate">{opt.label}</span>
          </button>
        );
      })}
    </div>
  );
};
