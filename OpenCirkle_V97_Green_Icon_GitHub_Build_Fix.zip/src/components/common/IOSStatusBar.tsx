import React, { useState, useEffect } from 'react';
import { Wifi, Battery } from 'lucide-react';

interface IOSStatusBarProps {
  className?: string;
}

export const IOSStatusBar: React.FC<IOSStatusBarProps> = ({ className = '' }) => {
  const [timeStr, setTimeStr] = useState('9:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('en-BD', { timeZone: 'Asia/Dhaka', hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div
      className={`w-full h-11 px-6 flex items-center justify-between text-xs text-[#F1F8FF] font-medium tracking-tight select-none pointer-events-none z-50 ${className}`}
    >
      {/* Left: Clock */}
      <span className="font-semibold text-xs tracking-tight text-[#F1F8FF]">
        {timeStr}
      </span>

      {/* Center: Dynamic Island Pill */}
      <div className="h-5 px-3 rounded-full bg-[#050A18]/90 border border-[#168BFF]/30 shadow-[0_0_12px_rgba(22,139,255,0.25)] flex items-center gap-1.5 pointer-events-auto">
        <span className="w-1.5 h-1.5 rounded-full bg-[#8DDCFF] animate-pulse" />
        <span className="text-[10px] font-mono text-[#8DDCFF] tracking-wider uppercase">
          OpenCirkle
        </span>
      </div>

      {/* Right: Cellular, WiFi, Battery */}
      <div className="flex items-center gap-2 text-[#F1F8FF]">
        {/* Cellular 4 bars */}
        <div className="flex items-end gap-0.5 h-3">
          <span className="w-0.5 h-1 bg-[#F1F8FF] rounded-xs" />
          <span className="w-0.5 h-1.5 bg-[#F1F8FF] rounded-xs" />
          <span className="w-0.5 h-2.5 bg-[#F1F8FF] rounded-xs" />
          <span className="w-0.5 h-3 bg-[#F1F8FF] rounded-xs" />
        </div>

        {/* WiFi */}
        <Wifi className="w-3.5 h-3.5" />

        {/* Battery */}
        <div className="flex items-center gap-0.5">
          <div className="w-5 h-2.5 rounded-[4px] border border-[#F1F8FF] p-0.5 flex items-center">
            <div className="w-3.5 h-full bg-[#8DDCFF] rounded-[2px]" />
          </div>
          <div className="w-0.5 h-1 bg-[#F1F8FF] rounded-r-xs" />
        </div>
      </div>
    </div>
  );
};
