import React from 'react';

type Props = { children: React.ReactNode; onRecover: () => void };
type State = { hasError: boolean };

/** Keeps a broken view from taking down the whole app shell. */
export class ViewErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('OpenCirkle view failed to render:', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <section className="mx-auto my-8 max-w-xl rounded-2xl border border-[#168BFF]/30 bg-[#071A38]/90 p-6 text-center shadow-[0_0_25px_rgba(22,139,255,0.12)]" role="alert">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full border border-[#8DDCFF]/40 bg-[#168BFF]/10 text-2xl text-[#8DDCFF]">!</div>
          <h2 className="text-lg font-bold text-[#F1F8FF]">This section couldn’t load</h2>
          <p className="mt-2 text-sm text-[#A8BCD7]">You can return to the home feed without refreshing the whole app.</p>
          <button type="button" onClick={this.props.onRecover} className="mt-5 rounded-full border border-[#8DDCFF]/40 bg-[#0D47A1] px-5 py-2 text-sm font-semibold text-white hover:bg-[#168BFF]">Back to Home</button>
        </section>
      );
    }
    return this.props.children;
  }
}
