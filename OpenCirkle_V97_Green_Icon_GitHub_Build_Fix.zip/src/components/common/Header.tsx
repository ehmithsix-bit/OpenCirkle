import React, { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { CrystalAvatar } from './CrystalAvatar';
import openCirkleLogo from '../../assets/opencirkle-logo.png';
import {
  Sparkles,
  PenSquare,
  LogIn,
  MessageSquare,
  ShieldCheck,
  Bookmark,
  Compass,
} from 'lucide-react';

interface HeaderProps {
  onOpenAuth: () => void;
  onOpenCompose: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unreadNotifsCount?: number;
  unreadMessagesCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenAuth,
  onOpenCompose,
  activeTab,
  setActiveTab,
  unreadNotifsCount = 0,
  unreadMessagesCount = 0,
}) => {
  const { currentUserProfile, isModerator } = useAuth();
  const [brandConfig, setBrandConfig] = useState<any>(() => { try { return JSON.parse(localStorage.getItem('oc-app-customization-cache') || 'null')?.branding || null; } catch { return null; } });
  const [searchAnimating, setSearchAnimating] = useState(false);
  const [bellAnimating, setBellAnimating] = useState(false);

  const openSearch = () => {
    setSearchAnimating(true);
    setActiveTab('explore');
    window.setTimeout(() => setSearchAnimating(false), 800);
  };
  const openNotifications = () => {
    setBellAnimating(true);
    setActiveTab('notifications');
    window.setTimeout(() => setBellAnimating(false), 800);
  };
  useEffect(() => onSnapshot(doc(db, 'platformSettings', 'global'), snap => {
    const c = snap.exists() ? snap.data()?.appCustomization : null;
    if (c?.schemaVersion === 1 && c?.status === 'published' && c.branding) {
      setBrandConfig(c.branding);
      try { localStorage.setItem('oc-app-customization-cache', JSON.stringify(c)); } catch {}
    }
  }, err => console.warn('Brand sync unavailable; using cached branding.', err)), []);

  return (
    <header data-oc-app-header="true" className="sticky top-0 z-30 w-full px-3 sm:px-6 md:px-8 py-2.5 transition-all">
      {/* iOS Liquid Glass Capsule Bar */}
      <div className="max-w-6xl mx-auto rounded-full ios-liquid-glass px-4 sm:px-6 py-2.5 flex items-center justify-between gap-3 shadow-[0_12px_36px_rgba(0,0,0,0.7),0_0_25px_rgba(22,139,255,0.2)] border border-[#8DDCFF]/30 backdrop-blur-2xl">
        {/* Zone 1: iOS Crystalline Brand Pill */}
        <button
          onClick={() => setActiveTab('feed')}
          className="flex items-center gap-0 text-left group shrink-0 focus:outline-none ios-press"
          aria-label="OpenCirkle Home"
        >
          <div className="relative w-11 h-11 shrink-0 p-0 group-hover:scale-105 transition-transform">
            <img src={brandConfig?.headerLogoUrl || brandConfig?.fallbackLogoUrl || openCirkleLogo} onError={(e) => { (e.currentTarget as HTMLImageElement).src = openCirkleLogo; }} alt="OpenCirkle logo" loading="eager" fetchPriority="high" decoding="async" className="w-full h-full object-contain" style={{width: `${Math.min(96, Math.max(20, Number(brandConfig?.headerLogoSize) || 44))}px`}} />
          </div>
          {brandConfig?.showHeaderName !== false && <div className="flex flex-col -ml-2.5">
            <span
              className="fx-lava text-base sm:text-lg font-extrabold tracking-tight whitespace-nowrap"
              data-text={brandConfig?.headerName || brandConfig?.appName || 'OpenCirkle'}
            >
              {brandConfig?.headerName || brandConfig?.appName || 'OpenCirkle'}
            </span>
            <span className="hidden sm:block text-[9px] font-mono text-[#8DDCFF]/70 tracking-widest uppercase -mt-1">
              Crystal Crypt
            </span>
          </div>}
        </button>

        {/* Zone 2: Desktop iOS Navigation Segmented Control */}
        <nav className="hidden md:flex items-center gap-1.5 p-1 rounded-full bg-[#050A18]/60 border border-[#168BFF]/20 text-xs font-medium">
          <button
            onClick={() => setActiveTab('feed')}
            className={`px-3.5 py-1.5 rounded-full transition-all ios-press ${
              activeTab === 'feed'
                ? 'bg-gradient-to-r from-[#0D47A1]/80 to-[#168BFF]/80 text-[#F1F8FF] shadow-[0_0_15px_rgba(22,139,255,0.5)] border border-[#8DDCFF]/30 font-semibold'
                : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
            }`}
          >
            Discourse
          </button>

          <button
            onClick={() => setActiveTab('explore')}
            className={`px-3.5 py-1.5 rounded-full transition-all ios-press ${
              activeTab === 'explore'
                ? 'bg-gradient-to-r from-[#0D47A1]/80 to-[#168BFF]/80 text-[#F1F8FF] shadow-[0_0_15px_rgba(22,139,255,0.5)] border border-[#8DDCFF]/30 font-semibold'
                : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
            }`}
          >
            Explore
          </button>

          {currentUserProfile && (
            <>
              <button
                onClick={() => setActiveTab('messages')}
                className={`relative px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 ios-press ${
                  activeTab === 'messages'
                    ? 'bg-gradient-to-r from-[#0D47A1]/80 to-[#168BFF]/80 text-[#F1F8FF] shadow-[0_0_15px_rgba(22,139,255,0.5)] border border-[#8DDCFF]/30 font-semibold'
                    : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
                }`}
              >
                <span>Crypt</span>
                {unreadMessagesCount > 0 && (
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-[#168BFF] text-white">
                    {unreadMessagesCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('bookmarks')}
                className={`px-3.5 py-1.5 rounded-full transition-all ios-press ${
                  activeTab === 'bookmarks'
                    ? 'bg-gradient-to-r from-[#0D47A1]/80 to-[#168BFF]/80 text-[#F1F8FF] shadow-[0_0_15px_rgba(22,139,255,0.5)] border border-[#8DDCFF]/30 font-semibold'
                    : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
                }`}
              >
                Vault
              </button>
            </>
          )}

          {isModerator && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`px-3.5 py-1.5 rounded-full transition-all flex items-center gap-1.5 ios-press ${
                activeTab === 'admin'
                  ? 'bg-gradient-to-r from-[#0D47A1]/80 to-[#168BFF]/80 text-[#F1F8FF] shadow-[0_0_15px_rgba(22,139,255,0.5)] border border-[#8DDCFF]/30 font-semibold'
                  : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#8DDCFF]" />
              <span>Admin</span>
            </button>
          )}
        </nav>

        {/* Zone 3: iOS Quick Action Group */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* KMF animated glass Search + Notifications actions */}
          <div className="oc-kmf-topbar-actions" aria-label="Quick actions">
            <button
              type="button"
              onClick={openSearch}
              className={`oc-kmf-topbar-btn oc-kmf-search-btn${searchAnimating ? ' anim-search' : ''}`}
              aria-label="Search"
              title="Search"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
            </button>

            {currentUserProfile && (
              <button
                type="button"
                onClick={openNotifications}
                className={`oc-kmf-topbar-btn oc-kmf-notification-btn${bellAnimating ? ' anim-bell' : ''}${activeTab === 'notifications' ? ' is-active' : ''}`}
                aria-label={`Notifications${unreadNotifsCount > 0 ? `, ${unreadNotifsCount} unread` : ''}`}
                title="Notifications"
              >
                <svg className="bell-body" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M10.268 21a2 2 0 0 0 3.464 0" />
                  <path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326" />
                </svg>
                {unreadNotifsCount > 0 && (
                  <span className="oc-kmf-notification-badge">{unreadNotifsCount > 99 ? '99+' : unreadNotifsCount}</span>
                )}
              </button>
            )}
          </div>


          {currentUserProfile ? (
            <div className="flex items-center gap-2">
              {/* iOS Publish Pill Button */}
              <button
                onClick={onOpenCompose}
                className="hidden sm:inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] via-[#168BFF] to-[#8DDCFF] rounded-full hover:shadow-[0_0_20px_rgba(22,139,255,0.6)] transition-all ios-press shadow-[0_0_15px_rgba(22,139,255,0.4)] whitespace-nowrap"
              >
                <PenSquare className="w-3.5 h-3.5" />
                <span>Publish</span>
              </button>

              {/* iOS Avatar Pill */}
              <button
                onClick={() => setActiveTab('profile')}
                className="flex items-center gap-2 p-0.5 rounded-full hover:ring-2 hover:ring-[#8DDCFF]/70 transition-all ios-press focus:outline-none"
                title={`Profile @${currentUserProfile.username}`}
              >
                <div className="p-0.5 rounded-full bg-gradient-to-tr from-[#168BFF] to-[#8DDCFF] shadow-[0_0_10px_rgba(22,139,255,0.5)]">
                  <CrystalAvatar
                    displayName={currentUserProfile.displayName}
                    username={currentUserProfile.username}
                    avatarSymbol={currentUserProfile.avatarSymbol}
                avatarUrl={currentUserProfile.avatarUrl}
                    avatarColor={currentUserProfile.avatarColor}
                    size="sm"
                    className="rounded-full"
                  />
                </div>
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 sm:px-4 sm:py-2 text-xs font-semibold text-[#F1F8FF] bg-[#071A38]/90 border border-[#8DDCFF]/40 rounded-full hover:border-[#8DDCFF] hover:bg-[#0D47A1]/50 transition-all shadow-[0_0_15px_rgba(22,139,255,0.3)] ios-press whitespace-nowrap"
            >
              <LogIn className="w-3.5 h-3.5 text-[#8DDCFF]" />
              <span>Enter</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
