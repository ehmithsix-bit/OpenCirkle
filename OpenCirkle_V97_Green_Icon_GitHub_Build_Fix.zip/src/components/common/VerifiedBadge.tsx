import React, { useEffect, useState } from 'react';
import verifiedBadgeImage from '../../assets/verified-badge.png';

type VerifiedBadgeProps = { className?: string; size?: 'sm' | 'md' | 'lg'; title?: string; placement?: 'displayName' | 'username' };
type BadgeConfig = { imageUrl?: string; sizePx?: number; gapPx?: number; offsetY?: number; placement?: 'displayName' | 'username' | 'both' };
const readConfig = (): BadgeConfig => { try { const c = JSON.parse(localStorage.getItem('oc-app-customization-cache') || 'null'); return c?.verifiedBadge || {}; } catch { return {}; } };
/** Blue verified badge. Admin-published URL/size/spacing settings apply live and fall back to the bundled artwork. */
export const VerifiedBadge: React.FC<VerifiedBadgeProps> = ({ className = '', size = 'md', title = 'Verified account', placement = 'displayName' }) => {
  const [cfg, setCfg] = useState<BadgeConfig>(readConfig);
  useEffect(() => { const update = (e: Event) => setCfg((e as CustomEvent).detail?.verifiedBadge || readConfig()); window.addEventListener('oc-app-customization-updated', update); return () => window.removeEventListener('oc-app-customization-updated', update); }, []);
  if (cfg.placement && cfg.placement !== 'both' && cfg.placement !== placement) return null;
  const defaults = { sm: 14, md: 18, lg: 24 };
  const px = Number(cfg.sizePx) >= 8 && Number(cfg.sizePx) <= 64 ? Number(cfg.sizePx) : defaults[size];
  const gap = Number(cfg.gapPx) >= 0 && Number(cfg.gapPx) <= 32 ? Number(cfg.gapPx) : 0;
  const offset = Number(cfg.offsetY) >= -20 && Number(cfg.offsetY) <= 20 ? Number(cfg.offsetY) : 0;
  const image = typeof cfg.imageUrl === 'string' && /^https:\/\//i.test(cfg.imageUrl) ? cfg.imageUrl : verifiedBadgeImage;
  return <img role="img" aria-label={title} title={title} src={image} onError={(e) => { e.currentTarget.src = verifiedBadgeImage; }} style={{ width: px, height: px, marginLeft: gap, transform: `translateY(${offset}px)` }} className={`inline-block shrink-0 object-contain ${className}`} />;
};
export default VerifiedBadge;
