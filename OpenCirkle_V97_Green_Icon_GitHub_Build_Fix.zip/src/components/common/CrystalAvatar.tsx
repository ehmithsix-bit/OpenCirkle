import React from 'react';
import { UserProfile } from '../../types';

interface CrystalAvatarProps {
  displayName?: string;
  username?: string;
  avatarSymbol?: UserProfile['avatarSymbol'];
  avatarColor?: UserProfile['avatarColor'];
  avatarUrl?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  interactive?: boolean;
  onClick?: () => void;
}

const colorThemes: Record<UserProfile['avatarColor'], { bg: string; border: string; glow: string; text: string; iconFill: string }> = {
  electric: {
    bg: 'from-[#0D47A1]/80 via-[#168BFF]/40 to-[#071A38]/90',
    border: 'border-[#168BFF]/60',
    glow: 'shadow-[0_0_15px_rgba(22,139,255,0.3)]',
    text: 'text-[#F1F8FF]',
    iconFill: '#8DDCFF',
  },
  ice: {
    bg: 'from-[#168BFF]/40 via-[#8DDCFF]/30 to-[#071A38]/90',
    border: 'border-[#8DDCFF]/60',
    glow: 'shadow-[0_0_15px_rgba(141,220,255,0.35)]',
    text: 'text-[#F1F8FF]',
    iconFill: '#8DDCFF',
  },
  sapphire: {
    bg: 'from-[#071A38] via-[#0D47A1]/60 to-[#050A18]',
    border: 'border-[#0D47A1]/80',
    glow: 'shadow-[0_0_15px_rgba(13,71,161,0.4)]',
    text: 'text-[#8DDCFF]',
    iconFill: '#168BFF',
  },
  cyan: {
    bg: 'from-[#006064]/70 via-[#00ACC1]/30 to-[#071A38]',
    border: 'border-[#26C6DA]/60',
    glow: 'shadow-[0_0_15px_rgba(38,198,218,0.3)]',
    text: 'text-[#E0F7FA]',
    iconFill: '#80DEEA',
  },
  neon: {
    bg: 'from-[#311B92]/70 via-[#7C4DFF]/30 to-[#050A18]',
    border: 'border-[#B388FF]/60',
    glow: 'shadow-[0_0_15px_rgba(179,136,255,0.35)]',
    text: 'text-[#EDE7F6]',
    iconFill: '#D1C4E9',
  },
};

const sizeClasses = {
  xs: 'w-6 h-6 text-[10px]',
  sm: 'w-8 h-8 text-xs',
  md: 'w-10 h-10 text-sm',
  lg: 'w-14 h-14 text-base font-semibold',
  xl: 'w-20 h-20 text-xl font-bold',
  '2xl': 'w-24 h-24 text-2xl font-bold',
};

const renderFacetSymbol = (symbol: UserProfile['avatarSymbol'], color: string) => {
  switch (symbol) {
    case 'gem':
    case 'diamond':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" className="w-1/2 h-1/2">
          <path d="M6 3h12l4 6-10 12L2 9z" />
          <path d="M2 9h20" />
          <path d="M10 3l-2 6 4 12 4-12-2-6" />
        </svg>
      );
    case 'prism':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" className="w-1/2 h-1/2">
          <polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2" />
          <line x1="12" y1="22" x2="12" y2="15.5" />
          <polyline points="22 8.5 12 15.5 2 8.5" />
        </svg>
      );
    case 'hexagon':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" className="w-1/2 h-1/2">
          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
        </svg>
      );
    case 'star':
    case 'sparkle':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" className="w-1/2 h-1/2">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
      );
    case 'shield':
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" className="w-1/2 h-1/2">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          <path d="M12 2v20" />
        </svg>
      );
    case 'orb':
    default:
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" className="w-1/2 h-1/2">
          <circle cx="12" cy="12" r="10" />
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
          <path d="M2 12h20" />
        </svg>
      );
  }
};

export const CrystalAvatar: React.FC<CrystalAvatarProps> = ({
  displayName = '',
  username = '',
  avatarSymbol = 'gem',
  avatarColor = 'electric',
  avatarUrl,
  size = 'md',
  className = '',
  interactive = false,
  onClick,
}) => {
  const theme = colorThemes[avatarColor] || colorThemes.electric;
  const initial = (displayName || username || 'O').charAt(0).toUpperCase();

  return (
    <div
      onClick={onClick}
      role={interactive ? 'button' : undefined}
      tabIndex={interactive ? 0 : undefined}
      className={`relative inline-flex items-center justify-center shrink-0 rounded-full bg-gradient-to-br ${theme.bg} ${theme.border} border ${theme.glow} ${sizeClasses[size]} ${
        interactive ? 'cursor-pointer transition-transform duration-200 hover:scale-105 active:scale-95' : ''
      } ${className}`}
      title={displayName ? `${displayName} (@${username})` : username}
    >
      {avatarUrl ? (
        <img src={avatarUrl} alt={displayName ? `${displayName} profile picture` : `${username} profile picture`} referrerPolicy="no-referrer" loading="lazy" className="absolute inset-0 w-full h-full rounded-[inherit] object-cover" onError={(event) => { event.currentTarget.style.display = 'none'; }} />
      ) : (
        <>
      {/* Crystalline subtle geometric facet background */}
      <div className="absolute inset-0 rounded-full opacity-25 bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.25),transparent_60%)] pointer-events-none" />

      {/* Primary indicator: display initial for smaller sizes or combo for large */}
      {size === 'xs' || size === 'sm' ? (
        <span className={`font-bold tracking-tight ${theme.text}`}>{initial}</span>
      ) : size === 'md' ? (
        <span className={`font-bold tracking-wider ${theme.text}`}>{initial}</span>
      ) : (
        <div className="flex flex-col items-center justify-center relative">
          <span className={`font-extrabold tracking-wider ${theme.text}`}>{initial}</span>
          <div className="absolute -bottom-2 opacity-85 scale-75">
            {renderFacetSymbol(avatarSymbol, theme.iconFill)}
          </div>
        </div>
      )}

        </>
      )}
    </div>
  );
};
