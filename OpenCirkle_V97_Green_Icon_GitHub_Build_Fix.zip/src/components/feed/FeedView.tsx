import { SponsorAdSlot } from '../common/SponsorAdSlot';
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Post } from '../../types';
import { fetchPostsFeed } from '../../services/postService';
import { fetchFollowingIds } from '../../services/socialService';
import { seedInitialPostsIfEmpty } from '../../services/seedService';
import { PostCard } from '../post/PostCard';
import { PostComposer } from '../post/PostComposer';
import { IOSStorySpheres } from './IOSStorySpheres';
import { IOSSegmentedTabs } from '../common/IOSSegmentedTabs';
import { DocumentSnapshot } from 'firebase/firestore';
import { Home, Users, Flame, RefreshCw, Layers, Database, Sparkles, LoaderCircle } from 'lucide-react';


// 20,000 virtual community profiles are generated locally (not Firebase Auth accounts).
// Community posts use varied locally-generated topics and writing voices; they are sample
// persona content, not live news and not Firebase Auth accounts.
import { AI_COMMUNITY_SIZE, AI_COMMUNITY_PROFILES } from '../../services/virtualCommunityProfiles';
import { makeVirtualCommunityPostContent } from '../../services/virtualCommunityContent';
const shufflePosts = <T,>(items: T[]): T[] => {
  const shuffled = [...items];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

const makeAICommunityPosts = (offset = 0, count = 15): Post[] => {
  const now = Date.now();
  return Array.from({ length: count }, (_, j) => {
    const i = (offset + j) % AI_COMMUNITY_SIZE;
    const user = AI_COMMUNITY_PROFILES[i];
    const template = makeVirtualCommunityPostContent(i);
    return {
      id: `virtual-ai-community-${user.id}-${offset + j}`, authorId: user.id,
      authorUsername: user.username, authorDisplayName: user.name,
      authorVerified: user.verified, authorAvatarSymbol: (['gem','prism','hexagon','star','orb','sparkle','shield','diamond'] as const)[i % 8],
      authorAvatarColor: (['electric','ice','sapphire','cyan','neon'] as const)[i % 5],
      content: template.content, tags: ['community', template.category.toLowerCase().replace(/[^a-z0-9]+/g, '')], mentions: [],
      createdAt: now - j * 1000 * 60 * 3 - offset * 1000,
      editedAt: null, likesCount: 4 + ((i * 37) % 1200), commentsCount: 0, repostsCount: 0, bookmarksCount: 0,
      viewsCount: 100 + ((i * 83) % 12000), isPinned: false, isRepost: false, repostOf: null, privacy: 'public' as const,
      isVirtualAICommunity: true, communityCategory: template.category, ...(template.sourceUrl ? { sourceUrl: template.sourceUrl } : {}),
    } as Post;
  });
};

interface FeedViewProps {
  onHashtagClick: (tag: string) => void;
  onUserClick: (username: string) => void;
  onOpenAuth: () => void;
}

export const FeedView: React.FC<FeedViewProps> = ({
  onHashtagClick,
  onUserClick,
  onOpenAuth,
}) => {
  const { currentUserProfile } = useAuth();
  const [feedType, setFeedType] = useState<'latest' | 'following' | 'popular'>('latest');
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastVisible, setLastVisible] = useState<DocumentSnapshot | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [seedNotice, setSeedNotice] = useState<string | null>(null);
  const [showInlineComposer, setShowInlineComposer] = useState(false);
  const [communityOffset, setCommunityOffset] = useState(0);
  const communityOffsetRef = React.useRef(0);
  const loadMoreSentinelRef = React.useRef<HTMLDivElement | null>(null);
  const loadMoreLockRef = React.useRef(false);

  useEffect(() => {
    const openPost = (event: Event) => {
      const id = (event as CustomEvent<{ id?: string }>).detail?.id;
      if (!id) return;
      const scrollToPost = () => document.getElementById(`post-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      window.setTimeout(scrollToPost, 350);
      window.setTimeout(scrollToPost, 1200);
    };
    window.addEventListener('opencirkle:open-post', openPost);
    return () => window.removeEventListener('opencirkle:open-post', openPost);
  }, []);

  const loadFeed = useCallback(
    async (isRefresh = false) => {
      if (isRefresh) setRefreshing(true);
      else setLoading(true);

      try {
        let followedIds: string[] = [];
        if (feedType === 'following' && currentUserProfile) {
          followedIds = await fetchFollowingIds(currentUserProfile.uid);
        }

        const { posts: fetchedPosts, lastVisible: nextCursor } = await fetchPostsFeed({
          feedType,
          followedUserIds: followedIds,
          pageSize: 15,
        });
        // Virtual AI content appears in Home/Trending only and never enters Firebase.
        // Pick a different slice of community authors on every Home entry/refresh.
        const batchOffset = isRefresh
          ? communityOffsetRef.current
          : Math.floor(Math.random() * AI_COMMUNITY_SIZE);
        const communityBatch = feedType === 'following' ? [] : makeAICommunityPosts(batchOffset, 15);
        let combinedPosts = feedType === 'following'
          ? fetchedPosts
          : [...fetchedPosts, ...communityBatch];

        // Do not sort Home back into a fixed newest-first order: that made the same
        // generated author (often Rahim Hasan) appear first on every app entry.
        if (feedType === 'latest') combinedPosts = shufflePosts(combinedPosts);
        else if (feedType === 'popular') combinedPosts = combinedPosts.sort((a, b) => b.likesCount - a.likesCount);

        communityOffsetRef.current = (batchOffset + 15) % AI_COMMUNITY_SIZE;
        setCommunityOffset(communityOffsetRef.current);

        // Deduplicate posts by ID
        const uniquePosts: Post[] = [];
        const seenIds = new Set<string>();
        for (const p of combinedPosts) {
          if (p && p.id && !seenIds.has(p.id)) {
            seenIds.add(p.id);
            uniquePosts.push(p);
          }
        }

        const now = Date.now();
        const visiblePosts = uniquePosts.filter((p: any) => {
          if (p.privacy === 'private' && p.authorId !== currentUserProfile?.uid) return false;
          if (p.scheduledAt && p.scheduledAt > now) return false;
          return true;
        });
        setPosts(visiblePosts);
        setLastVisible(nextCursor);
        setHasMore(feedType !== 'following' || Boolean(nextCursor && fetchedPosts.length >= 15));
      } catch (err) {
        console.error('Error fetching feed:', err);
        // Keep the local AI community visible even when Firestore feed loading fails.
        if (feedType !== 'following') { setPosts(makeAICommunityPosts(0, 15)); communityOffsetRef.current = 15; setCommunityOffset(15); setHasMore(true); }
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [feedType, currentUserProfile]
  );

  useEffect(() => {
    loadFeed();
  }, [loadFeed]);

  const handleLoadMore = async () => {
    if (loadMoreLockRef.current || loadingMore || (feedType === 'following' && !lastVisible)) return;
    loadMoreLockRef.current = true;
    setLoadingMore(true);

    // Add the next local community batch immediately so scrolling never waits on
    // a slow Firestore round-trip for the virtual community feed.
    if (feedType !== 'following') {
      const offset = communityOffsetRef.current;
      const batch = makeAICommunityPosts(offset, 15);
      setPosts((prev) => {
        const ids = new Set(prev.map((item) => item.id));
        return [...prev, ...batch.filter((item) => !ids.has(item.id))];
      });
      communityOffsetRef.current = (offset + 15) % AI_COMMUNITY_SIZE;
      setCommunityOffset(communityOffsetRef.current);
      setHasMore(true);
    }

    try {
      let followedIds: string[] = [];
      if (feedType === 'following' && currentUserProfile) {
        followedIds = await fetchFollowingIds(currentUserProfile.uid);
      }

      // The virtual batch is already visible; Firestore results can arrive later.
      const { posts: morePosts, lastVisible: nextCursor } = await fetchPostsFeed({
        feedType,
        followedUserIds: followedIds,
        pageSize: 15,
        lastDoc: lastVisible,
      });

      setPosts((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const uniqueMore = morePosts.filter((p) => p && p.id && !existingIds.has(p.id));
        return [...prev, ...uniqueMore.filter((p: any) => (p.privacy !== 'private' || p.authorId === currentUserProfile?.uid) && (!p.scheduledAt || p.scheduledAt <= Date.now()))];
      });
      setLastVisible(nextCursor);
      if (feedType === 'following') setHasMore(Boolean(nextCursor && morePosts.length >= 15));
    } catch (err) {
      console.error('Error loading more posts:', err);
      if (feedType === 'following') setHasMore(false);
    } finally {
      setLoadingMore(false);
      loadMoreLockRef.current = false;
    }
  };

  useEffect(() => {
    const target = loadMoreSentinelRef.current;
    if (!target || !hasMore || loading || loadingMore) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) void handleLoadMore();
    }, { rootMargin: '1200px 0px', threshold: 0 });
    observer.observe(target);
    return () => observer.disconnect();
  }, [hasMore, loading, loadingMore, communityOffset, lastVisible, feedType, currentUserProfile]);

  const handleSeedNetwork = async () => {
    if (!currentUserProfile) {
      onOpenAuth();
      return;
    }
    setSeeding(true);
    setSeedNotice(null);
    try {
      const seeded = await seedInitialPostsIfEmpty(currentUserProfile);
      if (seeded) {
        setSeedNotice('Seeded initial crystalline discourse nodes successfully!');
        await loadFeed(true);
      } else {
        setSeedNotice('Network already has active posts.');
      }
    } catch (err: any) {
      setSeedNotice(err?.message || 'Seeding failed.');
    } finally {
      setSeeding(false);
      setTimeout(() => setSeedNotice(null), 4000);
    }
  };

  const handlePostCreated = useCallback((newPost: Post) => {
    if (newPost.privacy === 'private' || (newPost.scheduledAt && newPost.scheduledAt > Date.now())) { setShowInlineComposer(false); return; }
    setPosts((prev) => [newPost, ...prev.filter((p) => p.id !== newPost.id)]);
    setShowInlineComposer(false);
  }, []);

  const handlePostDeleted = useCallback((deletedId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== deletedId));
  }, []);

  const handlePostUpdated = useCallback((updated: Post) => {
    setPosts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  }, []);

  const tabOptions = [
    { id: 'latest', label: 'Home', icon: <Home className="w-3.5 h-3.5" /> },
    ...(currentUserProfile
      ? [{ id: 'following', label: 'Following', icon: <Users className="w-3.5 h-3.5" /> }]
      : []),
    { id: 'popular', label: 'Trending', icon: <Flame className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="max-w-2xl w-full mx-auto pb-28">
      <SponsorAdSlot />
      {/* 1. iOS Active Discourse Spheres (Stories Carousel) */}
      <IOSStorySpheres
        onOpenCompose={() => {
          if (!currentUserProfile) onOpenAuth();
          else setShowInlineComposer(true);
        }}
        onUserClick={onUserClick}
      />

      {/* 2. iOS Segmented Pill Tabs Header */}
      <div className="flex items-center justify-between gap-3 mb-6">
        <IOSSegmentedTabs
          options={tabOptions}
          activeId={feedType}
          onChange={(id) => setFeedType(id as any)}
          className="flex-1 max-w-sm"
        />

        <button
          onClick={async () => {
            if (refreshing) return;
            // Rotate to the next virtual community batch so Refresh visibly changes the feed,
            // and discard the previous Firestore pagination cursor before fetching again.
            communityOffsetRef.current = (communityOffsetRef.current + 15) % AI_COMMUNITY_SIZE;
            setCommunityOffset(communityOffsetRef.current);
            setLastVisible(null);
            setHasMore(false);
            setLoadingMore(false);
            await loadFeed(true);
          }}
          disabled={refreshing}
          className="p-2.5 rounded-full ios-liquid-glass-subtle text-[#A8BCD7] hover:text-[#8DDCFF] border border-[#8DDCFF]/20 ios-press"
          title="Refresh Feed"
        >
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-[#8DDCFF]' : ''}`} />
        </button>
      </div>

      {/* Inline Post Composer (expandable) */}
      {currentUserProfile && showInlineComposer && (
        <div className="mb-6 animate-in fade-in slide-in-from-top-4 duration-200">
          <PostComposer
            onPostCreated={handlePostCreated}
            onClose={() => setShowInlineComposer(false)}
          />
        </div>
      )}

      {/* Visitor Welcome Card */}
      {!currentUserProfile && (
        <div className="rounded-3xl ios-liquid-glass p-6 mb-6 text-center shadow-[0_10px_35px_rgba(22,139,255,0.2)] space-y-3">
          <div className="w-12 h-12 mx-auto rounded-full bg-gradient-to-tr from-[#0D47A1] to-[#168BFF] flex items-center justify-center text-white shadow-[0_0_20px_rgba(22,139,255,0.5)]">
            <Sparkles className="w-6 h-6 text-[#8DDCFF]" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#F1F8FF]">Step into OpenCirkle</h3>
            <p className="text-xs text-[#A8BCD7] max-w-md mx-auto mt-1">
              Pure text discourse sanctuary. Polished crystalline ideas with zero media noise.
            </p>
          </div>
          <button
            onClick={onOpenAuth}
            className="px-6 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] via-[#168BFF] to-[#0D47A1] rounded-full shadow-[0_0_20px_rgba(22,139,255,0.4)] hover:shadow-[0_0_25px_rgba(22,139,255,0.6)] ios-press"
          >
            Enter the Network
          </button>
        </div>
      )}

      {/* Seed Notice */}
      {seedNotice && (
        <div className="mb-4 p-3 rounded-2xl bg-[#168BFF]/15 border border-[#168BFF]/30 text-xs text-[#8DDCFF] text-center font-medium">
          {seedNotice}
        </div>
      )}

      {/* Posts Stream */}
      {loading ? (
        <div className="space-y-4 py-4">
          {[1, 2, 3].map((n) => (
            <div
              key={`feed-skeleton-${n}`}
              className="rounded-3xl ios-liquid-glass p-5 animate-pulse space-y-3"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#071A38]" />
                <div className="space-y-1.5 flex-1">
                  <div className="w-28 h-3.5 bg-[#071A38] rounded-full" />
                  <div className="w-20 h-2.5 bg-[#071A38]/60 rounded-full" />
                </div>
              </div>
              <div className="space-y-2 pt-2">
                <div className="w-full h-3 bg-[#071A38]/80 rounded-full" />
                <div className="w-5/6 h-3 bg-[#071A38]/60 rounded-full" />
              </div>
            </div>
          ))}
        </div>
      ) : posts.length === 0 ? (
        <div className="rounded-3xl ios-liquid-glass p-8 text-center space-y-4">
          <Layers className="w-12 h-12 text-[#168BFF]/50 mx-auto" />
          <div>
            <h4 className="text-sm font-semibold text-[#F1F8FF]">
              {feedType === 'following'
                ? 'No posts from accounts you follow yet'
                : 'The crystalline stream is silent'}
            </h4>
            <p className="text-xs text-[#A8BCD7] mt-1 max-w-sm mx-auto">
              {feedType === 'following'
                ? 'Discover and follow other thinkers on the Explore tab, or return to Home.'
                : 'Seed initial discussions or publish the first reflection to activate this node.'}
            </p>
          </div>

          {currentUserProfile && (
            <button
              onClick={handleSeedNetwork}
              disabled={seeding}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-[#8DDCFF] bg-[#071A38] hover:bg-[#0D47A1]/40 border border-[#168BFF]/30 rounded-full transition-all shadow-[0_0_15px_rgba(22,139,255,0.2)] ios-press"
            >
              <Database className="w-3.5 h-3.5 text-[#168BFF]" />
              <span>{seeding ? 'Initializing Starter Discourse...' : 'Seed Community Starter Posts'}</span>
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => (
              <PostCard
                post={post}
                onPostDeleted={handlePostDeleted}
                onPostUpdated={handlePostUpdated}
                onHashtagClick={onHashtagClick}
                onUserClick={onUserClick}
                onOpenAuth={onOpenAuth}
              key={post.id}
              />
          ))}

          {/* Infinite-scroll sentinel: compact spinner instead of a text/button footer. */}
          {hasMore && (
            <div ref={loadMoreSentinelRef} className="flex min-h-14 items-center justify-center py-4" aria-live="polite">
              {loadingMore && (
                <span role="status" aria-label="Loading more discourses" className="inline-flex items-center justify-center rounded-full border border-[#8DDCFF]/20 bg-[#071A38]/70 p-3 shadow-[0_0_18px_rgba(22,139,255,.15)]">
                  <LoaderCircle className="h-5 w-5 animate-spin text-[#8DDCFF]" strokeWidth={2.2} />
                  <span className="sr-only">Loading more discourses</span>
                </span>
              )}
            </div>
          )}
        </div>
      )}

    </div>
  );
};
