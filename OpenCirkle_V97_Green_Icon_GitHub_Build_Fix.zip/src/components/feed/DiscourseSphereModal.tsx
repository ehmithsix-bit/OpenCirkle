import React, { useState, useEffect } from 'react';
import { CrystalAvatar } from '../common/CrystalAvatar';
import VerifiedBadge from '../common/VerifiedBadge';
import { X, Heart, Sparkles, Share2, Check, Eye, Pause } from 'lucide-react';
import { arrayUnion, doc, onSnapshot, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { UserProfile } from '../../types';
import { ShareToUserModal } from '../messages/ShareToUserModal';

const formatStoryAge = (createdAt: number, now: number): string => {
  if (!Number.isFinite(createdAt) || createdAt <= 0) return 'time unavailable';
  const ageMs = Math.max(0, now - createdAt);
  const minutes = Math.floor(ageMs / 60_000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
};

export interface DiscourseSphereItem {
  id: string;
  authorId?: string;
  viewers?: StoryViewer[];
  viewerIds?: string[];
  authorUsername: string;
  authorDisplayName: string;
  avatarSymbol: UserProfile['avatarSymbol'];
  avatarColor: UserProfile['avatarColor'];
  avatarUrl?: string;
  thought: string;
  imageDataUrl?: string;
  tag: string;
  createdAt: number;
}

interface StoryViewer { uid: string; username: string; displayName: string; avatarSymbol?: UserProfile['avatarSymbol']; avatarColor?: UserProfile['avatarColor']; avatarUrl?: string; }

interface DiscourseSphereModalProps {
  sphere: DiscourseSphereItem & { storyItems?: DiscourseSphereItem[] };
  onClose: () => void;
  onUserClick: (username: string) => void;
}

export const DiscourseSphereModal: React.FC<DiscourseSphereModalProps> = ({
  sphere,
  onClose,
  onUserClick,
}) => {
  const [progress, setProgress] = useState(0);
  const [storyIndex, setStoryIndex] = useState(0);
  const [storyNow, setStoryNow] = useState(() => Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setStoryNow(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);
  const storyList = sphere.storyItems?.length ? sphere.storyItems : [sphere];
  const activeStory = storyList[Math.min(storyIndex, storyList.length - 1)] || sphere;

  // Close the viewer as soon as the currently displayed story reaches 24 hours.
  useEffect(() => {
    if (activeStory.createdAt > 0 && storyNow >= activeStory.createdAt + 24 * 60 * 60 * 1000) onClose();
  }, [activeStory.id, activeStory.createdAt, storyNow, onClose]);

  const [liked, setLiked] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showShareToUser, setShowShareToUser] = useState(false);
  const [paused, setPaused] = useState(false);
  const [viewers, setViewers] = useState<StoryViewer[]>(sphere.viewers || []);
  const [liveAuthor, setLiveAuthor] = useState<{ username: string; displayName: string; avatarUrl?: string; verified?: boolean } | null>(null);
  const { firebaseUser, currentUserProfile } = useAuth();
  const isOwnStory = Boolean(firebaseUser?.uid && activeStory.authorId === firebaseUser.uid);

  // Keep the open story viewer in sync too, even if the author changes their name mid-session.
  useEffect(() => {
    if (!activeStory.authorId) { setLiveAuthor(null); return; }
    return onSnapshot(doc(db, 'users', activeStory.authorId), (snap) => {
      if (!snap.exists()) return;
      const data = snap.data();
      setLiveAuthor({
        username: typeof data.username === 'string' && data.username.trim() ? data.username : activeStory.authorUsername,
        displayName: typeof data.displayName === 'string' && data.displayName.trim() ? data.displayName : activeStory.authorDisplayName,
        avatarUrl: typeof data.avatarUrl === 'string' && data.avatarUrl ? data.avatarUrl : activeStory.avatarUrl,
        verified: data.verified === true,
      });
    }, (e) => console.warn('Could not sync live story author:', e));
  }, [activeStory.authorId, activeStory.authorUsername, activeStory.authorDisplayName, activeStory.avatarUrl]);

  // Record each authenticated viewer once and keep the author's viewer list live.
  useEffect(() => {
    const storyRef = doc(db, 'stories', activeStory.id);
    const unsubscribe = onSnapshot(storyRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setViewers(Array.isArray(data.viewers) ? data.viewers as StoryViewer[] : []);
      }
    });
    if (firebaseUser && currentUserProfile && sphere.authorId !== firebaseUser.uid) {
      const viewer: StoryViewer = {
        uid: firebaseUser.uid,
        username: currentUserProfile.username,
        displayName: currentUserProfile.displayName || currentUserProfile.username,
        avatarSymbol: currentUserProfile.avatarSymbol,
        avatarColor: currentUserProfile.avatarColor,
      };
      updateDoc(storyRef, { viewers: arrayUnion(viewer), viewerIds: arrayUnion(firebaseUser.uid) }).catch((e) => console.warn('Could not record story view:', e));
    }
    return unsubscribe;
  }, [activeStory.id, activeStory.authorId, firebaseUser, currentUserProfile]);

  // Holding the story pauses the timer; releasing resumes from the same progress.
  useEffect(() => {
    if (paused) return;
    const timer = window.setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          window.clearInterval(timer);
          if (storyIndex < storyList.length - 1) {
            setStoryIndex((i) => i + 1);
            return 0;
          }
          window.setTimeout(onClose, 200);
          return 100;
        }
        return Math.min(100, prev + 1.2);
      });
    }, 60);
    return () => window.clearInterval(timer);
  }, [paused, onClose, storyIndex, storyList.length]);

  const handleShare = () => {
    if (!currentUserProfile) {
      const storyText = `"${activeStory.thought}" — @${liveAuthor?.username || activeStory.authorUsername} on OpenCirkle`;
      void navigator.clipboard?.writeText(storyText);
      setCopied(true); window.setTimeout(() => setCopied(false), 2000); return;
    }
    setShowShareToUser(true);
  };

  return (
    <>
    <div className="fixed inset-0 z-50 flex items-stretch justify-center bg-black/95 backdrop-blur-xl animate-in fade-in duration-200">
      <div
        onPointerDown={(e) => {
          if (e.button !== 0 && e.pointerType !== 'touch' && e.pointerType !== 'pen') return;
          setPaused(true);
          try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* Capture may be unavailable in older WebViews. */ }
        }}
        onPointerUp={(e) => {
          setPaused(false);
          try { if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* Ignore unsupported capture APIs. */ }
        }}
        onPointerCancel={() => setPaused(false)}
        onLostPointerCapture={() => setPaused(false)}
        onTouchStart={() => setPaused(true)}
        onTouchEnd={() => setPaused(false)}
        onTouchCancel={() => setPaused(false)}
        onContextMenu={(e) => e.preventDefault()}
        style={{ touchAction: 'none' }}
        className="relative w-full max-w-none h-[100dvh] min-h-[100svh] max-h-none rounded-none ios-liquid-glass border-0 sm:border-x sm:border-[#168BFF]/25 shadow-none sm:shadow-[0_20px_60px_rgba(22,139,255,0.25)] flex flex-col justify-between px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-[max(1rem,env(safe-area-inset-bottom))] sm:px-6 overflow-hidden select-none"
      >
        {/* Subtle background crystalline ambient light */}
        <div className="absolute -top-20 -left-20 w-60 h-60 rounded-full bg-[#168BFF]/25 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-60 h-60 rounded-full bg-[#8DDCFF]/15 blur-3xl pointer-events-none" />

        {/* Top: Progress Bar & Author Header */}
        <div className="relative z-10 space-y-4">
          {/* iOS Progress Bar */}
          <div className="w-full h-1 bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#168BFF] to-[#8DDCFF] transition-all duration-75 ease-linear rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
          {paused && <div className="flex items-center justify-center gap-1 text-[10px] text-[#8DDCFF]"><Pause className="w-3 h-3" /> Paused — release to continue</div>}

          <div className="flex items-center justify-between">
            <button
              onClick={() => {
                onUserClick(liveAuthor?.username || activeStory.authorUsername);
                onClose();
              }}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="p-0.5 rounded-2xl bg-gradient-to-tr from-[#168BFF] to-[#8DDCFF]">
                <CrystalAvatar
                  displayName={liveAuthor?.displayName || activeStory.authorDisplayName}
                  username={liveAuthor?.username || activeStory.authorUsername}
                  avatarSymbol={activeStory.avatarSymbol}
                  avatarUrl={liveAuthor?.avatarUrl || activeStory.avatarUrl}
                  avatarColor={activeStory.avatarColor}
                  size="sm"
                />
              </div>
              <div>
                <span className="text-xs font-bold text-[#F1F8FF] group-hover:text-[#8DDCFF] block">
                  {liveAuthor?.displayName || activeStory.authorDisplayName}
                  {liveAuthor?.verified && <VerifiedBadge size="sm" title="Verified account" />}
                </span>
                <span className="text-[10px] font-mono text-[#A8BCD7]">
                  @{liveAuthor?.username || activeStory.authorUsername} · {formatStoryAge(activeStory.createdAt, storyNow)}
                </span>
              </div>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-[#050A18]/60 text-[#A8BCD7] hover:text-[#F1F8FF] border border-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Center: Glowing Crystalline Thought Axiom */}
        <div className="relative z-10 flex-1 min-h-0 my-4 sm:my-6 text-center px-1 sm:px-4 flex flex-col items-center justify-center gap-4 overflow-y-auto overscroll-contain">
          {activeStory.imageDataUrl && <img src={activeStory.imageDataUrl} alt={`Story by @${activeStory.authorUsername}`} className="mx-auto max-h-[62dvh] sm:max-h-[68dvh] w-full max-w-3xl flex-1 min-h-0 rounded-xl sm:rounded-2xl object-contain border border-white/10 shadow-xl" />}
          <div className="w-12 h-12 mx-auto rounded-full bg-gradient-to-tr from-[#0D47A1] via-[#168BFF] to-[#8DDCFF] flex items-center justify-center p-0.5 shadow-[0_0_20px_rgba(22,139,255,0.6)]">
            <div className="w-full h-full bg-[#071A38] rounded-full flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-[#8DDCFF]" />
            </div>
          </div>

          {activeStory.thought && <blockquote className="w-full max-w-3xl text-xl sm:text-2xl font-extrabold text-[#F1F8FF] leading-snug tracking-tight text-balance break-words">
            "{activeStory.thought}"
          </blockquote>}

          <span className="inline-block text-xs font-mono text-[#8DDCFF] px-3 py-1 rounded-full bg-[#0D47A1]/40 border border-[#168BFF]/30">
            #{activeStory.tag}
          </span>
        </div>

        {/* Story owner can see who viewed this story. */}
        {isOwnStory && (
          <div className="relative z-10 mt-auto mb-3 pt-3 border-t border-white/10">
            <div className="flex items-center gap-2 text-xs text-[#A8BCD7] mb-2"><Eye className="w-4 h-4" /><span>{viewers.length === 0 ? 'No views yet' : viewers.length === 1 ? `Seen by ${viewers[0].username}` : `Seen by ${viewers.length}`}</span></div>
            {viewers.length > 0 && <div className="flex items-center gap-2 overflow-x-auto pb-1">{viewers.map((viewer) => <button key={viewer.uid} onClick={(e) => { e.stopPropagation(); onUserClick(viewer.username); onClose(); }} className="flex shrink-0 items-center gap-1.5 rounded-full bg-[#050A18]/70 border border-white/10 px-2 py-1 text-[10px] text-[#F1F8FF]">{viewer.avatarSymbol && viewer.avatarColor ? <CrystalAvatar displayName={viewer.displayName} username={viewer.username} avatarSymbol={viewer.avatarSymbol} avatarColor={viewer.avatarColor} size="sm" /> : null}<span>@{viewer.username}</span></button>)}</div>}
          </div>
        )}

        {/* Bottom: Quick Interactive iOS Actions */}
        <div className="relative z-10 pt-4 border-t border-white/10 flex items-center justify-between gap-3">
          <button
            onClick={() => setLiked(!liked)}
            className={`flex-1 py-2.5 rounded-2xl flex items-center justify-center gap-2 text-xs font-semibold ios-press transition-all ${
              liked
                ? 'bg-[#FF6B6B]/20 text-[#FF6B6B] border border-[#FF6B6B]/40'
                : 'bg-[#050A18]/60 text-[#F1F8FF] border border-white/10'
            }`}
          >
            <Heart className={`w-4 h-4 ${liked ? 'fill-current text-[#FF6B6B]' : ''}`} />
            <span>{liked ? 'Resonated' : 'Resonate'}</span>
          </button>

          <button
            onClick={handleShare}
            className="p-2.5 rounded-2xl bg-[#050A18]/60 text-[#8DDCFF] border border-white/10 ios-press"
            title="Share Axiom"
          >
            {copied ? <Check className="w-4 h-4 text-[#8DDCFF]" /> : <Share2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
    {showShareToUser && <ShareToUserModal title={`OpenCirkle story by @${liveAuthor?.username || activeStory.authorUsername}`} shareText={activeStory.thought || 'View this story on OpenCirkle'} shareUrl={`${window.location.origin}/#story-${encodeURIComponent(activeStory.id)}`} onClose={() => setShowShareToUser(false)} />}
    </>
  );
};
