import React, { useCallback, useEffect, useState } from 'react';
import { collection, getDocs, orderBy, query, doc, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { CheckCircle2, RefreshCw, ShieldCheck, XCircle } from 'lucide-react';

type VerificationRequest = {
  id: string; uid: string; username?: string; displayName?: string; email?: string;
  documentType?: string; documentLabel?: string; documentNumber?: string;
  frontImageData?: string; backImageData?: string; paymentAmount?: number;
  paymentMethod?: string; paymentNumber?: string; transactionId?: string;
  paymentStatus?: string; status?: string; submittedAt?: number;
};

export const VerificationRequestsPanel: React.FC = () => {
  const { currentUserProfile, isAdmin } = useAuth();
  const [requests, setRequests] = useState<VerificationRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const loadRequests = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const q = query(collection(db, 'verification_requests'), orderBy('submittedAt', 'desc'));
      const snap = await getDocs(q);
      setRequests(snap.docs.map(d => ({ id: d.id, ...d.data() } as VerificationRequest)));
    } catch (e: any) {
      setError(e?.message || 'Verification requests could not be loaded. Check Firestore rules.');
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadRequests(); }, [loadRequests]);

  const review = async (request: VerificationRequest, status: 'approved' | 'rejected') => {
    if (!currentUserProfile || !isAdmin || busyId) return;
    if (status === 'approved' && !window.confirm(`Approve verification for @${request.username || request.uid}? Confirm you have manually checked the payment and ID.`)) return;
    setBusyId(request.id); setError(''); setNotice('');
    try {
      await updateDoc(doc(db, 'verification_requests', request.id), {
        status,
        reviewedAt: Date.now(),
        reviewedBy: currentUserProfile.uid,
        paymentStatus: status === 'approved' ? 'manually_confirmed' : 'rejected',
      });
      if (status === 'approved') {
        await updateDoc(doc(db, 'users', request.uid), {
          verified: true,
          verificationStatus: 'approved',
          verificationApprovedAt: Date.now(),
          verificationRequestId: request.id,
        });
      } else {
        await updateDoc(doc(db, 'users', request.uid), {
          verified: false,
          verificationStatus: 'rejected',
          badgeStatus: 'none',
          verificationRejectedAt: Date.now(),
          verificationRejectedBy: currentUserProfile.uid,
          verificationRequestId: request.id,
        });
      }
      setNotice(status === 'approved' ? `@${request.username || request.uid} verified. Badge should now appear on their profile.` : `Request from @${request.username || request.uid} rejected.`);
      await loadRequests();
    } catch (e: any) {
      setError(e?.message || 'Could not update this request. Check Firestore rules.');
    } finally { setBusyId(null); }
  };

  if (!isAdmin) return <div className="rounded-2xl border border-red-400/30 p-5 text-sm text-red-200">Only Admins and Super Admins can review ID verification requests.</div>;

  return <div className="space-y-4">
    <div className="flex items-center justify-between gap-3"><div><h3 className="font-bold text-[#F1F8FF]">Profile Verification Requests</h3><p className="text-xs text-[#A8BCD7]">Check the ID and confirm the transfer amount recorded on each request before approving.</p></div><button onClick={loadRequests} className="flex items-center gap-2 rounded-xl border border-[#168BFF]/30 px-3 py-2 text-xs text-[#8DDCFF]"><RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh</button></div>
    {error && <p className="rounded-xl bg-red-500/10 border border-red-400/30 p-3 text-xs text-red-200 break-words">{error}</p>}
    {notice && <p className="rounded-xl bg-[#168BFF]/10 border border-[#168BFF]/30 p-3 text-xs text-[#8DDCFF]">{notice}</p>}
    {loading ? <p className="p-8 text-center text-xs text-[#A8BCD7]">Loading verification requests…</p> : requests.length === 0 ? <div className="rounded-2xl border border-[#168BFF]/20 p-8 text-center text-xs text-[#A8BCD7]">No verification requests submitted yet.</div> : requests.map(r => <article key={r.id} className="rounded-2xl border border-[#168BFF]/25 bg-[#07152E] p-4 space-y-3">
      <div className="flex items-start justify-between gap-3"><div><h4 className="font-bold text-sm text-white">{r.displayName || r.username || r.uid} <span className="font-normal text-[#8DDCFF]">@{r.username || 'unknown'}</span></h4><p className="text-[11px] text-[#A8BCD7] break-all">UID: {r.uid} · Request: {r.id}</p><p className="text-[11px] text-[#A8BCD7]">{r.submittedAt ? new Date(r.submittedAt).toLocaleString('en-BD', { timeZone: 'Asia/Dhaka' }) : 'Submission time unavailable'}</p></div><span className={`shrink-0 rounded-full px-2 py-1 text-[10px] uppercase ${r.status === 'pending' ? 'bg-amber-500/15 text-amber-200' : r.status === 'approved' ? 'bg-green-500/15 text-green-200' : 'bg-red-500/15 text-red-200'}`}>{r.status || 'pending'}</span></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs"><div className="rounded-xl bg-black/20 p-3 space-y-1"><p><span className="text-[#A8BCD7]">Document:</span> {r.documentLabel || r.documentType || '—'}</p><p><span className="text-[#A8BCD7]">ID number:</span> {r.documentNumber || '—'}</p><p><span className="text-[#A8BCD7]">Payment:</span> ৳{r.paymentAmount || 120} · {r.paymentMethod || '—'}</p><p><span className="text-[#A8BCD7]">Receiver:</span> {r.paymentNumber || '01916293234'}</p><p><span className="text-[#A8BCD7]">TRX ID:</span> <strong className="break-all">{r.transactionId || '—'}</strong></p><p><span className="text-[#A8BCD7]">Payment status:</span> {r.paymentStatus || 'needs_manual_review'}</p></div><div className="grid grid-cols-2 gap-2">{r.frontImageData ? <a href={r.frontImageData} target="_blank" rel="noreferrer" className="block"><img src={r.frontImageData} alt="Document front" className="w-full h-36 object-contain rounded-xl bg-black/30 border border-white/10" /><span className="text-[10px] text-[#A8BCD7]">Front side · open full image</span></a> : <p className="text-[#A8BCD7]">Front image missing</p>}{r.backImageData ? <a href={r.backImageData} target="_blank" rel="noreferrer" className="block"><img src={r.backImageData} alt="Document back" className="w-full h-36 object-contain rounded-xl bg-black/30 border border-white/10" /><span className="text-[10px] text-[#A8BCD7]">Back side · open full image</span></a> : <p className="text-[#A8BCD7]">Back image missing</p>}</div></div>
      {r.status === 'pending' && <div className="flex gap-2"><button disabled={busyId === r.id} onClick={() => review(r, 'approved')} className="flex-1 rounded-xl bg-green-600/90 p-2.5 text-xs font-bold text-white disabled:opacity-50"><CheckCircle2 className="inline w-4 h-4 mr-1" />Approve & Add Badge</button><button disabled={busyId === r.id} onClick={() => review(r, 'rejected')} className="flex-1 rounded-xl border border-red-400/30 bg-red-500/10 p-2.5 text-xs font-bold text-red-200 disabled:opacity-50"><XCircle className="inline w-4 h-4 mr-1" />Reject</button></div>}
    </article>)}
    <p className="text-[10px] text-amber-200/80">Sensitive ID images are stored in Firestore because Firebase Storage is disabled. Configure strict Firestore rules so only the owner can submit/read their own request and only trusted admins can review requests. Do not deploy with permissive public rules.</p>
  </div>;
};
