import React from 'react';

type DotsProps = React.ComponentProps<'span'> & { dots?: number };

export function Dots({ className = '', dots = 3, style, ...props }: DotsProps) {
  return (
    <>
      <style>{`
        @keyframes loading-ui-dots-blink {
          0%, 100% { opacity: 0.2; }
          20% { opacity: 1; }
        }
      `}</style>
      <span
        role="status"
        className={`inline-flex items-center justify-center gap-2 ${className}`}
        style={{ height: '1.25rem', color: 'white', ...style }}
        {...props}
      >
        {Array.from({ length: dots }, (_, index) => (
          <span
            key={index}
            data-slot="dot"
            aria-hidden="true"
            style={{
              animation: 'loading-ui-dots-blink var(--duration, 1.4s) infinite both',
              animationDelay: `calc(var(--delay, 0.2s) * ${index})`,
              width: '0.6rem',
              height: '0.6rem',
              flex: '0 0 0.6rem',
              display: 'block',
              borderRadius: '9999px',
              backgroundColor: 'currentColor',
            }}
          />
        ))}
        <span className="sr-only">Loading</span>
      </span>
    </>
  );
}
