import React, { useEffect, useMemo, useState } from 'react';
import { collection, doc, onSnapshot, query, setDoc, where } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Post, UserProfile } from '../../types';
import { Eye, Wallet, ShieldCheck, FileText, Save, Clock, CheckCircle2 } from 'lucide-react';
import { isBangladeshMobile } from '../../utils/bangladesh';

const DEFAULT_TERMS = '1. You must have at least 1,000 followers and 1,000 total post views to apply.\n2. Submit accurate identity information and a bKash or Nagad number that belongs to you.\n3. Applications are reviewed for identity, authenticity and policy compliance.\n4. Earnings depend on eligible post performance and the platform monetization policy.\n5. Fraud, artificial engagement or false information may result in rejection or suspension.\n6. Do not submit another person’s identity document without their permission.';

export const MonetizationCenter: React.FC<{ profile: UserProfile; posts: Post[]; isOwnProfile: boolean }> = ({ profile, posts, isOwnProfile }) => {
  const [terms, setTerms] = useState(DEFAULT_TERMS);
  const [termsDraft, setTermsDraft] = useState(DEFAULT_TERMS);
  const [minFollowers, setMinFollowers] = useState(1000);
  const [minViews, setMinViews] = useState(1000);
  const [monetizationEnabled, setMonetizationEnabled] = useState(true);
  const [request, setRequest] = useState<any>(null);
  const [open, setOpen] = useState(false);
  const [docType, setDocType] = useState('National ID');
  const [docNumber, setDocNumber] = useState('');
  const [wallet, setWallet] = useState('bKash');
  const [walletNumber, setWalletNumber] = useState('');
  const [faceConsent, setFaceConsent] = useState(false);
  const [docConsent, setDocConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [requests, setRequests] = useState<any[]>([]);
  const [walletBalance, setWalletBalance] = useState(0);
  const [cashoutRequest, setCashoutRequest] = useState<any>(null);
  const [cashoutBusy, setCashoutBusy] = useState(false);
  const [cashoutMethod, setCashoutMethod] = useState('bKash');
  const [cashoutNumber, setCashoutNumber] = useState('');
  const totalViews = useMemo(() => posts.reduce((sum, post) => sum + Math.max(0, Number(post.viewsCount || 0)), 0), [posts]);
  const eligible = monetizationEnabled && Number(profile.followersCount || 0) >= minFollowers && totalViews >= minViews;
  const isAdmin = ['admin', 'superadmin'].includes(profile.role);

  useEffect(() => {
    const stop = onSnapshot(doc(db, 'platformSettings', 'global'), snap => {
      const data = snap.data() || {};
      const next = typeof data.termsAndConditions === 'string' && data.termsAndConditions.trim()
        ? data.termsAndConditions : DEFAULT_TERMS;
      setTerms(next); setTermsDraft(next);
      setMinFollowers(Number.isSafeInteger(Number(data.monetizationMinFollowers)) ? Math.max(0, Number(data.monetizationMinFollowers)) : 1000);
      setMinViews(Number.isSafeInteger(Number(data.monetizationMinViews)) ? Math.max(0, Number(data.monetizationMinViews)) : 1000);
      setMonetizationEnabled(data.monetizationEnabled !== false);
    }, () => {});
    return () => stop();
  }, []);
  useEffect(() => {
    if (!isOwnProfile) return;
    const stop = onSnapshot(doc(db, 'monetizationRequests', profile.uid), snap => {
      const data = snap.exists() ? snap.data() : null;
      setRequest(data);
      if (data?.payoutMethod) setCashoutMethod(data.payoutMethod === 'Nagad' ? 'Nagad' : 'bKash');
      if (data?.payoutNumber) setCashoutNumber(String(data.payoutNumber));
    }, () => {});
    const stopWallet = onSnapshot(doc(db, 'creatorWallets', profile.uid), snap => {
      const data = snap.data() || {};
      setWalletBalance(Math.max(0, Number(data.availableBalance || 0)));
    }, () => {});
    const stopCashout = onSnapshot(query(collection(db, 'cashoutRequests'), where('uid', '==', profile.uid)), snap => {
      const items = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a: any, b: any) => Number(b.submittedAt || 0) - Number(a.submittedAt || 0));
      setCashoutRequest(items[0] || null);
    }, () => {});
    return () => { stop(); stopWallet(); stopCashout(); };
  }, [profile.uid, isOwnProfile]);
  useEffect(() => {
    if (!isAdmin) return;
    const q = query(collection(db, 'monetizationRequests'), where('status', '==', 'pending'));
    return onSnapshot(q, s => setRequests(s.docs.map(d => ({ id: d.id, ...d.data() }))), () => {});
  }, [isAdmin]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setNotice('');
    if (!monetizationEnabled) return setNotice('Creator monetization applications are currently disabled by OpenCirkle.');
    if (!eligible) return setNotice(`You need at least ${minFollowers.toLocaleString()} followers and ${minViews.toLocaleString()} total post views.`);
    if (!docNumber.trim() || !walletNumber.trim() || !faceConsent || !docConsent) return setNotice('Complete all fields and confirm the identity/face verification consent.');
    if (!isBangladeshMobile(walletNumber)) return setNotice('Enter a valid Bangladesh mobile number, e.g. 01XXXXXXXXX or +8801XXXXXXXXX.');
    setBusy(true);
    try {
      const data = { uid: profile.uid, username: profile.username, displayName: profile.displayName, documentType: docType, documentNumber: docNumber.trim(), payoutMethod: wallet, payoutNumber: walletNumber.trim(), faceScanConsent: true, documentConsent: true, followersAtApplication: profile.followersCount || 0, totalViewsAtApplication: totalViews, status: 'pending', submittedAt: Date.now(), reviewAfter: Date.now() + 24 * 60 * 60 * 1000 };
      await setDoc(doc(db, 'monetizationRequests', profile.uid), data);
      setRequest(data); setOpen(false); setNotice('Application submitted. It is pending identity review; submission alone does not activate monetization.');
    } catch (err) { setNotice('Could not submit the application. Check your connection and Firestore permissions.'); }
    finally { setBusy(false); }
  };
  const requestCashout = async () => {
    setNotice('');
    if (request?.status !== 'approved') return setNotice('Cash out is available only after your monetization application is approved.');
    if (walletBalance <= 0) return setNotice('Your available balance is ৳0. There is no balance to cash out yet.');
    if (cashoutRequest && ['pending', 'processing'].includes(cashoutRequest.status)) return setNotice('You already have a cash-out request being processed.');
    const method = cashoutMethod === 'Nagad' ? 'Nagad' : 'bKash';
    const number = String(cashoutNumber || '').trim();
    if (!number || !isBangladeshMobile(number)) return setNotice('Enter a valid Bangladesh mobile number, e.g. 01XXXXXXXXX or +8801XXXXXXXXX.');
    setCashoutBusy(true);
    try {
      const now = Date.now();
      const ref = doc(collection(db, 'cashoutRequests'));
      const data = { id: ref.id, uid: profile.uid, username: profile.username, displayName: profile.displayName, amount: Number(walletBalance.toFixed(2)), payoutMethod: method, payoutNumber: number, status: 'pending', submittedAt: now, expectedWithinHours: '24-48', currency: 'BDT' };
      await setDoc(ref, data);
      setCashoutRequest(data);
      setNotice('Cash-out request submitted. Admin will review and process it within 24–48 hours.');
    } catch { setNotice('Could not submit cash-out request. Please check your connection and Firestore permissions.'); }
    finally { setCashoutBusy(false); }
  };

  const saveTerms = async () => {
    try { await setDoc(doc(db, 'platformSettings', 'global'), { termsAndConditions: termsDraft, updatedAt: Date.now(), updatedBy: profile.uid }, { merge: true }); setNotice('Terms & Conditions saved.'); }
    catch { setNotice('Could not save terms. Check admin permissions and Firestore rules.'); }
  };
  const review = async (item: any, status: 'approved' | 'rejected') => {
    try {
      const now = Date.now();
      const message = status === 'approved'
        ? 'অভিনন্দন! 🎉 আপনার Monetization আবেদন সফলভাবে অনুমোদিত হয়েছে। এখন থেকে আপনি OpenCirkle Monetization Affiliate Partner। আপনার যোগ্য পোস্টের আয় Monetize সেকশনে জমা হবে; প্রযোজ্য পেমেন্ট নিয়ম অনুযায়ী উত্তোলন করা যাবে।'
        : 'আপনার OpenCirkle Monetization আবেদনটি এই মুহূর্তে অনুমোদিত হয়নি। বিস্তারিত জানতে Support-এর সঙ্গে যোগাযোগ করুন।';
      const ref = doc(db, 'monetizationRequests', item.uid);
      await setDoc(ref, { status, reviewedAt: now, reviewedBy: profile.uid, reviewMessage: message }, { merge: true });
      await setDoc(doc(db, 'users', item.uid), status === 'approved'
        ? { monetizationEnabled: true, monetizationStatus: 'active', monetizationEnabledAt: now, monetizationApprovedBy: profile.uid }
        : { monetizationEnabled: false, monetizationStatus: 'rejected', monetizationRejectedAt: now }, { merge: true });
      const notificationRef = doc(collection(db, 'notifications'));
      await setDoc(notificationRef, {
        id: notificationRef.id, recipientId: item.uid, senderId: profile.uid,
        senderUsername: profile.username || 'opencirkle_admin',
        senderDisplayName: 'OpenCirkle Monetization Team',
        senderAvatarSymbol: profile.avatarSymbol || 'gem',
        senderAvatarColor: profile.avatarColor || 'electric',
        type: status === 'approved' ? 'monetization_approved' : 'monetization_rejected',
        targetPostId: '', textSnippet: message, read: false, createdAt: now,
      });
      setNotice(status === 'approved' ? 'Application approved and personal notification sent.' : 'Application rejected and personal notification sent.');
    } catch { setNotice('Could not update the application. Check Firestore permissions.'); }
  };

  return <section className="crystal-card rounded-2xl p-4 sm:p-5 border border-[#168BFF]/25 space-y-4 my-5">
    <div className="flex items-center gap-2"><Eye className="w-5 h-5 text-[#8DDCFF]"/><h3 className="font-bold text-[#F1F8FF]">Total View Insights</h3></div>
    <div className="grid grid-cols-2 gap-3">
      <div className="rounded-xl bg-[#071A38]/70 p-3"><div className="text-xs text-[#A8BCD7]">Followers</div><div className="text-xl font-bold text-white">{Number(profile.followersCount || 0).toLocaleString()}</div></div>
      <div className="rounded-xl bg-[#071A38]/70 p-3"><div className="text-xs text-[#A8BCD7]">Total post views</div><div className="text-xl font-bold text-white">{totalViews.toLocaleString()}</div></div>
    </div>
    <div className="space-y-2">{posts.map(p => <div key={p.id} className="flex justify-between gap-3 border-b border-white/5 pb-2 text-xs"><span className="text-[#A8BCD7] truncate">{p.content}</span><span className="shrink-0 text-[#8DDCFF] flex items-center gap-1"><Eye className="w-3 h-3"/>{Number(p.viewsCount || 0).toLocaleString()}</span></div>)}</div>
    {isOwnProfile && <>
      <div className="border-t border-white/10 pt-4 space-y-2"><div className="flex items-center gap-2"><Wallet className="w-4 h-4 text-[#8DDCFF]"/><h3 className="font-bold text-white">Monetize Your Account</h3></div>
        <p className="text-xs text-[#A8BCD7]">Eligibility: {minFollowers.toLocaleString()} followers + {minViews.toLocaleString()} total post views.</p>
        {!monetizationEnabled && <p className="text-xs text-amber-200">Creator monetization applications are currently disabled by the admin.</p>}
        <p className="text-xs text-[#A8BCD7]">Status: <span className="text-[#8DDCFF]">{request?.status ? request.status.toUpperCase() : eligible ? 'ELIGIBLE' : 'NOT YET ELIGIBLE'}</span></p>
        {!request && <button onClick={() => setOpen(v => !v)} disabled={!eligible} className="rounded-xl px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] disabled:opacity-40">Monetize Your Account</button>}
      </div>
      {open && <form onSubmit={submit} className="space-y-3 rounded-xl border border-[#168BFF]/20 p-4">
        <p className="text-sm font-semibold text-white flex items-center gap-2"><ShieldCheck className="w-4 h-4"/>Identity & payout verification</p>
        <p className="text-xs text-amber-200">Face verification must be performed through a secure, consent-based verification service. This form records your consent; it does not itself perform a biometric face scan or securely collect an ID image.</p>
        <label className="block text-xs text-[#A8BCD7]">Document type<select value={docType} onChange={e=>setDocType(e.target.value)} className="mt-1 w-full rounded-lg bg-[#071A38] p-2 text-white"><option>National ID</option><option>Passport</option><option>Driving Licence</option></select></label>
        <label className="block text-xs text-[#A8BCD7]">Document number<input value={docNumber} onChange={e=>setDocNumber(e.target.value)} required className="mt-1 w-full rounded-lg bg-[#071A38] p-2 text-white" autoComplete="off"/></label>
        <label className="block text-xs text-[#A8BCD7]">Payout method<select value={wallet} onChange={e=>setWallet(e.target.value)} className="mt-1 w-full rounded-lg bg-[#071A38] p-2 text-white"><option>bKash</option><option>Nagad</option></select></label>
        <label className="block text-xs text-[#A8BCD7]">{wallet} number<input value={walletNumber} onChange={e=>setWalletNumber(e.target.value)} required inputMode="tel" className="mt-1 w-full rounded-lg bg-[#071A38] p-2 text-white"/></label>
        <label className="flex gap-2 text-xs text-[#A8BCD7]"><input type="checkbox" checked={faceConsent} onChange={e=>setFaceConsent(e.target.checked)}/> I consent to a secure face/identity verification step.</label>
        <label className="flex gap-2 text-xs text-[#A8BCD7]"><input type="checkbox" checked={docConsent} onChange={e=>setDocConsent(e.target.checked)}/> I confirm the ID details are mine and agree to the Terms & Conditions below.</label>
        <button disabled={busy} className="rounded-xl px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] disabled:opacity-50">{busy ? 'Submitting…' : 'Submit application'}</button>
      </form>}
      <div className="rounded-2xl border border-[#168BFF]/25 bg-[#071A38]/70 p-4 space-y-3"><div className="flex items-center justify-between gap-3"><div><p className="text-xs text-[#A8BCD7]">Available creator balance</p><p className="text-2xl font-extrabold text-white">৳{walletBalance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p></div><Wallet className="w-7 h-7 text-[#8DDCFF]"/></div><p className="text-xs text-[#A8BCD7]">Choose bKash or Nagad and enter the receiving number. Processing target: 24–48 hours after admin review.</p><div className="grid sm:grid-cols-2 gap-2"><label className="block text-xs text-[#A8BCD7]">Cash-out method<select value={cashoutMethod} onChange={e=>setCashoutMethod(e.target.value)} className="mt-1 w-full rounded-lg bg-[#071A38] p-2 text-white"><option value="bKash">bKash</option><option value="Nagad">Nagad</option></select></label><label className="block text-xs text-[#A8BCD7]">Receiving number<input value={cashoutNumber} onChange={e=>setCashoutNumber(e.target.value)} inputMode="tel" required className="mt-1 w-full rounded-lg bg-[#071A38] p-2 text-white" placeholder="01XXXXXXXXX or +8801XXXXXXXXX" pattern="(?:\+?8801[3-9]\d{8}|01[3-9]\d{8})" maxLength={14}/></label></div><button type="button" onClick={requestCashout} disabled={cashoutBusy || walletBalance <= 0 || request?.status !== 'approved' || ['pending','processing'].includes(cashoutRequest?.status)} className="rounded-xl px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] disabled:opacity-40">{cashoutBusy ? 'Submitting…' : 'Cash out with bKash/Nagad'}</button>{cashoutRequest && <div className="rounded-lg bg-white/5 p-3 text-xs text-[#A8BCD7]">Latest cash-out: <b className="text-white">৳{Number(cashoutRequest.amount||0).toLocaleString()}</b> · {cashoutRequest.payoutMethod} · <b className="text-[#8DDCFF]">{String(cashoutRequest.status||'pending').toUpperCase()}</b>{['pending','processing'].includes(cashoutRequest.status) && <p className="mt-1">Expected processing within 24–48 hours after admin review.</p>}</div>}</div>
      <div className="rounded-xl bg-[#071A38]/60 p-3"><h4 className="text-sm font-semibold text-white flex gap-2 items-center"><FileText className="w-4 h-4"/>Monetization Terms & Conditions</h4><pre className="whitespace-pre-wrap font-sans text-xs text-[#A8BCD7] mt-2">{terms}</pre></div>
    </>}
    {isAdmin && <div className="border-t border-white/10 pt-4 space-y-3"><h3 className="font-bold text-white">Admin · Monetization settings</h3><label className="block text-xs text-[#A8BCD7]">Terms & Conditions (visible in user accounts)<textarea rows={6} value={termsDraft} onChange={e=>setTermsDraft(e.target.value)} className="mt-1 w-full rounded-lg bg-[#071A38] p-3 text-white"/></label><button onClick={saveTerms} className="rounded-lg px-3 py-2 text-xs font-semibold bg-[#168BFF] text-white flex items-center gap-2"><Save className="w-3 h-3"/>Save terms</button>
      <h4 className="text-sm font-semibold text-white">Pending applications ({requests.length})</h4>{requests.map(r=><div key={r.uid} className="rounded-xl border border-white/10 p-3 space-y-2"><p className="text-xs text-white">@{r.username} · {r.payoutMethod}: {r.payoutNumber}</p><p className="text-xs text-[#A8BCD7]">{r.documentType}: {r.documentNumber} · Views: {Number(r.totalViewsAtApplication||0).toLocaleString()}</p><p className="text-xs text-[#A8BCD7] flex items-center gap-1"><Clock className="w-3 h-3"/>Submitted {new Date(r.submittedAt).toLocaleString()}</p><div className="flex gap-2"><button onClick={()=>review(r,'approved')} className="rounded-lg px-3 py-1 text-xs bg-emerald-700 text-white flex gap-1 items-center"><CheckCircle2 className="w-3 h-3"/>Approve</button><button onClick={()=>review(r,'rejected')} className="rounded-lg px-3 py-1 text-xs bg-red-700 text-white">Reject</button></div></div>)}</div>}
    {notice && <p role="status" className="text-xs text-[#8DDCFF]">{notice}</p>}
  </section>;
};
