import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { PlatformSettings, Post, UserProfile } from '../../types';
import { getUserByUsername } from '../../services/authService';
import {
  fetchUserPosts,
  fetchUserPostCount,
  fetchBookmarkedPosts,
} from '../../services/postService';
import {
  checkFollowStatus,
  toggleFollowUser,
} from '../../services/socialService';
import { toggleBlockUser, updateUserProfile } from '../../services/authService';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { CrystalAvatar } from '../common/CrystalAvatar';
import VerifiedBadge from '../common/VerifiedBadge';
import { PostCard } from '../post/PostCard';
import { EditProfileModal } from './EditProfileModal';
import { UserListModal } from './UserListModal';
import { ReportModal } from '../post/ReportModal';
import { VerificationRequestModal } from './VerificationRequestModal';
import { MonetizationCenter } from './MonetizationCenter';
import { getVirtualCommunityProfile } from '../../services/virtualCommunityProfiles';
import { makeVirtualCommunityPostContent } from '../../services/virtualCommunityContent';
import {
  ArrowLeft,
  Wallet,
  Calendar,
  CheckCircle2,
  Lock,
  Globe,
  Edit3,
  MessageSquare,
  ShieldCheck,
  ShieldAlert,
  UserX,
  Share2,
  Check,
  Sparkles,
  MoreVertical,
  Download,
  Settings,
  RefreshCw,
  Shield,
  Flag,
  Sun,
  Moon,
} from 'lucide-react';

interface ProfileViewProps {
  targetUsername?: string;
  onOpenAuth: () => void;
  onStartChat?: (user: UserProfile) => void;
  onHashtagClick: (tag: string) => void;
  onUserClick: (username: string) => void;
  themePreference?: 'crystal_dark' | 'moonlight_manor';
  onThemePreferenceChange?: (next: 'crystal_dark' | 'moonlight_manor') => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  targetUsername,
  onOpenAuth,
  onStartChat,
  onHashtagClick,
  onUserClick,
  themePreference = 'crystal_dark',
  onThemePreferenceChange,
}) => {
  const { currentUserProfile, isModerator, logout } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [posts, setPosts] = useState<Post[]>([]);
  const [postsLoading, setPostsLoading] = useState(true);
  const [authoritativePostCount, setAuthoritativePostCount] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'posts' | 'saved'>('posts');
  const [followStatus, setFollowStatus] = useState<'not_following' | 'following' | 'requested'>('not_following');
  const [followBusy, setFollowBusy] = useState(false);
  const [isOnline, setIsOnline] = useState(false);
  const [lastActiveAt, setLastActiveAt] = useState<number | null>(null);
  const [presenceNow, setPresenceNow] = useState(() => Date.now());

  // Modals
  const [showEditModal, setShowEditModal] = useState(false);
  const [userListType, setUserListType] = useState<'followers' | 'following' | null>(null);
  const [showReportModal, setShowReportModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showVerificationModal, setShowVerificationModal] = useState(false);
  const [showMonetization, setShowMonetization] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [platformSettings, setPlatformSettings] = useState<Partial<PlatformSettings> | null>(null);
  const [updateNotice, setUpdateNotice] = useState<string | null>(null);

  const isOwnProfile = !targetUsername || (currentUserProfile && currentUserProfile.username.toLowerCase() === targetUsername.toLowerCase());
  const isVirtualProfile = Boolean((profile as (UserProfile & { isVirtualProfile?: boolean }) | null)?.isVirtualProfile);
  const normalizedFollowingCount = Math.max(0, Number.isFinite(Number(profile?.followingCount)) ? Number(profile?.followingCount) : 0);
  const virtualFollowingCount = isOwnProfile && currentUserProfile ? (() => {
    try {
      const saved = JSON.parse(window.localStorage.getItem(`opencirkle:virtual-following:${currentUserProfile.uid}`) || '[]');
      return Array.isArray(saved) ? saved.length : 0;
    } catch { return 0; }
  })() : 0;
  const displayedFollowingCount = normalizedFollowingCount + virtualFollowingCount;

  // Load user profile
  useEffect(() => {
    let active = true;
    const loadUser = async () => {
      setLoading(true);
      try {
        if (isOwnProfile) {
          if (active) setProfile(currentUserProfile);
        } else if (targetUsername) {
          const user = await getUserByUsername(targetUsername);
          if (user) {
            if (active) setProfile(user);
          } else {
            // Locally generated starter-feed profiles should open with the same normal
            // profile layout, without creating fake Firebase user documents.
            // Feed community handles use natural first.last usernames. Resolve those
            // locally so virtual feed authors always have a normal, populated profile.
            const normalizedHandle = targetUsername.toLowerCase().replace(/^@/, '');
            const nameParts = normalizedHandle.split(/[._-]+/).filter(Boolean);
            const knownNameMap: Record<string, string> = {
              'rahim.hasan': 'Rahim Hasan', 'nusrat.jahan': 'Nusrat Jahan', 'sabbir.ahmed': 'Sabbir Ahmed',
              'ayesha.akter': 'Ayesha Akter', 'tanvir.islam': 'Tanvir Islam', 'sumaiya.rahman': 'Sumaiya Rahman',
            };
            const communityEntry = getVirtualCommunityProfile(normalizedHandle);
            const displayName = communityEntry?.name || knownNameMap[normalizedHandle] || nameParts.map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(' ');
            const stableHash = Array.from(normalizedHandle).reduce<number>((acc, ch) => ((acc * 31) + ch.charCodeAt(0)) >>> 0, 7);
            const avatarSymbols: UserProfile['avatarSymbol'][] = ['gem', 'prism', 'hexagon', 'star', 'orb', 'sparkle', 'shield', 'diamond'];
            const avatarColors: UserProfile['avatarColor'][] = ['electric', 'ice', 'sapphire', 'cyan', 'neon'];
            const virtualProfile = {
              uid: communityEntry?.id || `ai-community-${normalizedHandle}`, email: '', username: normalizedHandle,
              displayName, bio: 'Sharing reading notes, reflections, and community updates on OpenCirkle.',
              joinedAt: Date.now() - (stableHash % 700) * 86400000, followersCount: (stableHash * 37) % 4200,
              followingCount: (stableHash * 13) % 900, postsCount: 6, likesCount: 0,
              verified: Boolean(communityEntry?.verified), isPrivate: false, role: 'user' as const, status: 'active' as const,
              avatarSymbol: avatarSymbols[stableHash % avatarSymbols.length],
              avatarColor: avatarColors[stableHash % avatarColors.length],
              isVirtualProfile: true,
            } as UserProfile & { isVirtualProfile: boolean };
            if (active && (communityEntry || nameParts.length >= 2)) setProfile(virtualProfile);
            else if (active) setProfile(null);
          }
        }
      } catch (err) {
        console.error('Error fetching profile:', err);
      } finally {
        if (active) setLoading(false);
      }
    };
    loadUser();
    return () => {
      active = false;
    };
  }, [targetUsername, isOwnProfile, currentUserProfile]);

  // Keep the admin-published app update link live for the profile menu.
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'platformSettings', 'global'), (snap) => {
      setPlatformSettings(snap.exists() ? (snap.data() as Partial<PlatformSettings>) : {});
    }, (err) => console.error('Could not load app update settings:', err));
    return () => unsubscribe();
  }, []);

  const handleAppUpdate = () => {
    const rawUrl = String(platformSettings?.appUpdateUrl || '').trim();
    if (!platformSettings?.appUpdateEnabled || !rawUrl) {
      setShowProfileMenu(false);
      setUpdateNotice('No app update is currently available.');
      window.setTimeout(() => setUpdateNotice(null), 3500);
      return;
    }
    try {
      const url = new URL(rawUrl);
      if (url.protocol !== 'https:') throw new Error('HTTPS required');
      window.open(url.toString(), '_blank', 'noopener,noreferrer');
      setShowProfileMenu(false);
    } catch {
      setShowProfileMenu(false);
      setUpdateNotice('The update link is invalid. Please contact OpenCirkle support.');
      window.setTimeout(() => setUpdateNotice(null), 4000);
    }
  };

  const handlePrivacyToggle = async () => {
    if (!currentUserProfile || !isOwnProfile) return;
    const next = !Boolean(profile?.isPrivate);
    try {
      await updateUserProfile(currentUserProfile.uid, { isPrivate: next });
      setProfile((old) => old ? { ...old, isPrivate: next } : old);
      setShowProfileMenu(false);
      setUpdateNotice(`Account is now ${next ? 'Private' : 'Public'}.`);
      window.setTimeout(() => setUpdateNotice(null), 3000);
    } catch (err) {
      setUpdateNotice((err as Error)?.message || 'Could not update account privacy.');
      window.setTimeout(() => setUpdateNotice(null), 4000);
    }
  };

  // Subscribe to live presence; stale heartbeats count as offline.
  useEffect(() => {
    if (!profile?.uid || isVirtualProfile) { setIsOnline(false); setLastActiveAt(null); return; }
    const unsubscribe = onSnapshot(doc(db, 'users', profile.uid), (snap) => {
      const data = snap.data();
      if (!data) return;
      const timestamp = Number(data.lastActiveAt || data.lastSeenAt || 0);
      setLastActiveAt(Number.isFinite(timestamp) && timestamp > 0 ? timestamp : null);
      setIsOnline(Boolean(data.isOnline) && timestamp > 0 && Date.now() - timestamp < 90000);
      // Keep public profile identity live: username/display name/avatar edits should
      // appear immediately on profiles opened from Home or Explore without navigation.
      setProfile((current) => current?.uid === profile.uid ? ({
        ...current,
        ...data,
        uid: profile.uid,
        username: String(data.username || current.username),
        displayName: String(data.displayName || data.name || current.displayName || data.username || current.username),
      } as UserProfile) : current);
    }, () => { setIsOnline(false); setLastActiveAt(null); });
    return () => unsubscribe();
  }, [profile?.uid, isVirtualProfile]);

  // Keep the relative last-active label fresh without requiring a profile reload.
  useEffect(() => {
    const timer = window.setInterval(() => setPresenceNow(Date.now()), 30000);
    return () => window.clearInterval(timer);
  }, []);

  const lastActiveLabel = (() => {
    if (isOnline) return 'Online now';
    if (!lastActiveAt) return 'Offline';
    const elapsed = Math.max(0, presenceNow - lastActiveAt);
    const minutes = Math.floor(elapsed / 60000);
    if (minutes < 1) return 'Active just now';
    if (minutes < 60) return `Active ${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `Active ${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
    const days = Math.floor(hours / 24);
    if (days < 30) return `Active ${days} ${days === 1 ? 'day' : 'days'} ago`;
    const date = new Date(lastActiveAt);
    return `Active on ${date.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}`;
  })();

  // Real users use Firebase follow records; sample profiles use device-local follows only.
  useEffect(() => {
    let active = true;
    const loadStatus = async () => {
      if (!currentUserProfile || !profile || isOwnProfile) {
        if (active) setFollowStatus('not_following');
        return;
      }
      if (isVirtualProfile) {
        try {
          const key = `opencirkle:virtual-following:${currentUserProfile.uid}`;
          const saved = JSON.parse(window.localStorage.getItem(key) || '[]') as Array<{ uid: string }>;
          if (active) setFollowStatus(saved.some((u) => u.uid === profile.uid) ? 'following' : 'not_following');
        } catch {
          if (active) setFollowStatus('not_following');
        }
        return;
      }
      try {
        const st = await checkFollowStatus(currentUserProfile.uid, profile.uid);
        if (active) setFollowStatus(st);
      } catch (err) {
        console.warn('Could not check follow status:', err);
      }
    };
    void loadStatus();
    return () => { active = false; };
  }, [currentUserProfile, profile, isOwnProfile, isVirtualProfile]);

  // Load posts for profile
  useEffect(() => {
    let active = true;
    const loadPosts = async () => {
      if (!profile) return;
      if (isVirtualProfile) {
        setPostsLoading(true);
        if (activeTab === 'saved') {
          setPosts([]);
          setPostsLoading(false);
          return;
        }
        const p = profile as UserProfile & { isVirtualProfile?: boolean };
        const hash = Array.from(p.username).reduce((acc, ch) => ((acc * 31) + ch.charCodeAt(0)) >>> 0, 11);
        const virtualPosts = Array.from({ length: 6 }, (_, idx) => {
          const communityEntry = getVirtualCommunityProfile(p.username);
          // Match the same stable persona index used by Home/Trending so the
          // author's feed post belongs to this exact profile as well.
          const personaIndex = communityEntry?.index ?? hash;
          const topic = makeVirtualCommunityPostContent(personaIndex + idx * 13);
          const createdAt = Date.now() - idx * 3 * 60 * 1000;
          return {
            id: `virtual-profile-post-${p.username}-${idx + 1}`, authorId: p.uid,
            authorUsername: p.username, authorDisplayName: p.displayName, authorVerified: Boolean(communityEntry?.verified),
            authorAvatarSymbol: p.avatarSymbol, authorAvatarColor: p.avatarColor,
            content: topic.content,
            tags: ['opencirkle', topic.category.toLowerCase().replace(/[^a-z0-9]+/g, '')], mentions: [], createdAt, editedAt: null,
            likesCount: (hash + idx * 17) % 240, commentsCount: (hash + idx) % 28,
            repostsCount: (hash + idx * 5) % 19, bookmarksCount: (hash + idx * 11) % 35,
            viewsCount: 80 + ((hash + idx * 97) % 6000), isPinned: false, isRepost: false,
            repostOf: null, privacy: 'public' as const, isVirtualAICommunity: true, communityCategory: topic.category, ...(topic.sourceUrl ? { sourceUrl: topic.sourceUrl } : {}),
          } as Post;
        });
        if (active) { setPosts(virtualPosts.sort((a, b) => b.createdAt - a.createdAt)); setAuthoritativePostCount(virtualPosts.length); }
        if (active) setPostsLoading(false);
        return;
      }
      setPostsLoading(true);
      if (activeTab === 'posts') setAuthoritativePostCount(null);
      try {
        if (activeTab === 'posts') {
          // Render the post list as soon as it arrives; the count query must not block the UI.
          const countPromise = fetchUserPostCount(profile.uid);
          const list = await fetchUserPosts(profile.uid);
          if (active) setPosts(list);
          void countPromise.then((count) => {
            if (active && count !== null) setAuthoritativePostCount(count);
          });
        } else if (activeTab === 'saved' && isOwnProfile) {
          const saved = await fetchBookmarkedPosts(profile.uid);
          if (active) setPosts(saved);
        }
      } catch (err) {
        console.error('Error loading profile posts:', err);
      } finally {
        if (active) setPostsLoading(false);
      }
    };
    loadPosts();
    return () => {
      active = false;
    };
  }, [profile?.uid, activeTab, isOwnProfile, isVirtualProfile]);

  const handleFollowToggle = async () => {
    if (!currentUserProfile) {
      onOpenAuth();
      return;
    }
    if (!profile || followBusy) return;
    setFollowBusy(true);
    const previousFollowStatus = followStatus;
    const optimisticStatus = followStatus === 'following' ? 'not_following' : (profile.isPrivate ? 'requested' : 'following');
    setFollowStatus(optimisticStatus);
    if (isVirtualProfile) {
      // Sample accounts are intentionally local-only: never write fake follows to Firebase.
      try {
        const key = `opencirkle:virtual-following:${currentUserProfile.uid}`;
        const saved = JSON.parse(window.localStorage.getItem(key) || '[]') as Array<UserProfile & { isVirtualProfile?: boolean }>;
        const alreadyFollowing = saved.some((u) => u.uid === profile.uid);
        const next = alreadyFollowing
          ? saved.filter((u) => u.uid !== profile.uid)
          : [...saved.filter((u) => u.uid !== profile.uid), { ...profile, isVirtualProfile: true }];
        window.localStorage.setItem(key, JSON.stringify(next));
        setFollowStatus(alreadyFollowing ? 'not_following' : 'following');
        setProfile((prev) => prev ? {
          ...prev,
          followersCount: Math.max(0, prev.followersCount + (alreadyFollowing ? -1 : 1)),
        } : prev);
      } catch (err) { setFollowStatus(previousFollowStatus); console.warn('Could not update local sample follow list:', err); } finally { setFollowBusy(false); }
      return;
    }

    try {
      const res = await toggleFollowUser(currentUserProfile, profile);
      setFollowStatus(res.status);
      // update follower count locally
      setProfile((prev) => {
        if (!prev) return null;
        const delta = res.status === 'following' ? 1 : res.status === 'not_following' ? -1 : 0;
        return { ...prev, followersCount: Math.max(0, prev.followersCount + delta) };
      });
    } catch (err) {
      setFollowStatus(previousFollowStatus);
      console.error('Follow error:', err);
    } finally { setFollowBusy(false); }
  };

  const handleShareProfile = async () => {
    if (!profile) return;
    const profileUrl = `${window.location.origin}/#user-${encodeURIComponent(profile.username)}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: `${profile.displayName} on OpenCirkle`, url: profileUrl });
        return;
      }
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(profileUrl);
      else {
        const field = document.createElement('textarea');
        field.value = profileUrl; field.setAttribute('readonly', '');
        field.style.position = 'fixed'; field.style.opacity = '0';
        document.body.appendChild(field); field.select();
        const copied = document.execCommand('copy'); field.remove();
        if (!copied) throw new Error('Clipboard unavailable');
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch (err) {
      if ((err as Error)?.name !== 'AbortError') window.prompt('Copy this profile link:', profileUrl);
    }
  };

  if (loading) {
    return (
      <div className="oc-liquid-loader-wrap py-12 flex flex-col items-center justify-center gap-3" role="status" aria-label="Loading profile">
        <div className="oc-liquid-loader" aria-hidden="true"><span className="oc-liquid-wave oc-liquid-wave-one" /><span className="oc-liquid-wave oc-liquid-wave-two" /><span className="oc-liquid-core" /></div>
        <span className="text-[11px] font-medium tracking-[0.22em] uppercase text-[#A8BCD7]">Loading</span>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="crystal-card max-w-xl mx-auto rounded-2xl p-8 text-center border border-[#168BFF]/20 space-y-3">
        <h3 className="text-base font-bold text-[#F1F8FF]">Profile Not Located</h3>
        <p className="text-xs text-[#A8BCD7]">
          This crystalline thinker is either dissolved or not yet manifested in the network.
        </p>
      </div>
    );
  }

  const joinDateFormatted = new Date(profile.joinedAt).toLocaleDateString('en-BD', { timeZone: 'Asia/Dhaka',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  // Keep monetization tools in their own dedicated section instead of cluttering the profile.
  if (showMonetization && isOwnProfile) {
    return (
      <div className="max-w-2xl w-full mx-auto pb-16 space-y-5">
        <div className="rounded-2xl ios-liquid-glass border border-[#8DDCFF]/25 p-4 sm:p-5">
          <button
            type="button"
            onClick={() => setShowMonetization(false)}
            className="inline-flex items-center gap-2 rounded-xl border border-[#168BFF]/30 bg-[#071A38]/70 px-3 py-2 text-sm font-semibold text-[#8DDCFF] hover:bg-[#0D47A1]/40 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Profile
          </button>
          <div className="mt-4 flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#168BFF]/15 border border-[#8DDCFF]/25">
              <Wallet className="h-5 w-5 text-[#8DDCFF]" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-[#F1F8FF]">Monetize</h2>
              <p className="text-xs text-[#A8BCD7]">View insights, eligibility and monetization settings</p>
            </div>
          </div>
        </div>
        <MonetizationCenter profile={profile} posts={posts} isOwnProfile={true} />
      </div>
    );
  }

  return (
    <div className="w-full min-w-0 max-w-2xl mx-auto px-3 sm:px-0 pb-20 overflow-x-clip">
      {/* Profile Header Glass Card */}
      <div className="w-full min-w-0 rounded-2xl sm:rounded-3xl ios-liquid-glass p-4 sm:p-8 border border-[#8DDCFF]/30 shadow-[0_16px_50px_rgba(0,0,0,0.8)] mb-6 relative">
        {/* Subtle decorative geometric crystal grid backdrop */}
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-gradient-to-br from-[#168BFF]/15 to-[#8DDCFF]/5 blur-2xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 relative">
          <div className="relative z-0 isolate shrink-0 overflow-visible" title={isOnline ? 'Online' : 'Offline'}>
            <CrystalAvatar
              displayName={profile.displayName}
              username={profile.username}
              avatarSymbol={profile.avatarSymbol}
              avatarUrl={profile.avatarUrl}
              avatarColor={profile.avatarColor}
              size="2xl"
            />
            <span
              aria-label={isOnline ? 'Online' : 'Offline'}
              className={`absolute z-20 bottom-0 right-0 translate-x-1/4 translate-y-1/4 w-4 h-4 rounded-full border-[3px] border-[#071A38] pointer-events-none ${isOnline ? 'bg-green-400 shadow-[0_0_12px_rgba(74,222,128,0.95)] ring-2 ring-green-300/30' : 'bg-slate-500'}`}
            />
          </div>

          <div className="flex-1 text-center sm:text-left space-y-3 min-w-0">
            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
                <h2 className="text-xl font-extrabold text-[#F1F8FF] tracking-tight">
                  {profile.displayName}
                </h2>
                {profile.verified && <VerifiedBadge size="lg" title="Verified account" placement="displayName" />}
                {profile.role !== 'user' && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#168BFF]/20 text-[#8DDCFF] border border-[#168BFF]/40 uppercase tracking-wider">
                    {profile.role}
                  </span>
                )}
              </div>
              <p className="block w-full text-xs font-mono text-[#A8BCD7] mt-1 leading-tight">@{profile.username}</p>
              {!isVirtualProfile && (
                <p className={`mt-1 text-[11px] font-medium ${isOnline ? 'text-emerald-300' : 'text-[#A8BCD7]'}`} title={lastActiveAt ? new Date(lastActiveAt).toLocaleString() : 'Last active time is not available'}>
                  <span className={`inline-block w-1.5 h-1.5 rounded-full mr-1.5 align-middle ${isOnline ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                  {lastActiveLabel}
                </p>
              )}
            </div>

            <p className="text-sm text-[#F1F8FF]/90 leading-relaxed break-words whitespace-pre-wrap">
              {profile.bio || 'Exploring the crystalline depths of OpenCirkle.'}
            </p>

            {/* Metadata unboxed text with typographic separator */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-2 gap-y-1 text-xs text-[#A8BCD7] min-w-0">
              <span className="flex items-center gap-1 font-mono">
                <Calendar className="w-3.5 h-3.5 text-[#168BFF]" />
                <span>Joined {joinDateFormatted}</span>
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1 font-mono">
                {profile.isPrivate ? (
                  <>
                    <Lock className="w-3.5 h-3.5 text-[#8DDCFF]" />
                    <span>Private Node</span>
                  </>
                ) : (
                  <>
                    <Globe className="w-3.5 h-3.5 text-[#168BFF]" />
                    <span>Public Node</span>
                  </>
                )}
              </span>
            </div>

            {/* Counters Bar (Clean tabular numerals) */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-5 gap-y-3 pt-2">
              <button
                onClick={() => setUserListType('following')}
                className="text-left group focus:outline-none"
              >
                <span className="font-mono font-bold text-sm text-[#F1F8FF] tabular-nums block group-hover:text-[#8DDCFF] transition-colors">
                  {displayedFollowingCount.toLocaleString('en-US')}
                </span>
                <span className="text-[11px] text-[#A8BCD7]">Following</span>
              </button>

              <button
                onClick={() => setUserListType('followers')}
                className="text-left group focus:outline-none"
              >
                <span className="font-mono font-bold text-sm text-[#F1F8FF] tabular-nums block group-hover:text-[#8DDCFF] transition-colors">
                  {Number(profile.followersCount || 0).toLocaleString('en-US')}
                </span>
                <span className="text-[11px] text-[#A8BCD7]">Followers</span>
              </button>

              <div>
                <span className="font-mono font-bold text-sm text-[#F1F8FF] tabular-nums block">
                  {Math.max(0, authoritativePostCount ?? (Number(profile.postsCount) || 0)).toLocaleString('en-US')}
                </span>
                <span className="text-[11px] text-[#A8BCD7]">Discourses</span>
              </div>
            </div>
          </div>
        </div>

        {isOwnProfile && !profile.verified && (
          <button
            onClick={() => setShowVerificationModal(true)}
            className="mt-5 w-full flex items-center justify-center gap-2 rounded-xl border border-[#8DDCFF]/40 bg-gradient-to-r from-[#0D47A1]/40 to-[#168BFF]/20 px-4 py-3 text-sm font-bold text-[#D7ECFF] hover:border-[#8DDCFF] transition-colors"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>✦ Get Your Profile Verified (৳{Number.isFinite(Number(platformSettings?.verificationFee)) && Number(platformSettings?.verificationFee) > 0 ? Number(platformSettings?.verificationFee).toLocaleString('en-US') : 120})</span>
          </button>
        )}
        {/* Action Controls Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 sm:gap-3 pt-5 sm:pt-6 mt-5 sm:mt-6 border-t border-[#168BFF]/15 min-w-0">
          <button
            onClick={handleShareProfile}
            className="p-2 rounded-xl bg-[#071A38] text-[#A8BCD7] hover:text-[#8DDCFF] border border-[#168BFF]/20 transition-colors relative"
            title="Copy profile link"
          >
            {copiedLink ? <Check className="w-4 h-4 text-[#8DDCFF]" /> : <Share2 className="w-4 h-4" />}
          </button>

          <div className="relative shrink-0">
            <button
              type="button"
              aria-label="More profile settings"
              aria-expanded={showProfileMenu}
              onClick={() => setShowProfileMenu((open) => !open)}
              className="p-2 rounded-xl bg-[#071A38] text-[#A8BCD7] hover:text-[#8DDCFF] border border-[#168BFF]/20 transition-colors"
              title="More options"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
            {showProfileMenu && (
              <>
              <button type="button" aria-label="Close profile menu" onClick={() => setShowProfileMenu(false)} className="fixed inset-0 z-[90] bg-black/55 sm:hidden" />
              <div role="menu" aria-label="Profile options" className="fixed inset-x-3 bottom-3 z-[100] max-h-[min(72dvh,560px)] overflow-y-auto overscroll-contain rounded-2xl border border-[#8DDCFF]/30 bg-[#06142B] p-2 shadow-[0_18px_50px_rgba(0,0,0,.75)] [padding-bottom:calc(0.5rem+env(safe-area-inset-bottom))] sm:absolute sm:inset-x-auto sm:bottom-auto sm:right-0 sm:top-11 sm:z-40 sm:w-72 sm:max-h-[min(70vh,560px)] sm:bg-[#06142B]/[.98]">
                <div className="flex items-center justify-between gap-2 px-3 pt-2 pb-1 sm:hidden"><strong className="text-sm text-[#F1F8FF]">Profile options</strong><button type="button" onClick={() => setShowProfileMenu(false)} className="rounded-lg border border-[#168BFF]/30 p-2 text-[#A8BCD7]" aria-label="Close menu"><span className="text-xs">Close</span></button></div>
                {isOwnProfile && (
                  <button role="menuitem" type="button" onClick={() => onThemePreferenceChange?.(themePreference === 'crystal_dark' ? 'moonlight_manor' : 'crystal_dark')} className="w-full min-w-0 flex items-center gap-3 rounded-xl px-3 py-3 text-left hover:bg-[#168BFF]/15">
                    {themePreference === 'crystal_dark' ? <Sun className="w-4 h-4 text-emerald-300" /> : <Moon className="w-4 h-4 text-[#8DDCFF]" />}
                    <span className="min-w-0 flex-1"><strong className="block text-xs text-[#F1F8FF]">{themePreference === 'crystal_dark' ? '8 Ball Pool Theme' : '8 Ball Pool Theme'}</strong><span className="block text-[10px] text-[#A8BCD7] mt-0.5">{themePreference === 'crystal_dark' ? 'Turn on Moonlight Manor · Crystal Crypt is active' : 'Turn off to return to Crystal Crypt'}</span></span>
                    <span className={`relative h-5 w-9 rounded-full transition-colors ${themePreference === 'moonlight_manor' ? 'bg-emerald-500' : 'bg-slate-600'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform ${themePreference === 'moonlight_manor' ? 'translate-x-4' : 'translate-x-0.5'}`} /></span>
                  </button>
                )}
                {isOwnProfile && currentUserProfile && (
                  <>
                    <button role="menuitem" type="button" onClick={async () => { setShowProfileMenu(false); try { if (currentUserProfile?.email) localStorage.setItem('opencirkle_last_account_to_switch', currentUserProfile.email); await logout(); onOpenAuth(); } catch (e) { setUpdateNotice((e as Error)?.message || 'Could not sign out.'); } }} className="w-full min-w-0 flex items-start gap-3 rounded-xl px-3 py-3 text-left hover:bg-[#168BFF]/15">
                      <Shield className="w-4 h-4 mt-0.5 text-[#8DDCFF]" />
                      <span><strong className="block text-xs text-[#F1F8FF]">Add / Switch Account</strong><span className="block text-[10px] text-[#A8BCD7] mt-0.5">Sign in with another account</span></span>
                    </button>
                    <button role="menuitem" type="button" onClick={async () => { setShowProfileMenu(false); try { if (currentUserProfile?.email) localStorage.setItem('opencirkle_last_account_to_switch', currentUserProfile.email); await logout(); onOpenAuth(); } catch (e) { setUpdateNotice((e as Error)?.message || 'Could not sign out.'); } }} className="w-full min-w-0 flex items-start gap-3 rounded-xl px-3 py-3 text-left hover:bg-red-500/10">
                      <UserX className="w-4 h-4 mt-0.5 text-red-300" />
                      <span><strong className="block text-xs text-[#F1F8FF]">Log out</strong><span className="block text-[10px] text-[#A8BCD7] mt-0.5">Sign out of this account</span></span>
                    </button>
                  </>
                )}
                {isOwnProfile && <button role="menuitem" type="button" onClick={handleAppUpdate} className="w-full min-w-0 flex items-start gap-3 rounded-xl px-3 py-3 text-left hover:bg-[#168BFF]/15 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#8DDCFF]">
                  <Download className="w-4 h-4 mt-0.5 text-[#8DDCFF]" />
                  <span><strong className="block text-xs text-[#F1F8FF]">Update This App{platformSettings?.appUpdateVersion ? ` · ${platformSettings.appUpdateVersion}` : ''}</strong><span className="block text-[10px] text-[#A8BCD7] mt-0.5">{platformSettings?.appUpdateEnabled && platformSettings?.appUpdateUrl ? 'Download the latest release' : 'Check for available updates'}</span></span>
                </button>}
                {isOwnProfile && platformSettings?.appUpdateNotes && platformSettings?.appUpdateEnabled && (
                  <p className="mx-3 mb-2 text-[10px] leading-4 text-[#A8BCD7] whitespace-pre-wrap">{platformSettings.appUpdateNotes}</p>
                )}
                {isOwnProfile ? (
                  <>
                    <button type="button" onClick={() => { setShowProfileMenu(false); setShowEditModal(true); }} className="w-full min-w-0 flex items-center gap-3 rounded-xl px-3 py-3 text-left hover:bg-[#168BFF]/15 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#8DDCFF]"><Settings className="w-4 h-4 text-[#8DDCFF]" /><span className="text-xs text-[#F1F8FF]">Edit profile settings</span></button>
                    <button type="button" onClick={() => { setShowProfileMenu(false); setShowMonetization(true); }} className="w-full min-w-0 flex items-center gap-3 rounded-xl px-3 py-3 text-left hover:bg-[#168BFF]/15 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#8DDCFF]"><Wallet className="w-4 h-4 text-[#8DDCFF]" /><span className="text-xs text-[#F1F8FF]">Monetize & Wallet</span></button>
                    <button type="button" onClick={handlePrivacyToggle} className="w-full min-w-0 flex items-center gap-3 rounded-xl px-3 py-3 text-left hover:bg-[#168BFF]/15 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#8DDCFF]"><Shield className="w-4 h-4 text-[#8DDCFF]" /><span className="text-xs text-[#F1F8FF]">Make account {profile.isPrivate ? 'Public' : 'Private'}</span></button>
                  </>
                ) : (
                  <button type="button" onClick={() => { setShowProfileMenu(false); setShowReportModal(true); }} className="w-full min-w-0 flex items-center gap-3 rounded-xl px-3 py-3 text-left hover:bg-[#168BFF]/15 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#8DDCFF]"><Flag className="w-4 h-4 text-[#FF9B9B]" /><span className="text-xs text-[#F1F8FF]">Report this profile</span></button>
                )}
                <button type="button" onClick={() => window.location.reload()} className="w-full min-w-0 flex items-center gap-3 rounded-xl px-3 py-3 text-left hover:bg-[#168BFF]/15 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#8DDCFF]"><RefreshCw className="w-4 h-4 text-[#8DDCFF]" /><span className="text-xs text-[#F1F8FF]">Refresh app</span></button>
              </div>
              </>
            )}
          </div>

          {isOwnProfile ? (
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 min-w-0">
            <button
              type="button"
              onClick={() => setShowMonetization(true)}
              className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-[#8DDCFF] bg-[#071A38]/80 border border-[#168BFF]/40 rounded-xl hover:bg-[#0D47A1]/40 hover:border-[#8DDCFF]/60 transition-all active:scale-95"
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>Monetize</span>
            </button>
            <button
              onClick={() => setShowEditModal(true)}
              className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-[#0D47A1] to-[#168BFF] rounded-xl hover:shadow-[0_0_15px_rgba(22,139,255,0.4)] transition-all active:scale-95"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Profile</span>
            </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              {currentUserProfile && onStartChat && (
                <button
                  onClick={() => onStartChat(profile)}
                  className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#8DDCFF] bg-[#071A38] hover:bg-[#0D47A1]/40 border border-[#168BFF]/30 rounded-xl transition-all"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Message</span>
                </button>
              )}

              <button
                onClick={handleFollowToggle}
                disabled={followBusy}
                className={`px-5 py-2 text-xs font-semibold rounded-xl transition-all shadow-[0_0_15px_rgba(22,139,255,0.3)] ${
                  followStatus === 'following'
                    ? 'bg-[#071A38] text-[#8DDCFF] border border-[#168BFF]/30'
                    : followStatus === 'requested'
                    ? 'bg-[#071A38] text-[#FFD166] border border-[#FFD166]/30'
                    : 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white hover:shadow-[0_0_20px_rgba(22,139,255,0.5)]'
                }`}
              >
                {followStatus === 'following'
                  ? 'Following'
                  : followStatus === 'requested'
                  ? 'Requested'
                  : 'Connect'}
              </button>
            </div>
          )}
        </div>
      </div>


      {updateNotice && (
        <div role="status" className="mb-4 rounded-xl border border-[#8DDCFF]/25 bg-[#071A38] px-4 py-3 text-xs text-[#8DDCFF]">{updateNotice}</div>
      )}

      {/* Profile Tabs: iOS Rounded Liquid Glass Pill */}
      <div className="flex items-center gap-1.5 p-1 rounded-full ios-liquid-glass-subtle border border-[#8DDCFF]/20 mb-6">
        <button
          onClick={() => setActiveTab('posts')}
          className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-full ios-press transition-all ${
            activeTab === 'posts'
              ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white shadow-[0_0_15px_rgba(22,139,255,0.4)] border border-[#8DDCFF]/30'
              : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
          }`}
        >
          Discourses ({posts.length})
        </button>

        {isOwnProfile && (
          <button
            onClick={() => setActiveTab('saved')}
            className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-full ios-press transition-all ${
              activeTab === 'saved'
                ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white shadow-[0_0_15px_rgba(22,139,255,0.4)] border border-[#8DDCFF]/30'
                : 'text-[#A8BCD7] hover:text-[#F1F8FF]'
            }`}
          >
            Vault Bookmarks
          </button>
        )}
      </div>

      {/* Posts Stream */}
      {postsLoading ? (
        <div className="py-8 text-center text-xs font-mono text-[#A8BCD7] animate-pulse">
          Loading discourses...
        </div>
      ) : posts.length === 0 ? (
        <div className="rounded-3xl ios-liquid-glass p-8 text-center text-xs text-[#A8BCD7] border border-[#168BFF]/15">
          {activeTab === 'saved'
            ? 'Your vault is currently empty. Bookmark posts in the feed to save them here.'
            : 'No discourses engraved yet.'}
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post, idx) => (
            <PostCard
              key={`profile-post-${post.id || 'p'}-${idx}`}
              post={post}
              onPostDeleted={(id) => setPosts((prev) => prev.filter((p) => p.id !== id))}
              onPostUpdated={(up) => setPosts((prev) => prev.map((p) => (p.id === up.id ? up : p)))}
              onHashtagClick={onHashtagClick}
              onUserClick={onUserClick}
              onOpenAuth={onOpenAuth}
            />
          ))}
        </div>
      )}

      {showReportModal && !isOwnProfile && profile && (
        <ReportModal
          targetType="user"
          targetId={profile.uid}
          targetAuthorId={profile.uid}
          targetAuthorUsername={profile.username}
          onClose={() => setShowReportModal(false)}
        />
      )}

      {/* Identity verification and payment flow */}
      {showVerificationModal && (
        <VerificationRequestModal onClose={() => setShowVerificationModal(false)} />
      )}

      {/* Edit Profile Modal */}
      {showEditModal && (
        <EditProfileModal
          onClose={() => setShowEditModal(false)}
          onProfileUpdated={() => {
            if (currentUserProfile) setProfile(currentUserProfile);
          }}
        />
      )}

      {/* Followers / Following List Modal */}
      {userListType && profile && (
        <UserListModal
          userId={profile.uid}
          type={userListType}
          onClose={() => setUserListType(null)}
          onUserClick={onUserClick}
        />
      )}
    </div>
  );
};
