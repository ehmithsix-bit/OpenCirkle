import React, { useState, useEffect } from 'react';
import { UserProfile } from '../../types';
import { fetchFollowersList, fetchFollowingList, toggleFollowUser } from '../../services/socialService';
import { useAuth } from '../../context/AuthContext';
import { CrystalAvatar } from '../common/CrystalAvatar';
import { X, Users } from 'lucide-react';
import VerifiedBadge from '../common/VerifiedBadge';

interface UserListModalProps {
  userId: string;
  type: 'followers' | 'following';
  onClose: () => void;
  onUserClick: (username: string) => void;
}

export const UserListModal: React.FC<UserListModalProps> = ({
  userId,
  type,
  onClose,
  onUserClick,
}) => {
  const { currentUserProfile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showOthers, setShowOthers] = useState(false);
  const PREVIEW_COUNT = 5;
  const visibleUsers = showOthers ? users : users.slice(0, PREVIEW_COUNT);
  const remainingCount = Math.max(0, users.length - PREVIEW_COUNT);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const list =
          type === 'followers'
            ? await fetchFollowersList(userId)
            : await fetchFollowingList(userId);
        let mergedList = list;
        // Local-only sample follows appear in the current user's Following list without Firebase writes.
        if (type === 'following' && currentUserProfile?.uid === userId) {
          try {
            const saved = JSON.parse(window.localStorage.getItem(`opencirkle:virtual-following:${userId}`) || '[]') as Array<UserProfile & { isVirtualProfile?: boolean }>;
            const realIds = new Set(list.map((u) => u.uid));
            mergedList = [...list, ...saved.filter((u) => !realIds.has(u.uid))];
          } catch (err) {
            console.warn('Could not load local sample follows:', err);
          }
        }
        if (active) setUsers(mergedList);
      } catch (err) {
        console.error('Failed to load user list:', err);
      } finally {
        if (active) setLoading(false);
      }
    };
    load();
    return () => {
      active = false;
    };
  }, [userId, type, currentUserProfile?.uid]);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#050A18]/85 backdrop-blur-md">
      <div className="rounded-t-[32px] sm:rounded-3xl ios-liquid-glass w-full max-w-md p-6 border border-[#8DDCFF]/30 shadow-[0_16px_50px_rgba(0,0,0,0.85)] relative max-h-[85vh] flex flex-col animate-slide-up sm:animate-in sm:fade-in sm:zoom-in-95 duration-200">
        <div className="w-10 h-1 bg-[#8DDCFF]/40 rounded-full mx-auto mb-4 sm:hidden shrink-0" />
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-[#A8BCD7] hover:text-[#F1F8FF] rounded-full hover:bg-[#071A38] transition-colors ios-press"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#168BFF]/15">
          <Users className="w-4 h-4 text-[#8DDCFF]" />
          <h3 className="text-base font-bold text-[#F1F8FF] capitalize">
            {type === 'followers' ? 'Followers' : 'Following'}
          </h3>
        </div>

        <div className="overflow-y-auto space-y-3 flex-1 pr-1">
          {loading ? (
            <div className="py-8 text-center text-xs font-mono text-[#A8BCD7] animate-pulse">
              Retrieving connections...
            </div>
          ) : users.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#A8BCD7] italic">
              No {type} discovered in this node.
            </div>
          ) : (
            visibleUsers.map((u) => (
              <div key={u.uid} className="flex items-center justify-between gap-3 p-2 rounded-xl hover:bg-[#071A38]/50 transition-colors">
                <button
                  onClick={() => {
                    onUserClick(u.username);
                    onClose();
                  }}
                  className="flex items-center gap-3 text-left group min-w-0"
                >
                  <CrystalAvatar
                    displayName={u.displayName}
                    username={u.username}
                    avatarSymbol={u.avatarSymbol}
                    avatarUrl={u.avatarUrl}
                    avatarColor={u.avatarColor}
                    size="sm"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <span className="text-xs font-semibold text-[#F1F8FF] group-hover:text-[#8DDCFF] transition-colors truncate">
                        {u.displayName}
                      </span>
                      {u.verified && (
                        <VerifiedBadge size="sm" title="Verified account" placement="displayName" className="align-middle" />
                      )}
                    </div>
                    <span className="text-[11px] font-mono text-[#A8BCD7] truncate block">
                      @{u.username}
                    </span>
                  </div>
                </button>
              </div>
            ))
          )}
          {!loading && users.length > PREVIEW_COUNT && (
            <button
              type="button"
              onClick={() => setShowOthers((current) => !current)}
              className="w-full mt-2 px-4 py-3 rounded-xl border border-[#168BFF]/25 bg-[#071A38]/55 text-sm font-semibold text-[#8DDCFF] hover:bg-[#0B2850]/70 transition-colors"
            >
              {showOthers ? 'Show less' : `Others (${remainingCount})`}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
