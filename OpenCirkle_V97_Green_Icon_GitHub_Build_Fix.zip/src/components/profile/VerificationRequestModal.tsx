import React, { useEffect, useMemo, useState } from 'react';
import { addDoc, collection, doc, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { CheckCircle2, ChevronLeft, CreditCard, FileCheck2, ShieldCheck, Upload, X } from 'lucide-react';
import bkashLogo from '../../assets/payment/bkash-logo.png';
import nagadLogo from '../../assets/payment/nagad-logo.jpg';
import sslcommerzLogo from '../../assets/payment/sslcommerz-powered.png';

type DocType = 'nid' | 'passport' | 'driving_license';
type PaymentMethod = 'bKash' | 'Nagad';

interface Props { onClose: () => void; }

const DEFAULT_PAYMENT_NUMBER = '01916293234';
const DEFAULT_VERIFICATION_FEE = 120;
const MAX_IMAGE_BYTES = 220 * 1024;

async function compressImage(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) throw new Error('JPG, PNG বা WebP ছবি নির্বাচন করুন।');
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 1400 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('ছবি প্রস্তুত করা যাচ্ছে না।');
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  let quality = 0.72;
  let data = canvas.toDataURL('image/jpeg', quality);
  while (Math.ceil((data.length * 3) / 4) > MAX_IMAGE_BYTES && quality > 0.3) {
    quality -= 0.08;
    data = canvas.toDataURL('image/jpeg', quality);
  }
  if (Math.ceil((data.length * 3) / 4) > MAX_IMAGE_BYTES) throw new Error('ছবিটি খুব বড়। আরও ছোট/কম রেজোলিউশনের ছবি দিন।');
  return data;
}

export const VerificationRequestModal: React.FC<Props> = ({ onClose }) => {
  const { currentUserProfile } = useAuth();
  const [step, setStep] = useState<1 | 2>(1);
  const [docType, setDocType] = useState<DocType>('nid');
  const [docNumber, setDocNumber] = useState('');
  const [frontFile, setFrontFile] = useState<File | null>(null);
  const [backFile, setBackFile] = useState<File | null>(null);
  const [method, setMethod] = useState<PaymentMethod>('bKash');
  const [paymentSettings, setPaymentSettings] = useState({ verificationFee: DEFAULT_VERIFICATION_FEE, bKashPaymentNumber: DEFAULT_PAYMENT_NUMBER, nagadPaymentNumber: DEFAULT_PAYMENT_NUMBER, verificationPaymentInstructions: 'Send Money করুন, তারপর আসল Transaction ID লিখুন। Admin পেমেন্ট যাচাই করবেন।' });
  const [trxId, setTrxId] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  const docLabel = useMemo(() => ({ nid: 'National ID (NID)', passport: 'Passport', driving_license: 'Driving License' }[docType]), [docType]);
  const paymentNumber = method === 'bKash' ? paymentSettings.bKashPaymentNumber : paymentSettings.nagadPaymentNumber;

  useEffect(() => {
    // Keep fee, receiver numbers, and payment instructions synchronized with admin changes.
    return onSnapshot(doc(db, 'platformSettings', 'global'), snap => {
      if (!snap.exists()) return;
      const data = snap.data();
      setPaymentSettings(prev => ({
        verificationFee: Number.isFinite(Number(data.verificationFee)) && Number(data.verificationFee) > 0 ? Number(data.verificationFee) : prev.verificationFee,
        bKashPaymentNumber: String(data.bKashPaymentNumber || prev.bKashPaymentNumber),
        nagadPaymentNumber: String(data.nagadPaymentNumber || prev.nagadPaymentNumber),
        verificationPaymentInstructions: String(data.verificationPaymentInstructions || prev.verificationPaymentInstructions),
      }));
    }, err => console.warn('Could not load live verification payment settings; using defaults.', err));
  }, []);

  const continueToPayment = () => {
    setMessage('');
    if (!currentUserProfile) { setMessage('আগে লগইন করুন।'); return; }
    if (docNumber.trim().length < 4) { setMessage('সঠিক ডকুমেন্ট নম্বর লিখুন।'); return; }
    if (!frontFile || !backFile) { setMessage('ডকুমেন্টের সামনের ও পেছনের ছবি দিন।'); return; }
    setStep(2);
  };

  const submitRequest = async () => {
    if (!currentUserProfile || busy) return;
    setBusy(true); setMessage('ছবি প্রস্তুত করে আবেদন জমা হচ্ছে…');
    try {
      if (!frontFile || !backFile) throw new Error('সামনের ও পেছনের ছবি দুটোই প্রয়োজন।');
      const [frontImageData, backImageData] = await Promise.all([compressImage(frontFile), compressImage(backFile)]);
      const combinedBytes = Math.ceil((frontImageData.length + backImageData.length) * 3 / 4);
      if (combinedBytes > 520 * 1024) throw new Error('দুটি ছবির মোট সাইজ বেশি। ছোট ছবি দিয়ে আবার চেষ্টা করুন।');
      const created = await addDoc(collection(db, 'verification_requests'), {
        uid: currentUserProfile.uid,
        username: currentUserProfile.username,
        displayName: currentUserProfile.displayName,
        email: currentUserProfile.email || '',
        documentType: docType,
        documentLabel: docLabel,
        documentNumber: docNumber.trim(),
        frontImageData,
        backImageData,
        paymentAmount: paymentSettings.verificationFee,
        currency: 'BDT',
        paymentMethod: method,
        paymentNumber,
        transactionId: trxId.trim(),
        paymentStatus: 'needs_manual_review',
        status: 'pending',
        submittedAt: Date.now(),
        submittedAtServer: serverTimestamp(),
        reviewDeadlineHours: 24,
      });
      setMessage(`আবেদন জমা হয়েছে। আবেদন ID: ${created.id}। Admin পেমেন্ট ও ডকুমেন্ট যাচাই করে ২৪ ঘণ্টার মধ্যে সিদ্ধান্ত দেবেন।`);
      setFrontFile(null); setBackFile(null);
    } catch (err: any) {
      console.error('Verification request failed:', err);
      setMessage(err?.message || 'আবেদন জমা হয়নি। Firestore rules ও connection পরীক্ষা করুন।');
    } finally { setBusy(false); }
  };

  return <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-3" role="dialog" aria-modal="true" aria-label="Profile verification">
    <div className="w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-3xl border border-[#168BFF]/40 bg-[#07152E] text-[#F1F8FF] shadow-2xl">
      <div className="sticky top-0 z-10 flex items-center justify-between p-5 border-b border-[#168BFF]/20 bg-[#07152E]">
        <div className="flex items-center gap-3"><div className="rounded-xl bg-[#168BFF]/15 p-2"><ShieldCheck className="w-6 h-6 text-[#8DDCFF]" /></div><div><h2 className="font-bold">Get Your Profile Verified</h2><p className="text-xs text-[#A8BCD7]">One-time review fee · ৳{paymentSettings.verificationFee}</p></div></div>
        <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/10" aria-label="Close"><X className="w-5 h-5" /></button>
      </div>
      <div className="p-5 space-y-4">
        <div className="flex gap-2 text-xs"><div className={`flex-1 rounded-xl p-2 text-center border ${step === 1 ? 'border-[#168BFF] bg-[#168BFF]/15' : 'border-white/10 text-[#A8BCD7]'}`}>1. Identity</div><div className={`flex-1 rounded-xl p-2 text-center border ${step === 2 ? 'border-[#168BFF] bg-[#168BFF]/15' : 'border-white/10 text-[#A8BCD7]'}`}>2. Payment</div></div>
        {step === 1 ? <>
          <label className="block text-xs text-[#A8BCD7] space-y-1"><span>Document type</span><select value={docType} onChange={e => setDocType(e.target.value as DocType)} className="w-full rounded-xl bg-[#050A18] border border-[#168BFF]/25 p-3 text-sm text-white"><option value="nid">National ID (NID)</option><option value="passport">Passport</option><option value="driving_license">Driving License</option></select></label>
          <label className="block text-xs text-[#A8BCD7] space-y-1"><span>Document number / ID No.</span><input value={docNumber} onChange={e => setDocNumber(e.target.value)} maxLength={60} className="w-full rounded-xl bg-[#050A18] border border-[#168BFF]/25 p-3 text-sm text-white" placeholder="Enter your document number" /></label>
          {[{label:'Front side photo',file:frontFile,set:setFrontFile},{label:'Back side photo',file:backFile,set:setBackFile}].map(item => <label key={item.label} className="block rounded-xl border border-dashed border-[#168BFF]/40 p-3 space-y-2 cursor-pointer"><span className="flex items-center gap-2 text-xs font-semibold"><Upload className="w-4 h-4 text-[#8DDCFF]" />{item.label}</span><span className="block text-[11px] text-[#A8BCD7]">{item.file ? item.file.name : 'Choose JPG / PNG / WebP image'}</span><input type="file" accept="image/jpeg,image/png,image/webp" className="block w-full text-xs" onChange={e => item.set(e.target.files?.[0] || null)} /></label>)}
          <p className="text-[11px] text-amber-200/90">Privacy note: Storage is not used. Compressed ID images and ID number are saved inside the Firestore verification request; ensure Firestore rules restrict access to the applicant and authorized admins only.</p>
          <button onClick={continueToPayment} className="w-full rounded-xl bg-gradient-to-r from-[#0D47A1] to-[#168BFF] p-3 font-bold text-sm">Continue to Pay ৳{paymentSettings.verificationFee} <CreditCard className="inline w-4 h-4 ml-1" /></button>
        </> : <>
          <div className="rounded-2xl border border-[#168BFF]/25 bg-[#050A18] p-4 space-y-3"><p className="text-sm font-bold">Send Money: ৳{paymentSettings.verificationFee}</p><div className="grid grid-cols-2 gap-3"><button type="button" aria-label="Select bKash" aria-pressed={method === 'bKash'} onClick={() => setMethod('bKash')} className={`min-h-20 rounded-xl border p-3 flex items-center justify-center transition-all ${method === 'bKash' ? 'border-pink-400 bg-pink-500/15 ring-2 ring-pink-400/30' : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06]'}`}><img src={bkashLogo} alt="bKash" className="h-14 w-14 rounded-lg object-contain" /></button><button type="button" aria-label="Select Nagad" aria-pressed={method === 'Nagad'} onClick={() => setMethod('Nagad')} className={`min-h-20 rounded-xl border p-3 flex items-center justify-center transition-all ${method === 'Nagad' ? 'border-orange-400 bg-orange-500/15 ring-2 ring-orange-400/30' : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06]'}`}><img src={nagadLogo} alt="Nagad" className="h-14 w-14 rounded-lg object-contain bg-white" /></button></div><div className="flex flex-col items-center gap-1 pt-1"><img src={sslcommerzLogo} alt="Powered by SSLCommerz" className="w-full max-w-[270px] h-auto object-contain rounded-md bg-white" /><span className="text-[10px] text-[#A8BCD7]/75">Secure payment instructions</span></div><div className="rounded-xl bg-white/5 p-3"><p className="text-[11px] text-[#A8BCD7]">{method} Send Money number</p><p className="text-xl font-mono font-bold tracking-wide">{paymentNumber}</p><button onClick={() => navigator.clipboard?.writeText(paymentNumber)} className="mt-2 text-xs text-[#8DDCFF] underline">Copy number</button></div><ol className="list-decimal pl-5 space-y-1 text-xs text-[#A8BCD7]"><li>{method} অ্যাপে Send Money করুন।</li><li>ঠিক ৳{paymentSettings.verificationFee} পাঠান।</li><li>পেমেন্টের আসল Transaction ID নিচে লিখুন।</li></ol><p className="text-xs text-[#A8BCD7]">{paymentSettings.verificationPaymentInstructions}</p></div>
          <label className="block text-xs text-[#A8BCD7] space-y-1"><span>Transaction ID (TRX ID)</span><input value={trxId} onChange={e => setTrxId(e.target.value)} maxLength={80} className="w-full rounded-xl bg-[#050A18] border border-[#168BFF]/25 p-3 text-sm text-white" placeholder="Enter transaction ID" /></label>
          <div className="flex gap-2"><button disabled={busy} onClick={() => setStep(1)} className="flex-1 rounded-xl border border-white/15 p-3 text-sm"><ChevronLeft className="inline w-4 h-4" /> Back</button><button disabled={busy || trxId.trim().length < 6} onClick={submitRequest} className="flex-[2] rounded-xl bg-gradient-to-r from-[#0D47A1] to-[#168BFF] p-3 font-bold text-sm disabled:opacity-50">{busy ? 'Submitting…' : 'Submit Verification Request'}</button></div>
        </>}
        {message && <div className="rounded-xl border border-[#168BFF]/30 bg-[#168BFF]/10 p-3 text-xs text-[#D7ECFF] break-words"><FileCheck2 className="inline w-4 h-4 mr-1" />{message}</div>}
        <p className="text-[10px] text-[#A8BCD7]/80 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Badge activates only after Admin approval. Review target: within 24 hours.</p>
      </div>
    </div>
  </div>;
};
