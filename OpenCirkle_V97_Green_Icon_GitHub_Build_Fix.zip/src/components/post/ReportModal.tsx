import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { ReportItem } from '../../types';
import { submitReport } from '../../services/moderationService';
import { ShieldAlert, X, CheckCircle2, AlertCircle } from 'lucide-react';

interface ReportModalProps {
  targetType: 'post' | 'comment' | 'user';
  targetId: string;
  targetAuthorId?: string;
  targetAuthorUsername?: string;
  targetSnippet?: string;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  targetType,
  targetId,
  targetAuthorId,
  targetAuthorUsername,
  targetSnippet,
  onClose,
}) => {
  const { currentUserProfile } = useAuth();
  const [reason, setReason] = useState<ReportItem['reason']>('spam');
  const [explanation, setExplanation] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUserProfile) return;

    setSubmitting(true);
    setError(null);

    try {
      await submitReport({
        reporter: currentUserProfile,
        targetType,
        targetId,
        targetAuthorId,
        targetAuthorUsername,
        targetSnippet,
        reason,
        explanation,
      });
      setSuccess(true);
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      setError(err?.message || 'Failed to submit report.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#050A18]/80 backdrop-blur-md">
      <div className="rounded-t-[32px] sm:rounded-3xl ios-liquid-glass w-full max-w-md p-6 border border-[#8DDCFF]/30 shadow-[0_16px_50px_rgba(0,0,0,0.85)] relative animate-slide-up sm:animate-in sm:fade-in sm:zoom-in-95 duration-200">
        <div className="w-10 h-1 bg-[#8DDCFF]/40 rounded-full mx-auto mb-4 sm:hidden" />
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-[#A8BCD7] hover:text-[#F1F8FF] rounded-full hover:bg-[#071A38] transition-colors ios-press"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-[#FF6B6B]/15 border border-[#FF6B6B]/30 flex items-center justify-center text-[#FF6B6B]">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#F1F8FF]">Report Content</h3>
            <p className="text-xs text-[#A8BCD7]">Submitted to OpenCirkle moderators</p>
          </div>
        </div>

        {success ? (
          <div className="py-6 text-center space-y-2">
            <CheckCircle2 className="w-10 h-10 text-[#8DDCFF] mx-auto animate-bounce" />
            <p className="text-sm font-semibold text-[#F1F8FF]">Report Received</p>
            <p className="text-xs text-[#A8BCD7]">
              Thank you for keeping the crystal crypt safe and authentic.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {targetSnippet && (
              <div className="p-3 rounded-xl bg-[#050A18]/70 border border-[#168BFF]/20 text-xs text-[#A8BCD7]">
                <span className="font-semibold text-[#8DDCFF] block mb-1">Target Snippet:</span>
                <p className="italic line-clamp-2">"{targetSnippet}"</p>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">
                Violation Reason
              </label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value as ReportItem['reason'])}
                className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl px-3 py-2 text-xs text-[#F1F8FF] focus:outline-none focus:border-[#168BFF]"
              >
                <option value="spam">Spam or unwanted solicitation</option>
                <option value="harassment">Harassment or targeted abuse</option>
                <option value="hate_speech">Hate speech or discrimination</option>
                <option value="impersonation">Impersonation or deception</option>
                <option value="misinformation">Harmful misinformation</option>
                <option value="other">Other policy violation</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#F1F8FF] mb-1.5">
                Additional Details (Optional)
              </label>
              <textarea
                value={explanation}
                onChange={(e) => setExplanation(e.target.value)}
                placeholder="Explain the context for review..."
                maxLength={500}
                rows={3}
                className="w-full bg-[#050A18] border border-[#168BFF]/25 rounded-xl p-3 text-xs text-[#F1F8FF] placeholder-[#A8BCD7]/50 focus:outline-none focus:border-[#168BFF] resize-none"
              />
            </div>

            {error && (
              <div className="flex items-center gap-2 text-xs text-[#FF6B6B] bg-[#FF6B6B]/10 p-2.5 rounded-lg border border-[#FF6B6B]/20">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-[#A8BCD7] hover:text-[#F1F8FF] rounded-xl hover:bg-[#071A38] transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-4 py-2 text-xs font-semibold text-white bg-[#FF6B6B]/80 hover:bg-[#FF6B6B] rounded-xl shadow-[0_0_15px_rgba(255,107,107,0.3)] transition-all disabled:opacity-50"
              >
                {submitting ? 'Submitting...' : 'Send Report'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
