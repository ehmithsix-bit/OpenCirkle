import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { Post, UserProfile } from '../../types';
import { getLatestUserProfile } from '../../services/latestProfileService';
import {
  toggleLikePost,
  checkIsLiked,
  toggleBookmarkPost,
  checkIsBookmarked,
  togglePinPost,
  deletePost,
  recordPostView,
} from '../../services/postService';
import { toggleBlockUser } from '../../services/authService';
import { CrystalAvatar } from '../common/CrystalAvatar';
import { CommentSection } from './CommentSection';
import { LinkPreview } from './LinkPreview';
import { ReportModal } from './ReportModal';
import { QuoteModal } from './QuoteModal';
import { EditPostModal } from './EditPostModal';
import { BoostPostModal } from './BoostPostModal';
import { ShareToUserModal } from '../messages/ShareToUserModal';
import VerifiedBadge from '../common/VerifiedBadge';
import {
  Heart,
  MessageSquare,
  Repeat2,
  Bookmark,
  Share2,
  MoreHorizontal,
  Pin,
  Edit3,
  Trash2,
  ShieldAlert,
  UserX,
  CheckCircle2,
  Check,
  TrendingUp,
  Eye,
  X,
} from 'lucide-react';

const formatCompactCount = (value: number): string => {
  const count = Math.max(0, Number.isFinite(Number(value)) ? Number(value) : 0);
  if (count >= 1_000_000) return `${(count / 1_000_000).toFixed(count >= 10_000_000 ? 0 : 1).replace(/\.0$/, '')}M`;
  if (count >= 1_000) return `${(count / 1_000).toFixed(count >= 10_000 ? 0 : 1).replace(/\.0$/, '')}K`;
  return String(Math.floor(count));
};

interface PostCardProps {
  post: Post;
  onPostDeleted?: (postId: string) => void;
  onPostUpdated?: (updatedPost: Post) => void;
  onHashtagClick?: (tag: string) => void;
  onUserClick?: (username: string) => void;
  onOpenAuth?: () => void;
}

const PostCardComponent: React.FC<PostCardProps> = ({
  post,
  onPostDeleted,
  onPostUpdated,
  onHashtagClick,
  onUserClick,
  onOpenAuth,
}) => {
  const { currentUserProfile, isModerator } = useAuth();
  const [acceptedCollaborators, setAcceptedCollaborators] = useState<Array<{ userId: string; username: string; displayName: string; avatarSymbol?: Post['authorAvatarSymbol']; avatarColor?: Post['authorAvatarColor']; avatarUrl?: string }>>([]);
  const [liveAuthor, setLiveAuthor] = useState<Partial<UserProfile> | null>(null);

  // Post author fields are historical snapshots. Prefer the current canonical profile.
  useEffect(() => {
    let active = true;
    if (!post?.authorId) { setLiveAuthor(null); return; }
    if (currentUserProfile?.uid === post.authorId) {
      setLiveAuthor(currentUserProfile);
      return;
    }
    getLatestUserProfile(post.authorId).then((profile) => {
      if (active && profile) setLiveAuthor(profile);
    });
    return () => { active = false; };
  }, [post?.authorId, currentUserProfile]);

  useEffect(() => {
    if (!post?.id) return;
    let cancelled = false;
    // Most posts have no collaborators; avoid one Firestore query per ordinary card.
    if (!post.collaboratorIds?.length && !post.collaborators?.length) {
      setAcceptedCollaborators([]);
      return () => { cancelled = true; };
    }
    const loadAcceptedCollaborators = async () => {
      try {
        const q = query(collection(db, 'postCollaborationResponses'), where('postId', '==', post.id));
        const responseSnap = await getDocs(q);
        const accepted = responseSnap.docs
          .map(d => d.data() as { userId: string; username?: string; displayName?: string; status: string })
          .filter(c => c.status === 'accepted' && c.userId);
        if (!accepted.length) { if (!cancelled) setAcceptedCollaborators([]); return; }
        const profiles = await Promise.all(accepted.map(async collaborator => {
          const live = await getLatestUserProfile(collaborator.userId);
          return {
            userId: collaborator.userId,
            username: typeof live?.username === 'string' && live.username ? live.username : (collaborator.username || 'user'),
            displayName: typeof live?.displayName === 'string' && live.displayName ? live.displayName : (collaborator.displayName || collaborator.username || 'OpenCirkle user'),
            avatarSymbol: live?.avatarSymbol || 'gem', avatarColor: live?.avatarColor || 'electric',
            avatarUrl: typeof live?.avatarUrl === 'string' ? live.avatarUrl : undefined,
          };
        }));
        if (!cancelled) setAcceptedCollaborators(profiles);
      } catch (error) { console.warn('Could not load accepted post collaborators:', error); }
    };
    void loadAcceptedCollaborators();
    return () => { cancelled = true; };
  }, [post?.id, post?.collaboratorIds?.length, post?.collaborators?.length]);

  const authorUsername = liveAuthor?.username || post.authorUsername;
  const authorDisplayName = liveAuthor?.displayName || post.authorDisplayName || authorUsername;
  const authorVerified = liveAuthor?.verified ?? post.authorVerified;
  const authorAvatarSymbol = liveAuthor?.avatarSymbol || post.authorAvatarSymbol;
  const authorAvatarColor = liveAuthor?.avatarColor || post.authorAvatarColor;
  const authorAvatarUrl = liveAuthor?.avatarUrl || post.authorAvatarUrl;
  const communityCategory = post.communityCategory || (post as Post & { communityCategory?: string }).communityCategory;

  const [isLiked, setIsLiked] = useState(false);
  const [likeBusy, setLikeBusy] = useState(false);
  const [likesCount, setLikesCount] = useState(Math.max(0, Number(post.likesCount) || 0));
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [bookmarksCount, setBookmarksCount] = useState(Math.max(0, Number(post.bookmarksCount) || 0));
  const [commentsCount, setCommentsCount] = useState(Math.max(0, Number(post.commentsCount) || 0));
  const [viewsCount, setViewsCount] = useState(Math.max(0, Number(post.viewsCount) || 0));
  const [showComments, setShowComments] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [menuPosition, setMenuPosition] = useState<{ top: number; right: number; maxHeight: number } | null>(null);
  const menuButtonRef = useRef<HTMLButtonElement | null>(null);
  useEffect(() => {
    if (!showMenu) return;
    const closeOnScroll = () => setShowMenu(false);
    const closeOnResize = () => setShowMenu(false);
    window.addEventListener('scroll', closeOnScroll, true);
    window.addEventListener('resize', closeOnResize);
    return () => {
      window.removeEventListener('scroll', closeOnScroll, true);
      window.removeEventListener('resize', closeOnResize);
    };
  }, [showMenu]);
  const [copiedShare, setCopiedShare] = useState(false);
  const [showShareToUser, setShowShareToUser] = useState(false);

  // Modals state
  const [showReportModal, setShowReportModal] = useState(false);
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showBoostModal, setShowBoostModal] = useState(false);

  const isAuthor = currentUserProfile?.uid === post.authorId;
  const isPinned = Boolean(post.isPinned);

  useEffect(() => {
    setViewsCount(Math.max(0, Number(post.viewsCount) || 0));
    recordPostView(post.id).then((counted) => { if (counted) setViewsCount((count) => Math.max(0, count + 1)); }).catch(() => undefined);
  }, [post.id]);

  // Check initial like and bookmark status
  useEffect(() => {
    let active = true;
    if (currentUserProfile) {
      checkIsLiked(post.id, currentUserProfile.uid).then((val) => {
        if (active) setIsLiked(val);
      });
      checkIsBookmarked(post.id, currentUserProfile.uid).then((val) => {
        if (active) setIsBookmarked(val);
      });
    }
    return () => {
      active = false;
    };
  }, [post.id, currentUserProfile]);

  const handleLike = async () => {
    if (!currentUserProfile) {
      if (onOpenAuth) onOpenAuth();
      return;
    }

    if (likeBusy) return;
    setLikeBusy(true);
    const previousLiked = isLiked;
    const previousCount = likesCount;

    // Optimistic UI update
    setIsLiked(!previousLiked);
    setLikesCount(Math.max(0, previousLiked ? previousCount - 1 : previousCount + 1));

    try {
      const result = await toggleLikePost(post.id, currentUserProfile);
      setIsLiked(result);
    } catch (err) {
      // Rollback on error
      setIsLiked(previousLiked);
      setLikesCount(previousCount);
      console.error('Error toggling like:', err);
    } finally {
      setLikeBusy(false);
    }
  };

  const handleBookmark = async () => {
    if (!currentUserProfile) {
      if (onOpenAuth) onOpenAuth();
      return;
    }

    const previousBookmarked = isBookmarked;
    const previousCount = bookmarksCount;

    setIsBookmarked(!previousBookmarked);
    setBookmarksCount(Math.max(0, previousBookmarked ? previousCount - 1 : previousCount + 1));

    try {
      const result = await toggleBookmarkPost(post.id, currentUserProfile.uid);
      setIsBookmarked(result);
    } catch (err) {
      setIsBookmarked(previousBookmarked);
      setBookmarksCount(previousCount);
      console.error('Error toggling bookmark:', err);
    }
  };

  const handleTogglePin = async () => {
    if (!currentUserProfile || !isAuthor) return;
    try {
      const result = await togglePinPost(post.id, currentUserProfile.uid);
      if (onPostUpdated) {
        onPostUpdated({ ...post, isPinned: result });
      }
      setShowMenu(false);
    } catch (err) {
      console.error('Error pinning post:', err);
    }
  };

  const handleDelete = async () => {
    if (!currentUserProfile) return;
    const confirmed = window.confirm('Are you sure you want to remove this post from OpenCirkle?');
    if (!confirmed) return;

    try {
      await deletePost(post.id, currentUserProfile.uid, isModerator);
      if (onPostDeleted) {
        onPostDeleted(post.id);
      }
    } catch (err) {
      console.error('Error deleting post:', err);
    }
  };

  const handleBlockAuthor = async () => {
    if (!currentUserProfile || isAuthor) return;
    try {
      await toggleBlockUser(currentUserProfile.uid, post.authorId);
      setShowMenu(false);
      if (onPostDeleted) {
        onPostDeleted(post.id);
      }
    } catch (err) {
      console.error('Error blocking user:', err);
    }
  };

  const handleShare = async () => {
    if (!currentUserProfile) { onOpenAuth?.(); return; }
    setShowShareToUser(true);
  };

  const formatTimestamp = (timestamp: number) => {
    if (!timestamp) return 'recently';
    const diffSeconds = Math.floor((Date.now() - timestamp) / 1000);
    if (diffSeconds < 60) return 'just now';
    const diffMinutes = Math.floor(diffSeconds / 60);
    if (diffMinutes < 60) return `${diffMinutes}m`;
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours}h`;
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays < 7) return `${diffDays}d`;
    return new Intl.DateTimeFormat('en-BD', { timeZone: 'Asia/Dhaka', month: 'short', day: 'numeric' }).format(new Date(timestamp));
  };

  // Safe Text-Only Parser for links, hashtags, mentions
  const renderFormattedText = (raw?: any) => {
    if (raw === undefined || raw === null) return null;
    const str = typeof raw === 'string' ? raw : String(raw);
    if (str.length === 0) return null;

    const tokenRegex = /(https?:\/\/[^\s]+)|(#[\w\d_]+)|(@[\w\d_]+)/gi;
    const elements: React.ReactNode[] = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    try {
      while ((match = tokenRegex.exec(str)) !== null) {
        const matchIndex = match.index;
        if (matchIndex > lastIndex) {
          elements.push(str.slice(lastIndex, matchIndex));
        }

        const token = match[0];
        if (!token) continue;

        if (token.startsWith('http')) {
          elements.push(
            <a
              key={`link-${matchIndex}-${token.slice(0, 15)}`}
              href={token}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#8DDCFF] underline decoration-[#168BFF]/40 hover:text-white transition-colors break-all"
              onClick={(e) => e.stopPropagation()}
            >
              {token}
            </a>
          );
        } else if (token.startsWith('#')) {
          const cleanTag = token.slice(1);
          elements.push(
            <button
              key={`tag-${matchIndex}-${cleanTag}`}
              onClick={(e) => {
                e.stopPropagation();
                if (onHashtagClick) onHashtagClick(cleanTag);
              }}
              className="text-[#8DDCFF] hover:underline font-mono font-medium hover:text-[#168BFF] transition-colors"
            >
              {token}
            </button>
          );
        } else if (token.startsWith('@')) {
          const cleanUser = token.slice(1);
          elements.push(
            <button
              key={`user-${matchIndex}-${cleanUser}`}
              onClick={(e) => {
                e.stopPropagation();
                if (onUserClick) onUserClick(cleanUser);
              }}
              className="text-[#168BFF] hover:underline font-mono font-medium hover:text-[#8DDCFF] transition-colors"
            >
              {token}
            </button>
          );
        }

        lastIndex = tokenRegex.lastIndex;
      }

      if (lastIndex < str.length) {
        elements.push(str.slice(lastIndex));
      }

      return elements.length > 0 ? elements : str;
    } catch {
      return str;
    }
  };

  return (
    <article
      id={`post-${post.id}`}
      className="oc-text-post rounded-[28px] ios-liquid-glass p-5 md:p-6 mb-3 transition-colors relative overflow-visible hover:border-[#8DDCFF]/35 [content-visibility:auto] [contain-intrinsic-size:auto_360px]"
    >
      {/* Pinned Banner */}
      {isPinned && (
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#8DDCFF] mb-3 pb-2 border-b border-[#168BFF]/15">
          <Pin className="w-3.5 h-3.5 text-[#168BFF]" />
          <span>Pinned Discourse</span>
        </div>
      )}

      {/* Header: Author info & options */}
      <div className="flex min-w-0 items-start justify-between gap-2 mb-3">
        <button
          onClick={() => onUserClick && onUserClick(authorUsername)}
          className="flex min-w-0 flex-1 items-center gap-3 text-left group focus:outline-none overflow-hidden"
        >
          <div className="relative isolate z-0 flex items-center shrink-0 pl-0.5" aria-label={acceptedCollaborators.length ? `Collaborative post by ${authorUsername} and ${acceptedCollaborators.map(c => c.username).join(', ')}` : `Post by ${authorUsername}`}>
            <span className="relative z-30 rounded-full overflow-hidden">
              <CrystalAvatar displayName={authorDisplayName} username={authorUsername} avatarSymbol={authorAvatarSymbol} avatarUrl={authorAvatarUrl} avatarColor={authorAvatarColor} size="md" className="!border-0 !shadow-none !ring-0" />
            </span>
            {acceptedCollaborators.slice(0, 3).map((collaborator, index) => <span key={collaborator.userId} className={`-ml-3.5 relative ${index === 0 ? 'z-20' : index === 1 ? 'z-10' : 'z-0'} rounded-full overflow-hidden`} title={`${collaborator.displayName} (@${collaborator.username})`}><CrystalAvatar displayName={collaborator.displayName} username={collaborator.username} avatarSymbol={collaborator.avatarSymbol || 'gem'} avatarColor={collaborator.avatarColor || 'electric'} avatarUrl={collaborator.avatarUrl} size="md" className="!border-0 !shadow-none !ring-0" /></span>)}
            {acceptedCollaborators.length > 3 && <span className="-ml-3.5 relative z-0 grid h-10 w-10 shrink-0 place-items-center rounded-full border-2 border-[#07111F] bg-gradient-to-br from-[#173A68] to-[#07111F] text-[10px] font-bold text-white shadow-lg">+{acceptedCollaborators.length - 3}</span>}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex min-w-0 items-center gap-1.5 flex-wrap">
              <span className="font-bold text-[13px] text-[#F1F8FF] group-hover:text-[#8DDCFF] transition-colors truncate">
                @{authorUsername}
              </span>
              {authorVerified && <VerifiedBadge title="Verified account" />}
              {acceptedCollaborators.length > 0 && <span className="text-[11px] text-[#A8BCD7]">and</span>}
              {acceptedCollaborators.slice(0, 2).map((collaborator, index) => <React.Fragment key={collaborator.userId}><span className="max-w-[110px] truncate text-[13px] font-semibold text-[#DCEBFA]">@{collaborator.username}</span>{index === 0 && acceptedCollaborators.length > 1 && <span className="text-[11px] text-[#A8BCD7]">,</span>}</React.Fragment>)}
              {acceptedCollaborators.length > 2 && <span className="text-[11px] text-[#A8BCD7]">+{acceptedCollaborators.length - 2} more</span>}
            </div>
            <div className="mt-0.5 flex min-w-0 items-center gap-2 text-xs text-[#A8BCD7]">
              <span className="truncate">{authorDisplayName}{acceptedCollaborators.length > 0 ? ' · Collaborative post' : ''}</span>
              <span aria-hidden="true">·</span>
              <span className="shrink-0 font-mono tabular-nums">{formatTimestamp(post.createdAt)}</span>
              {post.editedAt && <><span aria-hidden="true">·</span><span className="italic text-[10px]">edited</span></>}
            </div>
          </div>
        </button>

        {/* Options Dropdown */}
        <div className="relative z-30 shrink-0 ml-0.5">
          <button
            ref={menuButtonRef}
            onClick={() => {
              if (showMenu) {
                setShowMenu(false);
                return;
              }
              const rect = menuButtonRef.current?.getBoundingClientRect();
              if (rect) {
                // Measure the real header and bottom dock instead of guessing fixed
                // offsets. The menu is portalled, so it must stay between these bounds.
                const header = document.querySelector<HTMLElement>('[data-oc-app-header="true"]')
                  || document.querySelector<HTMLElement>('.oc-app-shell > header');
                const dock = document.querySelector<HTMLElement>('.oc-kmf-bottom-nav');
                const headerBottom = header?.getBoundingClientRect().bottom ?? 64;
                const dockTop = dock?.getBoundingClientRect().top ?? (window.innerHeight - 12);
                const safeTop = Math.max(8, Math.ceil(headerBottom + 8));
                const safeBottom = Math.min(window.innerHeight - 8, Math.floor(dockTop - 10));
                const belowTop = Math.ceil(rect.bottom + 6);
                const aboveSpace = Math.max(0, Math.floor(rect.top - safeTop - 6));
                const belowSpace = Math.max(0, Math.floor(safeBottom - belowTop));
                const placeAbove = belowSpace < 220 && aboveSpace > belowSpace;
                const maxHeight = Math.max(96, Math.min(420, placeAbove ? aboveSpace : belowSpace));
                const top = placeAbove
                  ? Math.max(safeTop, Math.floor(rect.top - maxHeight - 6))
                  : Math.min(belowTop, Math.max(safeTop, safeBottom - maxHeight));
                const right = Math.max(8, Math.min(window.innerWidth - rect.right, window.innerWidth - 8));
                setMenuPosition({ top, right, maxHeight });
              }
              setShowMenu(true);
            }}
            type="button"
            className="relative z-20 flex h-10 w-10 min-w-10 shrink-0 items-center justify-center rounded-xl border border-[#168BFF]/35 bg-[#071A38]/95 text-[#D7ECFF] shadow-[0_2px_10px_rgba(22,139,255,.16)] transition-colors hover:border-[#8DDCFF]/70 hover:bg-[#0D47A1]/70 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#8DDCFF] active:scale-95"
            title="Post options"
            aria-label="Post options"
            data-post-options-button="true"
            aria-expanded={showMenu}
            aria-haspopup="menu"
          >
            <MoreHorizontal className="h-5 w-5" strokeWidth={2.5} />
          </button>

          {showMenu && createPortal((
            <div
              role="menu"
              className="fixed z-[950] w-52 max-w-[calc(100vw-16px)] rounded-xl bg-[#071A38] border border-[#168BFF]/30 shadow-[0_10px_30px_rgba(0,0,0,0.7)] py-1.5 text-xs text-[#F1F8FF] overflow-y-auto overscroll-contain"
              style={{ top: menuPosition?.top ?? 80, right: menuPosition?.right ?? 12, maxHeight: menuPosition?.maxHeight ?? 'min(65dvh, 420px)' }}
            >
              <div className="flex items-center justify-between px-3 py-2 border-b border-[#168BFF]/20 mb-1">
                <span className="font-semibold text-[#A8BCD7]">Post options</span>
                <button type="button" onClick={() => setShowMenu(false)} aria-label="Close post options" className="p-1.5 rounded-lg hover:bg-[#168BFF]/20 text-[#8DDCFF]"><X className="w-4 h-4" /></button>
              </div>
              {isAuthor && (
                <>
                  <button onClick={() => { setShowBoostModal(true); setShowMenu(false); }} className="w-full px-3 py-2 text-left flex items-center gap-2 text-[#8DDCFF] hover:bg-[#0D47A1]/40 transition-colors"><TrendingUp className="w-3.5 h-3.5"/><span>Boost Post</span></button>
                  <button
                    onClick={handleTogglePin}
                    className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-[#0D47A1]/40 transition-colors"
                  >
                    <Pin className="w-3.5 h-3.5 text-[#8DDCFF]" />
                    <span>{isPinned ? 'Unpin from Profile' : 'Pin to Profile'}</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowEditModal(true);
                      setShowMenu(false);
                    }}
                    className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-[#0D47A1]/40 transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-[#8DDCFF]" />
                    <span>Edit Post</span>
                  </button>
                </>
              )}

              {(isAuthor || isModerator) && (
                <button
                  onClick={handleDelete}
                  className="w-full px-3 py-2 text-left flex items-center gap-2 text-[#FF6B6B] hover:bg-[#FF6B6B]/15 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Post</span>
                </button>
              )}

              {!isAuthor && (
                <>
                  <button
                    onClick={() => {
                      setShowReportModal(true);
                      setShowMenu(false);
                    }}
                    className="w-full px-3 py-2 text-left flex items-center gap-2 hover:bg-[#0D47A1]/40 transition-colors"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-[#FFD166]" />
                    <span>Report Content</span>
                  </button>
                  {currentUserProfile && (
                    <button
                      onClick={handleBlockAuthor}
                      className="w-full px-3 py-2 text-left flex items-center gap-2 text-[#FF6B6B] hover:bg-[#FF6B6B]/15 transition-colors"
                    >
                      <UserX className="w-3.5 h-3.5" />
                      <span>Block @{authorUsername}</span>
                    </button>
                  )}
                </>
              )}
            </div>
          ), document.body)}
        </div>
      </div>

      {/* Virtual community category label */}
      {communityCategory && <div className="mb-2.5"><span className="inline-flex items-center rounded-full border border-[#168BFF]/25 bg-[#0D47A1]/20 px-2.5 py-1 text-[10px] font-semibold tracking-wide text-[#8DDCFF]">{communityCategory}</span></div>}

      {/* Main Text Content */}
      <div className="oc-post-copy text-[15px] md:text-base text-[#F1F8FF] leading-[1.7] whitespace-pre-wrap break-words mb-5">
        {renderFormattedText(post.content || (post as any)?.text || (post as any)?.body || '')}
      </div>

      <LinkPreview text={post.content || (post as any)?.text || (post as any)?.body || ''} />

      {/* Text-Only Quote Post Preview */}
      {post.isRepost && post.repostOf && (
        <div className="mb-4 p-3.5 rounded-xl bg-[#050A18]/70 border border-[#168BFF]/25 text-xs space-y-1.5">
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-[#8DDCFF]">
              {post.repostOf.authorDisplayName || post.repostOf.authorUsername}
            </span>
            <span className="font-mono text-[#A8BCD7]">
              @{post.repostOf.authorUsername}
            </span>
            <span aria-hidden="true" className="text-[#A8BCD7]">·</span>
            <span className="text-[10px] text-[#A8BCD7] font-mono">
              {formatTimestamp(post.repostOf.createdAt)}
            </span>
          </div>
          <p className="text-xs text-[#F1F8FF]/85 italic line-clamp-3">
            "{post.repostOf.content || ''}"
          </p>
        </div>
      )}

      {/* Social Interactions Bar */}
      <div className="oc-post-actions flex w-full items-center gap-0 pt-3 border-t border-[#8DDCFF]/15 text-xs text-[#A8BCD7]">
        {/* Views */}
        <div className="flex min-w-0 flex-1 items-center justify-center gap-1 py-1 px-1 whitespace-nowrap" title={`Post views: ${viewsCount.toLocaleString()}`}>
          <Eye className="w-4 h-4" />
          <span className="min-w-[3ch] text-center font-mono tabular-nums">{formatCompactCount(viewsCount)}</span>
        </div>

        {/* Like */}
        <button
          onClick={handleLike}
          disabled={likeBusy}
          className={`flex min-w-0 flex-1 items-center justify-center gap-1 py-1 px-1 rounded-lg whitespace-nowrap transition-all ${
            isLiked
              ? 'text-[#FF6B6B] bg-[#FF6B6B]/10 font-medium'
              : 'hover:text-[#FF6B6B] hover:bg-[#FF6B6B]/5'
          }`}
          title={isLiked ? 'Unlike' : 'Like'}
        >
          <Heart className={`w-4 h-4 transition-transform active:scale-125 ${isLiked ? 'fill-current' : ''}`} />
          <span title={`${likesCount.toLocaleString()} likes`} className="min-w-[3ch] text-center font-mono tabular-nums">{formatCompactCount(likesCount)}</span>
        </button>

        {/* Comment */}
        <button
          onClick={() => setShowComments(!showComments)}
          className={`flex min-w-0 flex-1 items-center justify-center gap-1 py-1 px-1 rounded-lg whitespace-nowrap transition-all ${
            showComments
              ? 'text-[#8DDCFF] bg-[#168BFF]/10 font-medium'
              : 'hover:text-[#8DDCFF] hover:bg-[#168BFF]/5'
          }`}
          title="Replies"
        >
          <MessageSquare className="w-4 h-4" />
          <span title={`${commentsCount.toLocaleString()} comments`} className="min-w-[3ch] text-center font-mono tabular-nums">{formatCompactCount(commentsCount)}</span>
        </button>

        {/* Quote / Repost */}
        <button
          onClick={() => {
            if (!currentUserProfile) {
              if (onOpenAuth) onOpenAuth();
              return;
            }
            setShowQuoteModal(true);
          }}
          className="flex min-w-0 flex-1 items-center justify-center gap-1 py-1 px-1 rounded-lg whitespace-nowrap hover:text-[#8DDCFF] hover:bg-[#168BFF]/5 transition-all"
          title="Quote Post"
        >
          <Repeat2 className="w-4 h-4" />
          <span title={`${Math.max(0, Number(post.repostsCount) || 0).toLocaleString()} reposts`} className="min-w-[3ch] text-center font-mono tabular-nums">{formatCompactCount(Number(post.repostsCount) || 0)}</span>
        </button>

        {/* Bookmark */}
        <button
          onClick={handleBookmark}
          className={`flex shrink-0 items-center justify-center gap-1 py-1 px-2 rounded-lg transition-all ${
            isBookmarked
              ? 'text-[#168BFF] bg-[#168BFF]/10 font-medium'
              : 'hover:text-[#168BFF] hover:bg-[#168BFF]/5'
          }`}
          title={isBookmarked ? 'Remove Bookmark' : 'Save post'} aria-label={isBookmarked ? 'Remove saved post' : 'Save post'}
        >
          <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
        </button>

        {/* Share */}
        <button
          onClick={handleShare}
          className="flex shrink-0 items-center justify-center gap-1 py-1 px-2 rounded-lg hover:text-[#8DDCFF] hover:bg-[#168BFF]/5 transition-all relative"
          title="Share link"
        >
          {copiedShare ? <Check className="w-4 h-4 text-[#8DDCFF]" /> : <Share2 className="w-4 h-4" />}
          {copiedShare && (
            <span className="absolute -top-7 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded bg-[#071A38] text-[10px] text-[#8DDCFF] border border-[#168BFF]/30 whitespace-nowrap shadow-md">
              Copied!
            </span>
          )}
        </button>
      </div>

      {/* Inline Comments Section */}
      {showComments && (
        <CommentSection
          post={post}
          onCommentsUpdated={() => setCommentsCount((c) => Math.max(0, c + 1))}
          onOpenAuth={onOpenAuth}
          onViewProfile={onUserClick}
        />
      )}

      {/* Modals */}
      {showReportModal && (
        <ReportModal
          targetType="post"
          targetId={post.id}
          targetAuthorId={post.authorId}
          targetAuthorUsername={authorUsername}
          targetSnippet={post.content}
          onClose={() => setShowReportModal(false)}
        />
      )}

      {showQuoteModal && (
        <QuoteModal
          post={post}
          onClose={() => setShowQuoteModal(false)}
          onPostCreated={(newP) => {
            if (onPostUpdated) {
              onPostUpdated({ ...post, repostsCount: (post.repostsCount || 0) + 1 });
            }
          }}
        />
      )}

      {showBoostModal && <BoostPostModal post={{ id: post.id, content: post.content || '' }} onClose={() => setShowBoostModal(false)} />}
      {showShareToUser && <ShareToUserModal title={`OpenCirkle post by @${authorUsername}`} shareText={post.content || ''} shareUrl={`${window.location.origin}/#post-${encodeURIComponent(post.id)}`} onClose={() => setShowShareToUser(false)} />}
      {showEditModal && (
        <EditPostModal
          post={post}
          onClose={() => setShowEditModal(false)}
          onPostUpdated={(updated) => {
            if (onPostUpdated) onPostUpdated(updated);
          }}
        />
      )}
    </article>
  );
};

// Feed updates often append or replace a single post; memoization keeps unchanged cards
// from repeating their render work when their inputs have not changed.
export const PostCard = React.memo(PostCardComponent);
