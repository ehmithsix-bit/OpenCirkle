import React, { useEffect, useMemo, useState } from 'react';
import { ExternalLink, Globe, LoaderCircle, Play } from 'lucide-react';

type PreviewData = {
  title?: string;
  description?: string;
  image?: { url?: string } | string;
  logo?: { url?: string } | string;
  publisher?: string;
  url?: string;
};

export const findFirstUrl = (text: string): string | null => {
  const match = text.match(/(?:https?:\/\/|www\.)[^\s<>"']+/i);
  if (!match) return null;
  let candidate = match[0].replace(/[),.!?;:]+$/, '');
  if (/^www\./i.test(candidate)) candidate = `https://${candidate}`;
  try {
    const parsed = new URL(candidate);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:' ? parsed.href : null;
  } catch { return null; }
};

const getAssetUrl = (value: PreviewData['image'] | PreviewData['logo']): string | undefined => {
  if (typeof value === 'string') return value;
  return value?.url;
};

const getYouTubeId = (url: string): string | null => {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.replace(/^www\./, '').toLowerCase();
    if (host === 'youtu.be') return parsed.pathname.split('/').filter(Boolean)[0] || null;
    if (host.endsWith('youtube.com')) {
      if (parsed.pathname === '/watch') return parsed.searchParams.get('v');
      const match = parsed.pathname.match(/^\/(?:shorts|embed|live)\/([^/?]+)/);
      return match?.[1] || null;
    }
  } catch { /* invalid URL */ }
  return null;
};

const platformName = (hostname: string): string => {
  const host = hostname.replace(/^www\./, '').toLowerCase();
  if (host.includes('youtube.com') || host === 'youtu.be') return 'YouTube';
  if (host === 'facebook.com' || host.endsWith('.facebook.com') || host === 'fb.watch') return 'Facebook';
  if (host === 'instagram.com' || host.endsWith('.instagram.com')) return 'Instagram';
  if (host === 'tiktok.com' || host.endsWith('.tiktok.com')) return 'TikTok';
  if (host === 'x.com' || host === 'twitter.com') return 'X';
  if (host === 'whatsapp.com' || host === 'wa.me') return 'WhatsApp';
  if (host === 'youtu.be') return 'YouTube';
  return hostname.replace(/^www\./, '');
};

export const LinkPreview: React.FC<{ text: string; compact?: boolean }> = ({ text, compact = false }) => {
  const url = findFirstUrl(text);
  const [data, setData] = useState<PreviewData | null>(null);
  const [loading, setLoading] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);

  const parsed = useMemo(() => {
    if (!url) return null;
    try {
      const u = new URL(url);
      const youtubeId = getYouTubeId(url);
      return {
        hostname: u.hostname.replace(/^www\./, ''),
        publisher: platformName(u.hostname),
        youtubeId,
        favicon: `https://www.google.com/s2/favicons?domain=${encodeURIComponent(u.hostname)}&sz=128`,
      };
    } catch { return null; }
  }, [url]);

  useEffect(() => {
    let cancelled = false;
    setData(null);
    setImageFailed(false);
    if (!url) { setLoading(false); return; }
    setLoading(true);
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 8000);
    fetch(`https://api.microlink.io/?url=${encodeURIComponent(url)}&screenshot=false`, { signal: controller.signal })
      .then((response) => { if (!response.ok) throw new Error('Preview unavailable'); return response.json(); })
      .then((json) => {
        if (cancelled || json?.status !== 'success') return;
        const result = json.data || {};
        setData({ title: result.title, description: result.description, image: result.image, logo: result.logo, publisher: result.publisher, url: result.url || url });
      })
      .catch(() => { /* A useful domain/platform fallback is still rendered below. */ })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; controller.abort(); window.clearTimeout(timer); };
  }, [url]);

  if (!url || !parsed) return null;
  const imageUrl = getAssetUrl(data?.image) || (parsed.youtubeId ? `https://img.youtube.com/vi/${encodeURIComponent(parsed.youtubeId)}/hqdefault.jpg` : undefined);
  const logoUrl = getAssetUrl(data?.logo) || parsed.favicon;
  const title = data?.title?.trim() || (parsed.youtubeId ? 'Watch this video on YouTube' : `Open on ${parsed.publisher}`);
  const description = data?.description?.trim();

  return (
    <a href={url} target="_blank" rel="noopener noreferrer" onClick={(event) => event.stopPropagation()}
      aria-label={`Open link preview: ${title}`}
      className={`block overflow-hidden rounded-2xl border border-[#168BFF]/30 bg-[#050A18]/75 hover:border-[#8DDCFF]/60 transition-colors ${compact ? 'mt-3' : 'mt-2'}`}>
      {imageUrl && !compact && !imageFailed && <div className="relative w-full aspect-[16/7] bg-[#071A38] overflow-hidden"><img src={imageUrl} alt={`${parsed.publisher} link preview`} loading="lazy" referrerPolicy="no-referrer" className="w-full h-full object-cover" onError={() => setImageFailed(true)} />{parsed.youtubeId && <span className="absolute inset-0 flex items-center justify-center"><span className="rounded-full bg-black/70 p-3 text-white"><Play className="w-6 h-6 fill-current" /></span></span>}</div>}
      <div className="p-3 flex gap-3 items-start">
        {logoUrl ? <img src={logoUrl} alt="" loading="lazy" referrerPolicy="no-referrer" className="w-8 h-8 rounded-lg object-contain bg-white/5 shrink-0" onError={(e) => { e.currentTarget.style.display = 'none'; }} /> : <span className="w-8 h-8 rounded-lg bg-[#168BFF]/15 flex items-center justify-center text-[#8DDCFF] shrink-0"><Globe className="w-4 h-4" /></span>}
        <div className="min-w-0 flex-1">
          <div className="text-[10px] uppercase tracking-wider text-[#8DDCFF] flex items-center gap-1"><span className="truncate">{data?.publisher || parsed.publisher}</span><ExternalLink className="w-3 h-3 shrink-0" /></div>
          <div className="mt-1 text-sm font-semibold text-[#F1F8FF] line-clamp-2">{title}</div>
          {description && <p className="mt-1 text-xs leading-relaxed text-[#A8BCD7] line-clamp-3">{description}</p>}
          {loading && <div className="mt-1 text-[10px] text-[#A8BCD7] flex items-center gap-1"><LoaderCircle className="w-3 h-3 animate-spin" /> Loading website details…</div>}
          <div className="mt-1 text-[10px] text-[#8DDCFF]/80 break-all line-clamp-1">{url}</div>
        </div>
      </div>
    </a>
  );
};
