import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Post, UserProfile } from '../../types';
import { createPost, MAX_POST_LENGTH, searchCollaboratorUsers } from '../../services/postService';
import { CrystalAvatar } from '../common/CrystalAvatar';
import { PenSquare, Hash, X, AlertCircle, CalendarClock, Lock, Globe, Link2, UserPlus, Tags } from 'lucide-react';
import { LinkPreview, findFirstUrl } from './LinkPreview';

interface PostComposerProps {
  onPostCreated?: (newPost: Post) => void;
  onClose?: () => void;
  quotePost?: Post | null;
  placeholder?: string;
  isModal?: boolean;
}

export const PostComposer: React.FC<PostComposerProps> = ({
  onPostCreated,
  onClose,
  quotePost = null,
  placeholder = "Engrave your thoughts in pure crystalline text...",
  isModal = false,
}) => {
  const { currentUserProfile } = useAuth();
  const [content, setContent] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [privacy, setPrivacy] = useState<'public' | 'private'>('public');
  const [communityCategory, setCommunityCategory] = useState('');
  const [scheduleEnabled, setScheduleEnabled] = useState(false);
  const [scheduledAt, setScheduledAt] = useState('');
  const [collaboratorQuery, setCollaboratorQuery] = useState('');
  const [selectedCollaborators, setSelectedCollaborators] = useState<UserProfile[]>([]);
  const [collaboratorSuggestions, setCollaboratorSuggestions] = useState<UserProfile[]>([]);
  const [searchingCollaborators, setSearchingCollaborators] = useState(false);

  const charCount = content.length;
  const charsRemaining = MAX_POST_LENGTH - charCount;
  const isOverLimit = charCount > MAX_POST_LENGTH;
  const isPostingAllowed = charCount > 0 && !isOverLimit && !submitting;
  const postCategories = ['News & Updates', 'Sports', 'Technology', 'Entertainment', 'Education', 'Business & Career', 'Lifestyle', 'Food', 'Travel', 'Health & Fitness', 'Books & Ideas', 'Photography', 'Questions', 'Opinion', 'Personal Update', 'Community Discussion', 'Other'];

  useEffect(() => {
    if (!isModal || !onClose) return;
    const handleEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isModal, onClose]);

  useEffect(() => {
    if (!currentUserProfile) return;
    const prefix = collaboratorQuery.trim().replace(/^@/, '');
    if (!prefix) { setCollaboratorSuggestions([]); setSearchingCollaborators(false); return; }
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      setSearchingCollaborators(true);
      try {
        const matches = await searchCollaboratorUsers(prefix, currentUserProfile.uid, 8);
        if (!cancelled) setCollaboratorSuggestions(matches.filter(u => !selectedCollaborators.some(s => s.uid === u.uid)));
      } catch (searchError) {
        console.warn('Collaborator username search failed:', searchError);
        if (!cancelled) setCollaboratorSuggestions([]);
      } finally { if (!cancelled) setSearchingCollaborators(false); }
    }, 220);
    return () => { cancelled = true; window.clearTimeout(timer); };
  }, [collaboratorQuery, currentUserProfile?.uid, selectedCollaborators]);

  const addCollaborator = (user: UserProfile) => {
    if (selectedCollaborators.length >= 6 || selectedCollaborators.some(existing => existing.uid === user.uid)) return;
    setSelectedCollaborators(prev => [...prev, user]);
    setCollaboratorQuery('');
    setCollaboratorSuggestions([]);
  };

  if (!currentUserProfile) return null;

  const handleInsertTag = (tag: string) => {
    setContent((prev) => (prev ? `${prev} #${tag} ` : `#${tag} `));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isPostingAllowed) return;

    setSubmitting(true);
    setError(null);

    try {
      const scheduledTime = scheduleEnabled && scheduledAt ? new Date(scheduledAt).getTime() : null;
      if (scheduleEnabled && (!scheduledTime || !Number.isFinite(scheduledTime) || scheduledTime <= Date.now())) { setError('Please choose a future date and time to schedule.'); setSubmitting(false); return; }
      const created = await createPost(currentUserProfile, content, quotePost, { privacy, scheduledAt: scheduledTime, collaboratorUsernames: selectedCollaborators.map(user => user.username), communityCategory: communityCategory || undefined });
      // Short success chime; invoked from the user's submit gesture so mobile browsers can permit audio.
      try { const AudioCtx = window.AudioContext || (window as any).webkitAudioContext; if (AudioCtx) { const ctx = new AudioCtx(); const osc = ctx.createOscillator(); const gain = ctx.createGain(); osc.type = 'sine'; osc.frequency.setValueAtTime(880, ctx.currentTime); osc.frequency.setValueAtTime(1174.66, ctx.currentTime + 0.10); gain.gain.setValueAtTime(0.0001, ctx.currentTime); gain.gain.exponentialRampToValueAtTime(0.12, ctx.currentTime + 0.02); gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.24); osc.connect(gain); gain.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime + 0.26); osc.onended = () => { void ctx.close(); }; } } catch (soundError) { console.debug('Post success sound unavailable:', soundError); }
      setContent('');
      setPrivacy('public'); setCommunityCategory(''); setScheduleEnabled(false); setScheduledAt(''); setCollaboratorQuery(''); setSelectedCollaborators([]); setCollaboratorSuggestions([]);
      if (onPostCreated) {
        onPostCreated(created);
      }
      if (onClose) {
        onClose();
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to publish post. Please verify connection.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className={`rounded-t-[24px] sm:rounded-3xl ios-liquid-glass p-4 sm:p-5 md:p-6 border border-[#8DDCFF]/30 shadow-[0_16px_50px_rgba(0,0,0,0.8)] ${
        isModal ? 'relative flex max-h-[calc(100dvh-env(safe-area-inset-top)-env(safe-area-inset-bottom))] w-full max-w-2xl flex-col overflow-y-auto overscroll-contain mx-auto animate-slide-up' : 'mb-6'
      }`}
    >
      {/* iOS Modal Grabber Bar */}
      {isModal && (
        <div className="w-10 h-1 bg-[#8DDCFF]/40 rounded-full mx-auto mb-3 shrink-0" />
      )}
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#168BFF]/15">
        <div className="flex items-center gap-3">
          <CrystalAvatar
            displayName={currentUserProfile.displayName}
            username={currentUserProfile.username}
            avatarSymbol={currentUserProfile.avatarSymbol}
                avatarUrl={currentUserProfile.avatarUrl}
            avatarColor={currentUserProfile.avatarColor}
            size="sm"
          />
          <div>
            <span className="text-xs font-semibold text-[#F1F8FF]">
              {currentUserProfile.displayName}
            </span>
            <span className="text-[11px] font-mono text-[#A8BCD7] block">
              @{currentUserProfile.username}
            </span>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[#8DDCFF]/25 bg-[#071A38] text-[#A8BCD7] hover:text-white hover:bg-[#0D47A1]/60 transition-colors"
            aria-label="Close post composer"
            title="Close"
            type="button"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      <form onSubmit={handleSubmit} className="min-w-0 space-y-4 pb-1">
        <div className="rounded-xl border border-[#168BFF]/20 bg-[#050A18]/50 p-3 space-y-2">
          <label htmlFor="post-collaborators" className="text-xs font-semibold text-[#8DDCFF] flex items-center gap-1.5"><UserPlus className="w-3.5 h-3.5" /> Collaborators (optional)</label>
          {selectedCollaborators.length > 0 && <div className="flex flex-wrap gap-1.5">{selectedCollaborators.map(user => <span key={user.uid} className="inline-flex items-center gap-1 rounded-full border border-[#8DDCFF]/30 bg-[#168BFF]/10 px-2 py-1 text-[11px] text-[#F1F8FF]">@{user.username}<button type="button" aria-label={`Remove @${user.username}`} onClick={() => setSelectedCollaborators(prev => prev.filter(item => item.uid !== user.uid))} className="ml-0.5 text-[#A8BCD7] hover:text-white"><X className="h-3 w-3" /></button></span>)}</div>}
          <div className="relative">
            <input id="post-collaborators" autoComplete="off" value={collaboratorQuery} onChange={e => setCollaboratorQuery(e.target.value)} placeholder="Type a username to find people…" className="w-full rounded-lg border border-[#168BFF]/20 bg-[#071A38] px-3 py-2 text-xs text-[#F1F8FF] outline-none focus:border-[#8DDCFF]" />
            {(searchingCollaborators || collaboratorSuggestions.length > 0) && <div className="absolute z-30 mt-1 max-h-56 w-full overflow-y-auto rounded-xl border border-[#168BFF]/30 bg-[#071A38] shadow-2xl">{searchingCollaborators && <div className="px-3 py-2 text-[11px] text-[#A8BCD7]">Searching users…</div>}{collaboratorSuggestions.map(user => <button type="button" key={user.uid} onClick={() => addCollaborator(user)} className="flex w-full items-center gap-2 px-3 py-2 text-left hover:bg-[#168BFF]/15"><CrystalAvatar displayName={user.displayName || user.username} username={user.username} avatarSymbol={user.avatarSymbol || 'gem'} avatarUrl={user.avatarUrl} avatarColor={user.avatarColor || 'electric'} size="sm" /><span className="min-w-0"><span className="block truncate text-xs font-semibold text-[#F1F8FF]">{user.displayName || user.username}</span><span className="block text-[10px] text-[#8DDCFF]">@{user.username}</span></span></button>)}</div>}
            {!searchingCollaborators && collaboratorQuery.trim() && collaboratorSuggestions.length === 0 && <p className="mt-1 text-[10px] text-[#8199B9]">No matching users found. Try another username.</p>}
          </div>
          <p className="text-[10px] text-[#8199B9]">Type the first letters of a username, then select a person from the suggestions. Selected users must accept the invitation before appearing as collaborators.</p>
        </div>

        {/* Quote post preview if quoting */}
        {quotePost && (
          <div className="p-3.5 rounded-xl bg-[#050A18]/80 border border-[#168BFF]/30 text-xs text-[#A8BCD7] space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-[#8DDCFF]">{quotePost.authorDisplayName}</span>
              <span className="font-mono text-[#A8BCD7]">@{quotePost.authorUsername}</span>
            </div>
            <p className="line-clamp-2 italic text-[#F1F8FF]/90 font-sans">
              "{quotePost.content}"
            </p>
          </div>
        )}

        {/* Text-Only Input */}
        <div className="relative">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={placeholder}
            rows={isModal ? 5 : 3}
            maxLength={MAX_POST_LENGTH + 100}
            className="w-full bg-[#050A18]/60 border border-[#168BFF]/20 rounded-xl p-3.5 text-sm text-[#F1F8FF] placeholder-[#A8BCD7]/50 focus:outline-none focus:border-[#168BFF] focus:ring-1 focus:ring-[#168BFF] transition-all resize-y min-h-[90px]"
          />
        </div>

        {findFirstUrl(content) && (
          <div className="rounded-xl border border-[#168BFF]/20 bg-[#071A38]/40 p-3">
            <div className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold text-[#8DDCFF]"><Link2 className="w-3.5 h-3.5" /> Website link preview</div>
            <LinkPreview text={content} compact={false} />
          </div>
        )}

        <div className="rounded-xl border border-[#168BFF]/20 bg-[#050A18]/50 p-3 space-y-2">
          <label htmlFor="post-category" className="flex items-center gap-1.5 text-xs font-semibold text-[#8DDCFF]"><Tags className="h-3.5 w-3.5" /> Post category <span className="font-normal text-[#8199B9]">(optional)</span></label>
          <select id="post-category" value={communityCategory} onChange={e => setCommunityCategory(e.target.value)} className="w-full rounded-lg border border-[#168BFF]/25 bg-[#071A38] px-3 py-2.5 text-sm text-white outline-none focus:border-[#8DDCFF]">
            <option value="">No category</option>
            {postCategories.map(category => <option key={category} value={category}>{category}</option>)}
          </select>
          <p className="text-[10px] text-[#8199B9]">Everyone can choose a category for their own text post. It helps readers discover relevant discussions.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <label className="text-xs text-[#A8BCD7]">Post privacy
            <span className="relative mt-1 block">
              <select value={privacy} onChange={(e) => setPrivacy(e.target.value as 'public' | 'private')} className="w-full appearance-none rounded-xl bg-[#050A18] border border-[#168BFF]/25 px-3 py-2.5 pr-9 text-sm text-white focus:outline-none focus:border-[#168BFF]">
                <option value="public">🌐 Public — everyone can see</option>
                <option value="private">🔒 Private — only me</option>
              </select>
              {privacy === 'private' ? <Lock className="absolute right-3 top-3 w-4 h-4" /> : <Globe className="absolute right-3 top-3 w-4 h-4" />}
            </span>
          </label>
          <div className="text-xs text-[#A8BCD7]">
            <label className="flex items-center gap-2 mt-5 text-sm text-white"><input type="checkbox" checked={scheduleEnabled} onChange={(e) => setScheduleEnabled(e.target.checked)} /> <CalendarClock className="w-4 h-4" /> Schedule post</label>
            {scheduleEnabled && <input type="datetime-local" value={scheduledAt} min={new Date(Date.now() + 60000).toISOString().slice(0,16)} onChange={(e) => setScheduledAt(e.target.value)} className="mt-2 w-full rounded-xl bg-[#050A18] border border-[#168BFF]/25 px-3 py-2 text-sm text-white" />}
            {scheduleEnabled && <p className="mt-1 text-[10px]">Scheduled posts are saved with a future time. Automatic publishing requires a trusted server/Cloud Function.</p>}
          </div>
        </div>

        {submitting && <div role="status" aria-live="polite" className="rounded-xl border border-[#168BFF]/30 bg-[#168BFF]/10 p-3 text-xs text-[#8DDCFF]">Processing your post… This status is visible only in your own composer. Please keep the app open until publishing finishes.</div>}

        {error && (
          <div className="flex items-center gap-2 text-xs text-[#FF6B6B] bg-[#FF6B6B]/10 p-2.5 rounded-lg border border-[#FF6B6B]/20">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Suggested Crystalline Topics & Character Meter */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] text-[#A8BCD7] flex items-center gap-1 mr-1">
              <Hash className="w-3 h-3 text-[#168BFF]" /> Topics:
            </span>
            {['OpenCirkle', 'Cryptography', 'Ideas', 'Philosophy'].map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => handleInsertTag(tag)}
                className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-[#071A38] text-[#8DDCFF] hover:bg-[#0D47A1]/40 border border-[#168BFF]/20 transition-colors"
              >
                #{tag}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4 ml-auto">
            {/* Tabular Character Counter */}
            <div className="text-right">
              <span
                className={`text-xs font-mono tabular-nums ${
                  isOverLimit
                    ? 'text-[#FF6B6B] font-bold'
                    : charsRemaining < 200
                    ? 'text-[#FFD166]'
                    : 'text-[#A8BCD7]'
                }`}
              >
                {charCount.toLocaleString()} / {MAX_POST_LENGTH.toLocaleString()}
              </span>
            </div>

            <button
              type="submit"
              disabled={!isPostingAllowed}
              className={`px-5 py-2 text-xs font-semibold rounded-xl flex items-center gap-2 transition-all shadow-[0_0_15px_rgba(22,139,255,0.3)] ${
                isPostingAllowed
                  ? 'bg-gradient-to-r from-[#0D47A1] to-[#168BFF] text-white hover:shadow-[0_0_20px_rgba(22,139,255,0.5)] active:scale-95'
                  : 'bg-[#071A38] text-[#A8BCD7]/40 cursor-not-allowed border border-[#168BFF]/10'
              }`}
            >
              {submitting ? <span className="inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-white/40 border-t-white" /> : <PenSquare className="w-3.5 h-3.5" />}
              <span>{submitting ? 'Processing post…' : scheduleEnabled ? 'Schedule Post' : 'Publish'}</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
