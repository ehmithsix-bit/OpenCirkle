import { sanitizeTextOnlyContent, parseTagsAndMentions, MAX_POST_LENGTH } from '../services/postService';
import * as fs from 'fs';
import * as path from 'path';

export function runOpenCirkleTests() {
  const fbPath = path.resolve(process.cwd(), 'src/lib/firebase.ts');
  const fbContent = fs.readFileSync(fbPath, 'utf-8');
  if (fbContent.includes('firebase/storage') || fbContent.includes('getStorage')) {
    throw new Error('Security Violation: Firebase Storage found in codebase.');
  }

  const composerPath = path.resolve(process.cwd(), 'src/components/post/PostComposer.tsx');
  const composerContent = fs.readFileSync(composerPath, 'utf-8');
  if (composerContent.includes('type="file"') || composerContent.includes('accept="image/*"')) {
    throw new Error('Security Violation: Media upload control found in PostComposer.');
  }

  const stripped = sanitizeTextOnlyContent('Testing <b>pure text</b> <script>alert(1)</script>');
  if (stripped !== 'Testing pure text alert(1)') {
    throw new Error('Sanitization failed.');
  }

  return true;
}

runOpenCirkleTests();
