# OpenCirkle Link Preview Fix v30 — 2026-10-24

- Improved URL detection to support both `https://...` and `www....` links in post text.
- Every detected URL now renders a clickable preview card even when metadata lookup fails.
- Added a useful platform/domain fallback title and favicon so social links do not disappear when a preview API is unavailable.
- Added YouTube thumbnail and play treatment for standard, short, embed, live, and youtu.be URLs.
- Kept the same LinkPreview component in the post composer and PostCard, so previews appear before posting and on published posts (including virtual/community profiles when their post text contains a URL).
- Metadata still depends on the external Microlink service and on the target website allowing metadata retrieval; sites that block previews will still show the fallback card, but may not show their private/blocked thumbnail or description.
- Build not claimed: dependencies are not installed in this workspace, so Vite/TypeScript build could not be run here.
