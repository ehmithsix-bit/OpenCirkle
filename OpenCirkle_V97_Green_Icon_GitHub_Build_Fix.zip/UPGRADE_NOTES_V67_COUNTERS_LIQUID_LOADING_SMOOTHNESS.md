# OpenCirkle v67 — Counter Accuracy & Liquid Loading

- Profile Discourses counter now queries Firestore's server-side count for authored posts instead of relying only on a potentially stale `users.postsCount` field.
- Profile post list renders independently from the count request so a slow count lookup does not delay the feed.
- Following counter is normalized to a non-negative finite number before display; malformed/negative stored values cannot render with a minus sign. Virtual follows are counted defensively.
- Replaced the “Resonating crystalline node...” profile loading copy with a compact animated liquid-fill loader and an accessible “Loading” status label.
- Added reduced-motion support for the loader animation.

Notes: Firestore security rules must allow users to read the relevant posts query/count for the counter to show the authoritative result. If that count query is denied, the UI safely falls back to the stored counter. The source ZIP is integrity-checked; a full build/device test was not run because dependencies are not installed in this environment.
