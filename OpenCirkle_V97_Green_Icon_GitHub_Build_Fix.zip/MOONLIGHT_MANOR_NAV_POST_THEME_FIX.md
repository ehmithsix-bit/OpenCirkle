# Moonlight Manor navigation and theme fix

- Hides the in-app mobile bottom navigation while the post composer is open, so it cannot cover the composer or its Publish button.
- Raises the composer overlay above app navigation and other page controls.
- Removes the dock reveal clip-path that clipped the raised centre Post action during navigation opening; keeps the post action above the dock.
- Applies the supplied Moonlight Manor 8 Ball Pool image as the persistent app background and changes the primary navigation accents and app surfaces to teal billiards green.
- Updates Android system navigation/status bar base color to match the teal palette.
- Keeps the original supplied wallpaper asset unchanged at `src/assets/8-ball-pool-moonlight-manor.jpg`.

Build verification should be run in the target Android/Web environment after installing the project's dependencies.
