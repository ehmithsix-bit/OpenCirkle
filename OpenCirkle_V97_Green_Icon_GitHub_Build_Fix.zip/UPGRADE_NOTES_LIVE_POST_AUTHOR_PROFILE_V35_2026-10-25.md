# OpenCirkle v35 — Live author names on older posts

- Post cards now subscribe to the original author's Firestore `users/{authorId}` document.
- When a user changes their display name or username, existing post cards update to the latest profile values without rewriting old post documents.
- The current profile's verified state and avatar symbol/color are also reflected when available.
- The subscription is cleaned up when the card unmounts or the author changes.

## Notes
- Requires the user's current display name and username to be saved in `users/{uid}` in the same Firebase project.
- Existing post data remains intact; only author display fields are resolved live in the UI.
- Build/device verification was not run in this environment because dependencies are not installed.
