# OpenCirkle v51 — Live Profile Identity & Collaboration Display

## Changes
- Existing post headers resolve the original author's current username, display name, verification state and avatar from the live `users/{uid}` profile document.
- Existing story spheres already subscribe to live author profiles; retained this behavior so updated usernames, display names and profile pictures appear on older stories too.
- Accepted collaboration response records are now resolved against live collaborator profile documents, so collaborator usernames, display names and avatars stay current.
- Post headers use an Instagram-style collaboration treatment: original author first, accepted collaborators after them, with overlapping profile avatars.
- Profile post loading now merges authored posts with posts whose collaboration response is `accepted`. Pending and rejected invitations are excluded, and duplicates are removed.
- Accepted collaborator profiles can show the collaborated post even when the post is private, consistent with the existing Firestore rule that permits invited collaborators to read it.

## Important
- Existing collaboration response documents in `postCollaborationResponses` are the source of truth for accepted collaborators.
- This update changes the client application source. Deploy the updated app/site build to make it live for users.
- Build verification was not completed in this environment because dependency installation did not finish; run `npm install`, `npm run lint`, `npm test`, and `npm run build` in the project environment before release.
